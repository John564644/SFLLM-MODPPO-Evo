from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import numpy as np

from sfllm.config import DHFSPConfig, ExperimentConfig
from sfllm.encoding import DHFSPEncoder
from sfllm.evaluator import evaluate_schedule
from sfllm.framework import SFLLMMODPPOEvo
from sfllm.llm.client import OfflineCandidateProvider
from sfllm.llm.processing import process_candidates


def tiny_instance() -> DHFSPConfig:
    n, k, f = 3, 2, 2
    machines = [[2, 2], [2, 2]]
    p, e = {}, {}
    for j in range(n):
        p[str(j)], e[str(j)] = {}, {}
        for s in range(k):
            p[str(j)][str(s)], e[str(j)][str(s)] = {}, {}
            for fac in range(f):
                p[str(j)][str(s)][str(fac)] = {}
                e[str(j)][str(s)][str(fac)] = {}
                for m in range(2):
                    p[str(j)][str(s)][str(fac)][str(m)] = 2.0 + j + s + 0.2 * fac + 0.1 * m
                    e[str(j)][str(s)][str(fac)][str(m)] = 25.0 + 5 * m + 2 * fac
    return DHFSPConfig(
        name="tiny",
        n=n,
        k=k,
        f=f,
        machines_per_stage=machines,
        processing_times=p,
        energy_consumption=e,
        peak_power_limits=[60.0, 60.0],
        seed=7,
    )


class CoreTests(unittest.TestCase):
    def test_encoding_roundtrip(self) -> None:
        cfg = tiny_instance()
        encoder = DHFSPEncoder(cfg)
        schedule = [[(0, 0), (0, 1)], [(1, 1), (1, 0)], [(0, 1), (0, 0)]]
        self.assertEqual(encoder.decode(encoder.encode(schedule)), schedule)

    def test_evaluator_enforces_constraints(self) -> None:
        cfg = tiny_instance()
        schedule = [[(0, 0), (0, 1)], [(0, 1), (0, 0)], [(1, 0), (1, 1)]]
        result = evaluate_schedule(cfg, schedule)
        self.assertTrue(result["feasible"])
        self.assertGreater(result["makespan"], 0)
        self.assertLessEqual(max(result["max_power_by_factory"]), 60.0 + 1e-8)

    def test_candidate_repair(self) -> None:
        cfg = tiny_instance()
        malformed = [[[[9, 99]]]]
        accepted, stats = process_candidates(malformed, cfg, np.random.default_rng(1))
        self.assertEqual(stats.returned, 1)
        self.assertEqual(stats.repaired, 1)
        self.assertEqual(len(accepted), 1)

    def test_quick_framework(self) -> None:
        cfg = tiny_instance()
        experiment = ExperimentConfig.quick(seed=3)
        experiment.population_size = 8
        experiment.iterations = 1
        experiment.ppo_workers = 2
        experiment.local_candidates_per_iteration = 2
        experiment.llm_feedback_interval = 1
        experiment.archive_size = 20
        provider = OfflineCandidateProvider(seed=3)
        solver = SFLLMMODPPOEvo(cfg, experiment, provider)
        result = solver.run()
        self.assertGreaterEqual(len(result["pareto_solutions"]), 1)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "result.json"
            solver.save_result(path)
            self.assertTrue(path.exists())


if __name__ == "__main__":
    unittest.main()
