from __future__ import annotations

from typing import Any, Literal

import numpy as np

from .config import DHFSPConfig
from .encoding import DHFSPEncoder, Schedule
from .simulator import DHFSPEnvironment

EPS_P = 1e-8


def evaluate_schedule(
    cfg: DHFSPConfig,
    schedule: Schedule,
    *,
    dispatch_rule: Literal["earliest_finish", "lexicographic"] = "earliest_finish",
    seed: int = 42,
) -> dict[str, Any]:

    encoder = DHFSPEncoder(cfg)
    encoder.validate_schedule(schedule)
    env = DHFSPEnvironment(cfg, seed=seed)
    env.reset()
    while env.scheduled_count < cfg.n * cfg.k:
        ready = env.ready_operations()
        if not ready:
            raise RuntimeError("decoder has no ready operation")
        scored: list[tuple[float, int, int, int]] = []
        for ready_idx, (job, stage) in enumerate(ready):
            fac, machine = schedule[job][stage]
            finish = (
                env.estimate_finish(job, stage, fac, machine)
                if dispatch_rule == "earliest_finish"
                else float(ready_idx)
            )
            scored.append((finish, job, stage, ready_idx))
        _finish, _job, _stage, ready_idx = min(scored)
        job, stage = ready[ready_idx]
        fac, machine = schedule[job][stage]
        action = env.flatten_action(ready_idx, fac, machine)
        _obs, _mask, _done, info = env.step(action)
    return info


def evaluate_vector(
    cfg: DHFSPConfig,
    vector: np.ndarray,
    *,
    dispatch_rule: Literal["earliest_finish", "lexicographic"] = "earliest_finish",
    seed: int = 42,
) -> dict[str, Any]:
    encoder = DHFSPEncoder(cfg)
    schedule = encoder.decode(vector)
    metrics = evaluate_schedule(cfg, schedule, dispatch_rule=dispatch_rule, seed=seed)
    return {"encoding": np.asarray(vector, dtype=np.float64), "schedule": schedule, "metrics": metrics}


def dominates(a: dict[str, Any], b: dict[str, Any]) -> bool:
    if not a.get("feasible", False) or not b.get("feasible", False):
        return False
    return (
        a["makespan"] <= b["makespan"]
        and a["total_energy"] <= b["total_energy"]
        and (
            a["makespan"] < b["makespan"]
            or a["total_energy"] < b["total_energy"]
        )
    )


def feasibility_audit(metrics: list[dict[str, Any]]) -> dict[str, float]:
    if not metrics:
        return {"CVR": 0.0, "FSR": 1.0}
    cvr = sum(float(m.get("max_violation", 0.0)) > EPS_P for m in metrics) / len(metrics)
    return {"CVR": float(cvr), "FSR": float(1.0 - cvr)}
