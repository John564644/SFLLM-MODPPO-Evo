"""Algorithm 5: robust LLM feedback, validation, and bounded injection."""

from __future__ import annotations

from typing import Any

import numpy as np

from .config import DHFSPConfig, ExperimentConfig
from .llm.client import CandidateProvider
from .llm.processing import CandidateProcessingStats, process_candidates
from .optim.pareto import environmental_select, update_archive


def build_feedback_report(
    population: list[dict[str, Any]],
    archive: list[dict[str, Any]],
    iteration: int,
    recent_stats: CandidateProcessingStats | None = None,
) -> dict[str, Any]:
    feasible = [ind for ind in population if ind["metrics"].get("feasible", False)]
    makespans = [float(ind["metrics"]["makespan"]) for ind in feasible]
    energies = [float(ind["metrics"]["total_energy"]) for ind in feasible]
    cfg: DHFSPConfig | None = population[0].get("cfg") if population else None
    if cfg is None and population:
        schedule = population[0]["schedule"]
        n_factories = max(pair[0] for job in schedule for pair in job) + 1
        n_stages = len(schedule[0])
    elif cfg is not None:
        n_factories = cfg.f
        n_stages = cfg.k
    else:
        n_factories = 0
        n_stages = 0
    factory_job_counts = [0 for _ in range(n_factories)]
    machine_counts: dict[str, int] = {}
    if population:
        for ind in population:
            schedule = ind["schedule"]
            for job_plan in schedule:
                fac = int(job_plan[0][0])
                if 0 <= fac < len(factory_job_counts):
                    factory_job_counts[fac] += 1
                for stage, (_f, machine) in enumerate(job_plan):
                    key = f"f{fac}-s{stage}-m{int(machine)}"
                    machine_counts[key] = machine_counts.get(key, 0) + 1
    overloaded_machines = [
        key
        for key, _value in sorted(machine_counts.items(), key=lambda item: item[1], reverse=True)[:10]
    ]
    report = {
        "iteration": iteration,
        "population_size": len(population),
        "feasible_count": len(feasible),
        "feasible_rate": len(feasible) / max(1, len(population)),
        "average_makespan_feasible": float(np.mean(makespans)) if makespans else None,
        "best_makespan_feasible": min(makespans) if makespans else None,
        "average_total_energy_feasible": float(np.mean(energies)) if energies else None,
        "best_total_energy_feasible": min(energies) if energies else None,
        "archive_size": len(archive),
        "factory_job_counts": factory_job_counts,
        "frequently_used_machine_slots": overloaded_machines,
        "recent_candidate_processing": recent_stats.to_dict() if recent_stats else {},
        "n_stages": n_stages,
    }
    return report


def robust_feedback_and_injection(
    cfg: DHFSPConfig,
    experiment: ExperimentConfig,
    provider: CandidateProvider,
    population: list[dict[str, Any]],
    archive: list[dict[str, Any]],
    iteration: int,
    rng: np.random.Generator,
    recent_stats: CandidateProcessingStats | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], CandidateProcessingStats, dict[str, Any]]:
    report = build_feedback_report(population, archive, iteration, recent_stats)
    payload = provider.generate_feedback(cfg, experiment.llm_batch_size, report)
    candidates, stats = process_candidates(
        payload, cfg, rng, limit=experiment.llm_batch_size
    )
    for candidate in candidates:
        candidate["cfg"] = cfg
    max_injected = int(np.floor(experiment.injection_ratio * len(population)))
    selected = environmental_select(candidates, max_injected) if max_injected > 0 else []
    stats.injected = len(selected)
    updated_population = environmental_select(population + selected, len(population))
    updated_archive = update_archive(
        archive, updated_population + candidates, max_size=experiment.archive_size
    )
    return updated_population, updated_archive, stats, report
