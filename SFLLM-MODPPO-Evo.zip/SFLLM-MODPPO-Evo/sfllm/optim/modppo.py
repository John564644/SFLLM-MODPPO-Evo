"""
Algorithm 3
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.distributions import Categorical

from ..config import DHFSPConfig, ExperimentConfig
from ..encoding import DHFSPEncoder, Schedule
from ..simulator import DHFSPEnvironment


class ActorCritic(nn.Module):
    def __init__(self, state_size: int, action_size: int, hidden_size: int):
        super().__init__()
        self.backbone = nn.Sequential(
            nn.Linear(state_size, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, hidden_size),
            nn.Tanh(),
        )
        self.actor = nn.Linear(hidden_size, action_size)
        self.values = nn.Linear(hidden_size, 3)

    def forward(self, states: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        hidden = self.backbone(states)
        return self.actor(hidden), self.values(hidden)


@dataclass
class Rollout:
    states: list[np.ndarray]
    masks: list[np.ndarray]
    actions: list[int]
    log_probs: list[float]
    values: list[np.ndarray]
    rewards: list[np.ndarray]
    dones: list[bool]
    schedule: Schedule
    metrics: dict[str, Any]
    weight: np.ndarray


class MODPPOTrainer:
    def __init__(self, cfg: DHFSPConfig, experiment: ExperimentConfig):
        self.cfg = cfg
        self.experiment = experiment
        self.device = torch.device(experiment.device)
        prototype = DHFSPEnvironment(cfg, seed=experiment.seed)
        self.state_size = prototype.state_size
        self.action_size = prototype.action_size
        torch.manual_seed(experiment.seed)
        self.network = ActorCritic(
            self.state_size, self.action_size, experiment.hidden_size
        ).to(self.device)
        self.optimizer = torch.optim.Adam(
            self.network.parameters(), lr=experiment.learning_rate
        )
        self.rng = np.random.default_rng(experiment.seed)
        self.weights = self._weight_vectors(experiment.ppo_workers)

    def _weight_vectors(self, count: int) -> list[np.ndarray]:
        if count == 1:
            values = [0.5]
        else:
            values = np.linspace(0.05, 0.95, count)
        return [
            np.array(
                [float(w), float(1.0 - w), self.experiment.violation_weight],
                dtype=np.float32,
            )
            for w in values
        ]

    @staticmethod
    def _masked_distribution(logits: torch.Tensor, mask: torch.Tensor) -> Categorical:
        masked_logits = logits.masked_fill(~mask, torch.finfo(logits.dtype).min)
        return Categorical(logits=masked_logits)

    def _rollout(self, weight: np.ndarray, *, greedy: bool = False, seed: int = 0) -> Rollout:
        env = DHFSPEnvironment(self.cfg, seed=seed)
        state, mask = env.reset()
        states: list[np.ndarray] = []
        masks: list[np.ndarray] = []
        actions: list[int] = []
        log_probs: list[float] = []
        values: list[np.ndarray] = []
        rewards: list[np.ndarray] = []
        dones: list[bool] = []
        done = False
        info: dict[str, Any] = {}
        while not done:
            state_tensor = torch.as_tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
            mask_tensor = torch.as_tensor(mask, dtype=torch.bool, device=self.device).unsqueeze(0)
            with torch.no_grad():
                logits, value_vector = self.network(state_tensor)
                distribution = self._masked_distribution(logits, mask_tensor)
                action_tensor = (
                    torch.argmax(logits.masked_fill(~mask_tensor, -torch.inf), dim=-1)
                    if greedy
                    else distribution.sample()
                )
                log_prob = distribution.log_prob(action_tensor)
            action = int(action_tensor.item())
            next_state, next_mask, done, info = env.step(action)
            states.append(state.copy())
            masks.append(mask.copy())
            actions.append(action)
            log_probs.append(float(log_prob.item()))
            values.append(value_vector.squeeze(0).cpu().numpy().astype(np.float32))
            rewards.append(np.zeros(3, dtype=np.float32))
            dones.append(done)
            state, mask = next_state, next_mask
        terminal_reward = np.array(
            [
                -float(info["ms_norm"]),
                -float(info["en_norm"]),
                -float(info["violation_norm"]),
            ],
            dtype=np.float32,
        )
        rewards[-1] = terminal_reward
        return Rollout(
            states,
            masks,
            actions,
            log_probs,
            values,
            rewards,
            dones,
            info["schedule"],
            info,
            weight,
        )

    def _advantages_and_returns(self, rollout: Rollout) -> tuple[np.ndarray, np.ndarray]:
        rewards = np.asarray(rollout.rewards, dtype=np.float32)
        values = np.asarray(rollout.values, dtype=np.float32)
        advantages = np.zeros_like(rewards)
        gae = np.zeros(3, dtype=np.float32)
        for t in range(len(rewards) - 1, -1, -1):
            next_values = values[t + 1] if t + 1 < len(values) else np.zeros(3, dtype=np.float32)
            nonterminal = 0.0 if rollout.dones[t] else 1.0
            delta = rewards[t] + self.experiment.gamma * next_values * nonterminal - values[t]
            gae = (
                delta
                + self.experiment.gamma
                * self.experiment.gae_lambda
                * nonterminal
                * gae
            )
            advantages[t] = gae
        returns = advantages + values
        return advantages, returns

    def update(self, rollouts: list[Rollout]) -> dict[str, float]:
        if not rollouts:
            return {"loss": 0.0, "policy_loss": 0.0, "value_loss": 0.0, "entropy": 0.0}
        states: list[np.ndarray] = []
        masks: list[np.ndarray] = []
        actions: list[int] = []
        old_log_probs: list[float] = []
        advantages_scalar: list[float] = []
        returns_vector: list[np.ndarray] = []
        for rollout in rollouts:
            advantages, returns = self._advantages_and_returns(rollout)
            scalar_advantage = advantages @ rollout.weight
            states.extend(rollout.states)
            masks.extend(rollout.masks)
            actions.extend(rollout.actions)
            old_log_probs.extend(rollout.log_probs)
            advantages_scalar.extend(scalar_advantage.tolist())
            returns_vector.extend(list(returns))
        states_tensor = torch.as_tensor(np.asarray(states), dtype=torch.float32, device=self.device)
        masks_tensor = torch.as_tensor(np.asarray(masks), dtype=torch.bool, device=self.device)
        actions_tensor = torch.as_tensor(actions, dtype=torch.long, device=self.device)
        old_log_tensor = torch.as_tensor(old_log_probs, dtype=torch.float32, device=self.device)
        advantage_tensor = torch.as_tensor(advantages_scalar, dtype=torch.float32, device=self.device)
        return_tensor = torch.as_tensor(np.asarray(returns_vector), dtype=torch.float32, device=self.device)
        advantage_tensor = (advantage_tensor - advantage_tensor.mean()) / (
            advantage_tensor.std(unbiased=False) + 1e-8
        )
        n_samples = states_tensor.shape[0]
        batch_size = min(self.experiment.ppo_batch_size, n_samples)
        final_stats = {"loss": 0.0, "policy_loss": 0.0, "value_loss": 0.0, "entropy": 0.0}
        updates = 0
        for _epoch in range(self.experiment.ppo_update_epochs):
            permutation = torch.randperm(n_samples, device=self.device)
            for start in range(0, n_samples, batch_size):
                idx = permutation[start : start + batch_size]
                logits, value_vectors = self.network(states_tensor[idx])
                distribution = self._masked_distribution(logits, masks_tensor[idx])
                new_log_probs = distribution.log_prob(actions_tensor[idx])
                entropy = distribution.entropy().mean()
                ratio = torch.exp(new_log_probs - old_log_tensor[idx])
                unclipped = ratio * advantage_tensor[idx]
                clipped = torch.clamp(
                    ratio,
                    1.0 - self.experiment.ppo_clip,
                    1.0 + self.experiment.ppo_clip,
                ) * advantage_tensor[idx]
                policy_loss = -torch.min(unclipped, clipped).mean()
                value_loss = torch.nn.functional.mse_loss(value_vectors, return_tensor[idx])
                loss = (
                    policy_loss
                    + self.experiment.value_coef * value_loss
                    - self.experiment.entropy_coef * entropy
                )
                self.optimizer.zero_grad(set_to_none=True)
                loss.backward()
                nn.utils.clip_grad_norm_(
                    self.network.parameters(), self.experiment.max_grad_norm
                )
                self.optimizer.step()
                final_stats["loss"] += float(loss.item())
                final_stats["policy_loss"] += float(policy_loss.item())
                final_stats["value_loss"] += float(value_loss.item())
                final_stats["entropy"] += float(entropy.item())
                updates += 1
        if updates:
            final_stats = {key: value / updates for key, value in final_stats.items()}
        return final_stats

    def train_iteration(self, iteration: int) -> tuple[list[dict[str, Any]], dict[str, float]]:
        rollouts = [
            self._rollout(weight, greedy=False, seed=self.experiment.seed + iteration * 100 + index)
            for index, weight in enumerate(self.weights)
        ]
        stats = self.update(rollouts)
        candidates = [
            {
                "encoding": DHFSPEncoder(self.cfg).encode(rollout.schedule),
                "schedule": rollout.schedule,
                "metrics": rollout.metrics,
                "source": "modppo",
            }
            for rollout in rollouts
        ]
        # Additional policy rollouts cover the requested local candidate count.
        while len(candidates) < self.experiment.local_candidates_per_iteration:
            index = len(candidates)
            weight = self.weights[index % len(self.weights)]
            rollout = self._rollout(
                weight,
                greedy=index % 2 == 0,
                seed=self.experiment.seed + iteration * 1000 + index,
            )
            candidates.append(
                {
                    "encoding": DHFSPEncoder(self.cfg).encode(rollout.schedule),
                    "schedule": rollout.schedule,
                    "metrics": rollout.metrics,
                    "source": "modppo",
                }
            )
        return candidates, stats

    def behavior_clone(self, schedules: list[Schedule], epochs: int | None = None) -> float:
        """Warm-start the shared actor from validated initialization schedules."""
        if not schedules:
            return 0.0
        states: list[np.ndarray] = []
        masks: list[np.ndarray] = []
        actions: list[int] = []
        for schedule_index, schedule in enumerate(schedules):
            env = DHFSPEnvironment(self.cfg, seed=self.experiment.seed + schedule_index)
            state, mask = env.reset()
            while env.scheduled_count < self.cfg.n * self.cfg.k:
                ready = env.ready_operations()
                scored: list[tuple[float, int, int, int]] = []
                for ready_idx, (job, stage) in enumerate(ready):
                    fac, machine = schedule[job][stage]
                    scored.append(
                        (
                            env.estimate_finish(job, stage, fac, machine),
                            job,
                            stage,
                            ready_idx,
                        )
                    )
                _finish, _job, _stage, ready_idx = min(scored)
                job, stage = ready[ready_idx]
                fac, machine = schedule[job][stage]
                action = env.flatten_action(ready_idx, fac, machine)
                states.append(state.copy())
                masks.append(mask.copy())
                actions.append(action)
                state, mask, _done, _info = env.step(action)
        states_tensor = torch.as_tensor(np.asarray(states), dtype=torch.float32, device=self.device)
        masks_tensor = torch.as_tensor(np.asarray(masks), dtype=torch.bool, device=self.device)
        actions_tensor = torch.as_tensor(actions, dtype=torch.long, device=self.device)
        total_loss = 0.0
        count = 0
        for _ in range(epochs if epochs is not None else self.experiment.behavior_clone_epochs):
            permutation = torch.randperm(len(actions), device=self.device)
            batch_size = min(self.experiment.ppo_batch_size, len(actions))
            for start in range(0, len(actions), batch_size):
                idx = permutation[start : start + batch_size]
                logits, _values = self.network(states_tensor[idx])
                masked_logits = logits.masked_fill(~masks_tensor[idx], torch.finfo(logits.dtype).min)
                loss = torch.nn.functional.cross_entropy(masked_logits, actions_tensor[idx])
                self.optimizer.zero_grad(set_to_none=True)
                loss.backward()
                nn.utils.clip_grad_norm_(self.network.parameters(), self.experiment.max_grad_norm)
                self.optimizer.step()
                total_loss += float(loss.item())
                count += 1
        return total_loss / max(1, count)
