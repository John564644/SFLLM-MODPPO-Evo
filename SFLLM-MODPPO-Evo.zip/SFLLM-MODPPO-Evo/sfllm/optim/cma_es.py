"""Algorithm 4: covariance-guided global evolution."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import numpy as np

Individual = dict[str, Any]


def _aggregate(ind: Individual) -> float:
    metrics = ind["metrics"]
    return float(metrics["makespan"] + metrics["total_energy"])


def _sample_empirical_covariance(
    mean: np.ndarray,
    centered: np.ndarray,
    rng: np.random.Generator,
    eps: float,
) -> np.ndarray:
    """Sample N(mean, Cov(elites)+eps I) without forming/decomposing an LxL matrix."""
    elite_count, dimension = centered.shape
    z = rng.standard_normal(elite_count)
    empirical = centered.T @ z / np.sqrt(max(1, elite_count - 1))
    jitter = np.sqrt(eps) * rng.standard_normal(dimension)
    return mean + empirical + jitter


def cma_es_step(
    population: list[Individual],
    evaluate_vector: Callable[[np.ndarray], Individual],
    rng: np.random.Generator,
    *,
    elite_size: int,
    sigma: float,
    eps: float = 1e-6,
    target_size: int | None = None,
) -> list[Individual]:
    """One covariance-resampling generation matching Algorithm 4."""
    target = int(target_size or len(population))
    if len(population) < 2 or target < 2:
        return list(population)
    feasible = [ind for ind in population if ind["metrics"].get("feasible", False)]
    if feasible:
        pool = sorted(feasible, key=_aggregate)
    else:
        pool = sorted(
            population,
            key=lambda ind: ind["metrics"].get("max_violation", float("inf")),
        )
    elites = [ind for ind in pool[: max(1, min(elite_size, len(pool)))] if ind.get("encoding") is not None]
    if not elites:
        return list(population)
    matrix = np.stack([np.asarray(ind["encoding"], dtype=np.float64) for ind in elites])
    mean = matrix.mean(axis=0)
    centered = matrix - mean
    offspring: list[Individual] = []
    attempts = 0
    required = max(0, target - len(elites))
    while len(offspring) < required and attempts < max(10, required * 3):
        attempts += 1
        if matrix.shape[0] > 1:
            sample = _sample_empirical_covariance(mean, centered, rng, eps)
        else:
            sample = mean + sigma * rng.standard_normal(mean.shape)
        sample = np.clip(sample, 0.0, 1.0)
        try:
            offspring.append(evaluate_vector(sample))
        except (ValueError, RuntimeError, FloatingPointError):
            continue
    result = elites + offspring
    if len(result) < target:
        included = {id(ind) for ind in result}
        for ind in pool:
            if id(ind) not in included:
                result.append(ind)
                included.add(id(ind))
                if len(result) == target:
                    break
    return result[:target]
