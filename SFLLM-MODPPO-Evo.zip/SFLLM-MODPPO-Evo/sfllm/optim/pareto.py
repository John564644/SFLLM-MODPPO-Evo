"""Feasibility-first Pareto archive and diversity-preserving selection."""

from __future__ import annotations

from typing import Any

import numpy as np

from ..encoding import schedule_key

Individual = dict[str, Any]


def _objective(ind: Individual) -> tuple[float, float]:
    metrics = ind["metrics"]
    return float(metrics["makespan"]), float(metrics["total_energy"])


def nondominated_front(individuals: list[Individual]) -> list[Individual]:
    unique: dict[tuple[int, ...], Individual] = {}
    for ind in individuals:
        if not ind["metrics"].get("feasible", False):
            continue
        key = schedule_key(ind["schedule"])
        current = unique.get(key)
        if current is None or sum(_objective(ind)) < sum(_objective(current)):
            unique[key] = ind
    candidates = list(unique.values())
    front: list[Individual] = []
    for i, a in enumerate(candidates):
        ma, ea = _objective(a)
        dominated = False
        for j, b in enumerate(candidates):
            if i == j:
                continue
            mb, eb = _objective(b)
            if mb <= ma and eb <= ea and (mb < ma or eb < ea):
                dominated = True
                break
        if not dominated:
            front.append(a)
    return sorted(front, key=lambda ind: _objective(ind))


def fast_nondominated_sort(individuals: list[Individual]) -> list[list[Individual]]:
    n = len(individuals)
    if n == 0:
        return []
    dominates_set: list[list[int]] = [[] for _ in range(n)]
    dominated_count = [0] * n
    fronts: list[list[int]] = [[]]
    for i in range(n):
        mi, ei = _objective(individuals[i])
        for j in range(i + 1, n):
            mj, ej = _objective(individuals[j])
            i_dom = mi <= mj and ei <= ej and (mi < mj or ei < ej)
            j_dom = mj <= mi and ej <= ei and (mj < mi or ej < ei)
            if i_dom:
                dominates_set[i].append(j)
                dominated_count[j] += 1
            elif j_dom:
                dominates_set[j].append(i)
                dominated_count[i] += 1
    fronts[0] = [i for i, count in enumerate(dominated_count) if count == 0]
    level = 0
    while level < len(fronts) and fronts[level]:
        next_front: list[int] = []
        for i in fronts[level]:
            for j in dominates_set[i]:
                dominated_count[j] -= 1
                if dominated_count[j] == 0:
                    next_front.append(j)
        if next_front:
            fronts.append(next_front)
        level += 1
    return [[individuals[i] for i in front] for front in fronts if front]


def crowding_distance(front: list[Individual]) -> dict[int, float]:
    if not front:
        return {}
    distance = {id(ind): 0.0 for ind in front}
    if len(front) <= 2:
        return {id(ind): float("inf") for ind in front}
    for objective_index in (0, 1):
        ordered = sorted(front, key=lambda ind: _objective(ind)[objective_index])
        distance[id(ordered[0])] = float("inf")
        distance[id(ordered[-1])] = float("inf")
        values = [_objective(ind)[objective_index] for ind in ordered]
        span = max(values) - min(values)
        if span <= 0:
            continue
        for i in range(1, len(ordered) - 1):
            if np.isinf(distance[id(ordered[i])]):
                continue
            distance[id(ordered[i])] += (values[i + 1] - values[i - 1]) / span
    return distance


def _deduplicate(individuals: list[Individual]) -> list[Individual]:
    best: dict[tuple[int, ...], Individual] = {}
    for ind in individuals:
        key = schedule_key(ind["schedule"])
        old = best.get(key)
        if old is None:
            best[key] = ind
            continue
        old_m = old["metrics"]
        new_m = ind["metrics"]
        old_score = (
            0 if old_m.get("feasible", False) else 1,
            old_m.get("max_violation", float("inf")),
            old_m.get("makespan", float("inf")) + old_m.get("total_energy", float("inf")),
        )
        new_score = (
            0 if new_m.get("feasible", False) else 1,
            new_m.get("max_violation", float("inf")),
            new_m.get("makespan", float("inf")) + new_m.get("total_energy", float("inf")),
        )
        if new_score < old_score:
            best[key] = ind
    return list(best.values())


def environmental_select(individuals: list[Individual], size: int) -> list[Individual]:
    """Feasibility-first rank-and-crowding survival selection."""
    if size <= 0:
        return []
    unique = _deduplicate(individuals)
    feasible = [ind for ind in unique if ind["metrics"].get("feasible", False)]
    infeasible = [ind for ind in unique if not ind["metrics"].get("feasible", False)]
    selected: list[Individual] = []
    for front in fast_nondominated_sort(feasible):
        remaining = size - len(selected)
        if remaining <= 0:
            break
        if len(front) <= remaining:
            selected.extend(front)
        else:
            distances = crowding_distance(front)
            selected.extend(
                sorted(front, key=lambda ind: distances[id(ind)], reverse=True)[:remaining]
            )
    if len(selected) < size:
        infeasible.sort(
            key=lambda ind: (
                ind["metrics"].get("max_violation", float("inf")),
                ind["metrics"].get("makespan", float("inf"))
                + ind["metrics"].get("total_energy", float("inf")),
            )
        )
        selected.extend(infeasible[: size - len(selected)])
    return selected[:size]


def update_archive(
    archive: list[Individual],
    candidates: list[Individual],
    max_size: int | None = None,
) -> list[Individual]:
    front = nondominated_front(list(archive) + list(candidates))
    if max_size is None or len(front) <= max_size:
        return front
    distances = crowding_distance(front)
    return sorted(front, key=lambda ind: distances[id(ind)], reverse=True)[:max_size]
