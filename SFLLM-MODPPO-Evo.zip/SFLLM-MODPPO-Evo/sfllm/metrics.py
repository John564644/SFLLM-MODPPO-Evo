from __future__ import annotations

from collections.abc import Sequence

import numpy as np

Point = tuple[float, float]


def nondominated_points(points: Sequence[Point]) -> list[Point]:
    unique = sorted(set((float(a), float(b)) for a, b in points))
    front: list[Point] = []
    for i, point in enumerate(unique):
        if any(
            j != i
            and other[0] <= point[0]
            and other[1] <= point[1]
            and (other[0] < point[0] or other[1] < point[1])
            for j, other in enumerate(unique)
        ):
            continue
        front.append(point)
    return sorted(front)


def hypervolume(front: Sequence[Point], reference_point: Point | None = None) -> float:
    pf = nondominated_points(front)
    if not pf:
        return 0.0
    array = np.asarray(pf, dtype=float)
    ref = (
        np.asarray(reference_point, dtype=float)
        if reference_point is not None
        else np.maximum(array.max(axis=0) * 1.1, array.max(axis=0) + 1.0)
    )
    hv = 0.0
    previous_y = float(ref[1])
    for x, y in array[np.argsort(array[:, 0])]:
        if y < previous_y:
            hv += max(0.0, float(ref[0] - x)) * max(0.0, previous_y - float(y))
            previous_y = float(y)
    return float(hv)


def igd(front: Sequence[Point], reference_front: Sequence[Point]) -> float:
    if not front or not reference_front:
        return float("inf")
    pf = np.asarray(front, dtype=float)
    rf = np.asarray(reference_front, dtype=float)
    lower, upper = rf.min(axis=0), rf.max(axis=0)
    span = np.where(upper > lower, upper - lower, 1.0)
    pf = (pf - lower) / span
    rf = (rf - lower) / span
    return float(np.mean([np.min(np.linalg.norm(pf - point, axis=1)) for point in rf]))


def spacing(front: Sequence[Point]) -> float:
    if len(front) < 2:
        return 0.0
    pf = np.asarray(front, dtype=float)
    lower, upper = pf.min(axis=0), pf.max(axis=0)
    span = np.where(upper > lower, upper - lower, 1.0)
    pf = (pf - lower) / span
    nearest = []
    for i, point in enumerate(pf):
        others = np.delete(pf, i, axis=0)
        nearest.append(float(np.min(np.linalg.norm(others - point, axis=1))))
    nearest_array = np.asarray(nearest)
    return float(np.sqrt(np.mean((nearest_array - nearest_array.mean()) ** 2)))


def archive_summary(archive: list[dict]) -> dict[str, float | int | None]:
    points = [
        (float(ind["metrics"]["makespan"]), float(ind["metrics"]["total_energy"]))
        for ind in archive
        if ind["metrics"].get("feasible", False)
    ]
    return {
        "archive_size": len(points),
        "best_makespan": min((p[0] for p in points), default=None),
        "best_total_energy": min((p[1] for p in points), default=None),
        "spacing": spacing(points),
        "hypervolume_raw": hypervolume(points) if points else 0.0,
    }
