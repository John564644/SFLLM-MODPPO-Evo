"""Algorithms 1 and 2: encoding and decoding."""

from __future__ import annotations

from typing import Iterable

import numpy as np

from .config import DHFSPConfig

Schedule = list[list[tuple[int, int]]]


class DHFSPEncoder:

    def __init__(self, cfg: DHFSPConfig):
        self.cfg = cfg
        self.encoding_length = cfg.n * (cfg.k + 1)

    def validate_schedule(self, schedule: Schedule) -> None:
        if len(schedule) != self.cfg.n:
            raise ValueError("schedule job dimension mismatch")
        for j, job_plan in enumerate(schedule):
            if len(job_plan) != self.cfg.k:
                raise ValueError(f"job {j} stage dimension mismatch")
            factories = {int(pair[0]) for pair in job_plan}
            if len(factories) != 1:
                raise ValueError(f"job {j} is split across factories")
            fac = next(iter(factories))
            if not 0 <= fac < self.cfg.f:
                raise ValueError(f"job {j} uses invalid factory")
            for s, (_f, machine) in enumerate(job_plan):
                if not 0 <= int(machine) < self.cfg.n_machines(fac, s):
                    raise ValueError(f"job {j}, stage {s} uses invalid machine")

    def encode(self, schedule: Schedule) -> np.ndarray:
        self.validate_schedule(schedule)
        genes = np.empty(self.encoding_length, dtype=np.float64)
        idx = 0
        for j in range(self.cfg.n):
            fac = int(schedule[j][0][0])
            genes[idx] = fac / max(1, self.cfg.f - 1)
            idx += 1
            for s in range(self.cfg.k):
                machine = int(schedule[j][s][1])
                genes[idx] = machine / max(1, self.cfg.n_machines(fac, s) - 1)
                idx += 1
        return genes

    def decode(self, vector: Iterable[float]) -> Schedule:
        r = np.asarray(list(vector), dtype=np.float64).reshape(-1)
        if r.size != self.encoding_length:
            raise ValueError(
                f"encoding length {r.size} != expected {self.encoding_length}"
            )
        r = np.clip(r, 0.0, 1.0)
        schedule: Schedule = []
        idx = 0
        for _j in range(self.cfg.n):
            fac = int(np.clip(np.rint(r[idx] * (self.cfg.f - 1)), 0, self.cfg.f - 1))
            idx += 1
            job_plan: list[tuple[int, int]] = []
            for s in range(self.cfg.k):
                machine_count = self.cfg.n_machines(fac, s)
                machine = int(
                    np.clip(np.rint(r[idx] * (machine_count - 1)), 0, machine_count - 1)
                )
                idx += 1
                job_plan.append((fac, machine))
            schedule.append(job_plan)
        return schedule

    def random_schedule(self, rng: np.random.Generator) -> Schedule:
        result: Schedule = []
        for _j in range(self.cfg.n):
            fac = int(rng.integers(0, self.cfg.f))
            result.append(
                [
                    (fac, int(rng.integers(0, self.cfg.n_machines(fac, s))))
                    for s in range(self.cfg.k)
                ]
            )
        return result

    def random_vector(self, rng: np.random.Generator) -> np.ndarray:
        return rng.random(self.encoding_length)


def schedule_key(schedule: Schedule) -> tuple[int, ...]:
    values: list[int] = []
    for job_plan in schedule:
        for fac, machine in job_plan:
            values.extend((int(fac), int(machine)))
    return tuple(values)
