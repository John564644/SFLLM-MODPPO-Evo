from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from .config import DHFSPConfig
from .encoding import Schedule

EPS = 1e-9


@dataclass(frozen=True)
class OperationInterval:
    job: int
    stage: int
    factory: int
    machine: int
    start: float
    finish: float
    power: float


class DHFSPEnvironment:

    def __init__(self, cfg: DHFSPConfig, seed: int = 42):
        self.cfg = cfg
        self.rng = np.random.default_rng(seed)
        self.max_machines = cfg.max_machines
        self.action_size = cfg.n * cfg.f * self.max_machines
        self.state_size = 2 * cfg.n + cfg.f + cfg.k + 5
        self.time_scale = max(
            1.0,
            sum(
                max(
                    cfg.p(j, s, fac, m)
                    for fac in range(cfg.f)
                    for m in range(cfg.n_machines(fac, s))
                )
                for j in range(cfg.n)
                for s in range(cfg.k)
            ),
        )
        self.energy_scale = max(
            1.0,
            sum(
                max(
                    cfg.p(j, s, fac, m) * cfg.e(j, s, fac, m)
                    for fac in range(cfg.f)
                    for m in range(cfg.n_machines(fac, s))
                )
                for j in range(cfg.n)
                for s in range(cfg.k)
            ),
        )
        self.reset()

    def reset(self) -> tuple[np.ndarray, np.ndarray]:
        c = self.cfg
        self.assignments: list[list[tuple[int, int] | None]] = [
            [None for _ in range(c.k)] for _ in range(c.n)
        ]
        self.start_times = np.full((c.n, c.k), np.nan, dtype=np.float64)
        self.finish_times = np.full((c.n, c.k), np.nan, dtype=np.float64)
        self.job_factory = np.full(c.n, -1, dtype=np.int64)
        self.machine_intervals: list[list[list[list[OperationInterval]]]] = [
            [
                [[] for _ in range(c.n_machines(fac, stage))]
                for stage in range(c.k)
            ]
            for fac in range(c.f)
        ]
        self.factory_intervals: list[list[OperationInterval]] = [
            [] for _ in range(c.f)
        ]
        self.scheduled_count = 0
        self.total_energy = 0.0
        self.invalid_actions = 0
        return self.observation(), self.action_mask()

    def ready_operations(self) -> list[tuple[int, int]]:
        ready: list[tuple[int, int]] = []
        for j in range(self.cfg.n):
            for s in range(self.cfg.k):
                if self.assignments[j][s] is not None:
                    continue
                if s == 0 or self.assignments[j][s - 1] is not None:
                    ready.append((j, s))
                break
        return ready

    def flatten_action(self, ready_index: int, factory: int, machine: int) -> int:
        return (
            ready_index * (self.cfg.f * self.max_machines)
            + factory * self.max_machines
            + machine
        )

    def unflatten_action(self, action: int) -> tuple[int, int, int]:
        per_ready = self.cfg.f * self.max_machines
        ready_index, rem = divmod(int(action), per_ready)
        factory, machine = divmod(rem, self.max_machines)
        return ready_index, factory, machine

    def action_mask(self) -> np.ndarray:
        mask = np.zeros(self.action_size, dtype=np.bool_)
        for ready_idx, (job, stage) in enumerate(self.ready_operations()):
            locked = int(self.job_factory[job])
            factories = [locked] if locked >= 0 else range(self.cfg.f)
            for fac in factories:
                for machine in range(self.cfg.n_machines(fac, stage)):
                    if self.cfg.e(job, stage, fac, machine) <= self.cfg.peak_power_limits[fac] + EPS:
                        mask[self.flatten_action(ready_idx, fac, machine)] = True
        return mask

    def observation(self) -> np.ndarray:
        c = self.cfg
        job_progress = np.zeros(c.n, dtype=np.float32)
        for j in range(c.n):
            job_progress[j] = sum(v is not None for v in self.assignments[j]) / c.k
        factory_state = np.where(
            self.job_factory < 0,
            -1.0,
            self.job_factory / max(1, c.f - 1),
        ).astype(np.float32)
        factory_load = np.zeros(c.f, dtype=np.float32)
        for fac in range(c.f):
            factory_load[fac] = (
                sum(x.finish - x.start for x in self.factory_intervals[fac]) / self.time_scale
            )
        stage_progress = np.zeros(c.k, dtype=np.float32)
        for s in range(c.k):
            stage_progress[s] = sum(self.assignments[j][s] is not None for j in range(c.n)) / c.n
        current_makespan = float(np.nanmax(self.finish_times)) if np.any(~np.isnan(self.finish_times)) else 0.0
        global_features = np.array(
            [
                self.scheduled_count / (c.n * c.k),
                len(self.ready_operations()) / c.n,
                current_makespan / self.time_scale,
                self.total_energy / self.energy_scale,
                self.invalid_actions / max(1, self.scheduled_count + self.invalid_actions),
            ],
            dtype=np.float32,
        )
        return np.concatenate(
            [job_progress, factory_state, factory_load, stage_progress, global_features]
        ).astype(np.float32)

    @staticmethod
    def _overlap(start_a: float, end_a: float, start_b: float, end_b: float) -> bool:
        return start_a < end_b - EPS and start_b < end_a - EPS

    def _machine_next_time(
        self, fac: int, stage: int, machine: int, start: float, duration: float
    ) -> float | None:
        finish = start + duration
        overlaps = [
            interval
            for interval in self.machine_intervals[fac][stage][machine]
            if self._overlap(start, finish, interval.start, interval.finish)
        ]
        if not overlaps:
            return None
        return min(interval.finish for interval in overlaps if interval.finish > start + EPS)

    def _power_next_time(
        self, fac: int, start: float, duration: float, add_power: float
    ) -> float | None:
        if add_power > self.cfg.peak_power_limits[fac] + EPS:
            return float("inf")
        finish = start + duration
        relevant = [
            interval
            for interval in self.factory_intervals[fac]
            if self._overlap(start, finish, interval.start, interval.finish)
        ]
        checkpoints = {start}
        for interval in relevant:
            if start < interval.start < finish:
                checkpoints.add(interval.start)
            if start < interval.finish < finish:
                checkpoints.add(interval.finish)
        for t in sorted(checkpoints):
            existing = sum(
                interval.power
                for interval in relevant
                if interval.start <= t + EPS < interval.finish - EPS
            )
            if existing + add_power > self.cfg.peak_power_limits[fac] + EPS:
                ends = [
                    interval.finish
                    for interval in relevant
                    if interval.start <= t + EPS < interval.finish - EPS
                ]
                return min(ends) if ends else t + EPS
        return None

    def earliest_feasible_start(
        self, job: int, stage: int, fac: int, machine: int
    ) -> float:
        duration = self.cfg.p(job, stage, fac, machine)
        power = self.cfg.e(job, stage, fac, machine)
        predecessor_finish = 0.0 if stage == 0 else float(self.finish_times[job, stage - 1])
        t = predecessor_finish
        for _ in range(100000):
            machine_next = self._machine_next_time(fac, stage, machine, t, duration)
            if machine_next is not None:
                t = max(t + EPS, machine_next)
                continue
            power_next = self._power_next_time(fac, t, duration, power)
            if power_next is not None:
                if not np.isfinite(power_next):
                    raise ValueError("operation power exceeds factory peak-power limit")
                t = max(t + EPS, power_next)
                continue
            return float(t)
        raise RuntimeError("failed to find a feasible start time")

    def estimate_finish(self, job: int, stage: int, fac: int, machine: int) -> float:
        return self.earliest_feasible_start(job, stage, fac, machine) + self.cfg.p(
            job, stage, fac, machine
        )

    def step(
        self, action: int
    ) -> tuple[np.ndarray, np.ndarray, bool, dict[str, Any]]:
        mask = self.action_mask()
        if action < 0 or action >= self.action_size or not bool(mask[action]):
            self.invalid_actions += 1
            valid = np.flatnonzero(mask)
            if valid.size == 0:
                raise RuntimeError("no valid action exists for an unfinished schedule")
            action = int(valid[0])
        ready = self.ready_operations()
        ready_idx, fac, machine = self.unflatten_action(action)
        if ready_idx >= len(ready):
            raise RuntimeError("action ready-operation index is out of range")
        job, stage = ready[ready_idx]
        locked = int(self.job_factory[job])
        if locked >= 0 and fac != locked:
            raise RuntimeError("action violates job-factory consistency")
        if locked < 0:
            self.job_factory[job] = fac
        start = self.earliest_feasible_start(job, stage, fac, machine)
        duration = self.cfg.p(job, stage, fac, machine)
        power = self.cfg.e(job, stage, fac, machine)
        finish = start + duration
        interval = OperationInterval(job, stage, fac, machine, start, finish, power)
        self.machine_intervals[fac][stage][machine].append(interval)
        self.factory_intervals[fac].append(interval)
        self.assignments[job][stage] = (fac, machine)
        self.start_times[job, stage] = start
        self.finish_times[job, stage] = finish
        self.scheduled_count += 1
        self.total_energy += duration * power
        done = self.scheduled_count == self.cfg.n * self.cfg.k
        info = self.final_info() if done else {}
        return self.observation(), self.action_mask(), done, info

    def final_schedule(self) -> Schedule:
        if self.scheduled_count != self.cfg.n * self.cfg.k:
            raise RuntimeError("schedule is incomplete")
        return [
            [(int(pair[0]), int(pair[1])) for pair in job_plan if pair is not None]
            for job_plan in self.assignments
        ]

    def _max_power(self, fac: int) -> float:
        events: list[tuple[float, int, float]] = []
        for interval in self.factory_intervals[fac]:
            events.append((interval.start, 1, interval.power))
            events.append((interval.finish, -1, interval.power))
        # End events before start events at equal time.
        events.sort(key=lambda item: (item[0], item[1]))
        current = 0.0
        maximum = 0.0
        for _t, event_type, power in events:
            current += event_type * power
            maximum = max(maximum, current)
        return maximum

    def final_info(self) -> dict[str, Any]:
        makespan = float(np.nanmax(self.finish_times))
        max_power = [self._max_power(fac) for fac in range(self.cfg.f)]
        max_violation = max(
            [0.0]
            + [
                max_power[fac] - self.cfg.peak_power_limits[fac]
                for fac in range(self.cfg.f)
            ]
        )
        return {
            "schedule": self.final_schedule(),
            "start_times": self.start_times.tolist(),
            "finish_times": self.finish_times.tolist(),
            "makespan": makespan,
            "total_energy": float(self.total_energy),
            "ms_norm": makespan / self.time_scale,
            "en_norm": self.total_energy / self.energy_scale,
            "max_power_by_factory": max_power,
            "max_violation": float(max_violation),
            "violation_norm": float(
                max_violation / max(1.0, max(self.cfg.peak_power_limits))
            ),
            "feasible": bool(max_violation <= 1e-8),
            "invalid_actions": int(self.invalid_actions),
        }
