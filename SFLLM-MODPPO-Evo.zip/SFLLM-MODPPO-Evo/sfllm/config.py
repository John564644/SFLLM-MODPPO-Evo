"""Configuration objects for DHFSPP instances and experiments."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class DHFSPConfig:
    """
    Distributed hybrid flow-shop instance.
    """

    name: str
    n: int
    k: int
    f: int
    machines_per_stage: list[list[int]]
    processing_times: dict[str, Any]
    energy_consumption: dict[str, Any]
    peak_power_limits: list[float] = field(default_factory=list)
    seed: int = 42

    def __post_init__(self) -> None:
        self.validate()
        if not self.peak_power_limits:
            self.peak_power_limits = self.compute_peak_power_limits()
        if len(self.peak_power_limits) != self.f:
            raise ValueError("peak_power_limits must contain one value per factory")
        if any(q <= 0 for q in self.peak_power_limits):
            raise ValueError("all peak-power limits must be positive")

    def validate(self) -> None:
        if self.n <= 0 or self.k <= 0 or self.f <= 0:
            raise ValueError("n, k and f must be positive")
        if len(self.machines_per_stage) != self.f:
            raise ValueError("machines_per_stage factory dimension mismatch")
        for fac, row in enumerate(self.machines_per_stage):
            if len(row) != self.k:
                raise ValueError(f"factory {fac} stage dimension mismatch")
            if any(int(v) <= 0 for v in row):
                raise ValueError("each factory-stage must have at least one machine")
        for j in range(self.n):
            for s in range(self.k):
                for fac in range(self.f):
                    for m in range(self.n_machines(fac, s)):
                        _ = self.p(j, s, fac, m)
                        _ = self.e(j, s, fac, m)

    def p(self, j: int, s: int, fac: int, m: int) -> float:
        return float(self.processing_times[str(j)][str(s)][str(fac)][str(m)])

    def e(self, j: int, s: int, fac: int, m: int) -> float:
        return float(self.energy_consumption[str(j)][str(s)][str(fac)][str(m)])

    def n_machines(self, fac: int, stage: int) -> int:
        return int(self.machines_per_stage[fac][stage])

    @property
    def max_machines(self) -> int:
        return max(max(row) for row in self.machines_per_stage)

    def compute_peak_power_limits(self) -> list[float]:
        """Use Q_f = mean(e) * k * mean(M), as reported in the paper."""
        rates: list[float] = []
        for j in range(self.n):
            for s in range(self.k):
                for fac in range(self.f):
                    for m in range(self.n_machines(fac, s)):
                        rates.append(self.e(j, s, fac, m))
        e_bar = sum(rates) / max(1, len(rates))
        m_bar = sum(sum(row) for row in self.machines_per_stage) / (self.f * self.k)
        q = float(e_bar * self.k * m_bar)
        return [q for _ in range(self.f)]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")

    @classmethod
    def from_json(cls, path: str | Path) -> "DHFSPConfig":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls(
            name=data.get("name", Path(path).stem),
            n=int(data["n"]),
            k=int(data["k"]),
            f=int(data["f"]),
            machines_per_stage=data["machines_per_stage"],
            processing_times=data["processing_times"],
            energy_consumption=data["energy_consumption"],
            peak_power_limits=[float(v) for v in data.get("peak_power_limits", [])],
            seed=int(data.get("seed", 42)),
        )


@dataclass
class ExperimentConfig:
    """
    Algorithm settings.
    """
    population_size: int = 200
    iterations: int = 200
    learning_rate: float = 2.15e-4
    llm_feedback_interval: int = 10
    cma_sigma: float = 0.34
    gamma: float = 0.986
    llm_batch_size: int = 5
    llm_temperature: float = 0.2
    llm_max_tokens: int = 4096
    llm_timeout_seconds: int = 60
    llm_max_attempts: int = 3
    llm_retry_seconds: float = 2.0

    injection_ratio: float = 0.10
    elite_fraction: float = 0.20
    archive_size: int = 200
    ppo_workers: int = 5
    ppo_update_epochs: int = 4
    ppo_batch_size: int = 256
    ppo_clip: float = 0.20
    gae_lambda: float = 0.95
    value_coef: float = 0.50
    entropy_coef: float = 0.01
    max_grad_norm: float = 0.50
    violation_weight: float = 2.0
    local_candidates_per_iteration: int = 10
    behavior_clone_epochs: int = 2
    hidden_size: int = 128
    seed: int = 42
    device: str = "cpu"

    def validate(self) -> None:
        if self.population_size < 2 or self.iterations < 1:
            raise ValueError("population_size >= 2 and iterations >= 1 required")
        if not (0.0 < self.injection_ratio <= 1.0):
            raise ValueError("injection_ratio must be in (0, 1]")
        if not (0.0 < self.elite_fraction <= 1.0):
            raise ValueError("elite_fraction must be in (0, 1]")
        if self.ppo_workers < 1 or self.local_candidates_per_iteration < 1:
            raise ValueError("PPO worker and candidate counts must be positive")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def quick(cls, seed: int = 42) -> "ExperimentConfig":
        return cls(
            population_size=20,
            iterations=3,
            llm_feedback_interval=2,
            ppo_workers=3,
            ppo_update_epochs=2,
            ppo_batch_size=64,
            local_candidates_per_iteration=4,
            behavior_clone_epochs=1,
            archive_size=50,
            hidden_size=64,
            seed=seed,
        )
