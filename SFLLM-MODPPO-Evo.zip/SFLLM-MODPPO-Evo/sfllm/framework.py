"""Fig. 3 closed-loop SFLLM-MODPPO-Evo framework."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np

from .config import DHFSPConfig, ExperimentConfig
from .encoding import DHFSPEncoder
from .evaluator import evaluate_vector
from .feedback import robust_feedback_and_injection
from .llm.client import CandidateProvider
from .llm.processing import CandidateProcessingStats, process_candidates
from .metrics import archive_summary
from .optim.cma_es import cma_es_step
from .optim.modppo import MODPPOTrainer
from .optim.pareto import environmental_select, update_archive


class SFLLMMODPPOEvo:
    def __init__(
        self,
        cfg: DHFSPConfig,
        experiment: ExperimentConfig,
        provider: CandidateProvider,
    ):
        experiment.validate()
        self.cfg = cfg
        self.experiment = experiment
        self.provider = provider
        self.rng = np.random.default_rng(experiment.seed)
        self.encoder = DHFSPEncoder(cfg)
        self.modppo = MODPPOTrainer(cfg, experiment)
        self.population: list[dict[str, Any]] = []
        self.archive: list[dict[str, Any]] = []
        self.history: list[dict[str, Any]] = []
        self.feedback_history: list[dict[str, Any]] = []
        self.last_llm_stats: CandidateProcessingStats | None = None

    def _provider_metadata(self) -> dict[str, Any]:
        metadata = getattr(self.provider, "last_response_metadata", None)
        if isinstance(metadata, dict):
            return dict(metadata)
        return {"provider": self.provider.__class__.__name__}

    def _evaluate_vector(self, vector: np.ndarray) -> dict[str, Any]:
        result = evaluate_vector(self.cfg, vector, seed=self.experiment.seed)
        result["source"] = "cma_es"
        result["cfg"] = self.cfg
        return result

    def initialize(self) -> None:
        payload = self.provider.generate_initial(
            self.cfg, self.experiment.llm_batch_size
        )
        llm_candidates, stats = process_candidates(
            payload,
            self.cfg,
            self.rng,
            limit=self.experiment.llm_batch_size,
        )
        for candidate in llm_candidates:
            candidate["cfg"] = self.cfg
            candidate["source"] = "llm_initial"
        self.last_llm_stats = stats
        pool = list(llm_candidates)
        while len(pool) < self.experiment.population_size:
            if llm_candidates and self.rng.random() < 0.7:
                base = np.asarray(
                    llm_candidates[len(pool) % len(llm_candidates)]["encoding"],
                    dtype=np.float64,
                )
                vector = np.clip(
                    base + self.rng.normal(0.0, 0.08, size=base.shape), 0.0, 1.0
                )
            else:
                vector = self.encoder.random_vector(self.rng)
            try:
                individual = self._evaluate_vector(vector)
            except (ValueError, RuntimeError, FloatingPointError):
                continue
            individual["source"] = "initial_population"
            pool.append(individual)
        self.population = environmental_select(
            pool, self.experiment.population_size
        )
        self.archive = update_archive(
            [], self.population, max_size=self.experiment.archive_size
        )
        warm_schedules = [candidate["schedule"] for candidate in llm_candidates]
        bc_loss = self.modppo.behavior_clone(
            warm_schedules, epochs=self.experiment.behavior_clone_epochs
        )
        self.history.append(
            {
                "iteration": 0,
                "phase": "initialization",
                "llm_stats": stats.to_dict(),
                "llm_response_metadata": self._provider_metadata(),
                "behavior_clone_loss": bc_loss,
                **archive_summary(self.archive),
            }
        )

    def run(self) -> dict[str, Any]:
        if not self.population:
            self.initialize()
        elite_size = max(
            1,
            int(round(self.experiment.elite_fraction * self.experiment.population_size)),
        )
        for iteration in range(1, self.experiment.iterations + 1):
            local_candidates, ppo_stats = self.modppo.train_iteration(iteration)
            for candidate in local_candidates:
                candidate["cfg"] = self.cfg
            self.population = environmental_select(
                self.population + local_candidates,
                self.experiment.population_size,
            )
            self.population = cma_es_step(
                self.population,
                self._evaluate_vector,
                self.rng,
                elite_size=elite_size,
                sigma=self.experiment.cma_sigma,
                target_size=self.experiment.population_size,
            )
            self.archive = update_archive(
                self.archive,
                self.population,
                max_size=self.experiment.archive_size,
            )
            feedback_stats: dict[str, int] | None = None
            if iteration % self.experiment.llm_feedback_interval == 0:
                (
                    self.population,
                    self.archive,
                    stats,
                    report,
                ) = robust_feedback_and_injection(
                    self.cfg,
                    self.experiment,
                    self.provider,
                    self.population,
                    self.archive,
                    iteration,
                    self.rng,
                    self.last_llm_stats,
                )
                self.last_llm_stats = stats
                feedback_stats = stats.to_dict()
                self.feedback_history.append(
                    {
                        "iteration": iteration,
                        "report": report,
                        "stats": feedback_stats,
                        "llm_response_metadata": self._provider_metadata(),
                    }
                )
            feasible_rate = sum(
                ind["metrics"].get("feasible", False) for ind in self.population
            ) / len(self.population)
            self.history.append(
                {
                    "iteration": iteration,
                    "phase": "optimization",
                    "feasible_rate": feasible_rate,
                    "ppo": ppo_stats,
                    "feedback": feedback_stats,
                    **archive_summary(self.archive),
                }
            )
        return self.result()

    def result(self) -> dict[str, Any]:
        pareto_solutions = []
        for ind in self.archive:
            pareto_solutions.append(
                {
                    "schedule": [
                        [[int(fac), int(machine)] for fac, machine in job_plan]
                        for job_plan in ind["schedule"]
                    ],
                    "makespan": float(ind["metrics"]["makespan"]),
                    "total_energy": float(ind["metrics"]["total_energy"]),
                    "max_power_by_factory": [
                        float(value)
                        for value in ind["metrics"].get("max_power_by_factory", [])
                    ],
                    "feasible": bool(ind["metrics"].get("feasible", False)),
                    "source": ind.get("source", "unknown"),
                }
            )
        return {
            "instance": self.cfg.name,
            "experiment_config": self.experiment.to_dict(),
            "llm_provider": self.provider.__class__.__name__,
            "pareto_solutions": pareto_solutions,
            "history": self.history,
            "feedback_history": self.feedback_history,
        }

    def save_result(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.result(), indent=2), encoding="utf-8")
