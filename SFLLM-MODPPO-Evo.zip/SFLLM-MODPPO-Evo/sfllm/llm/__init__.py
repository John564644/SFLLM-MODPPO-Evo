"""LLM prompting, API adapter, and candidate validation."""

from .client import CandidateProvider, OfflineCandidateProvider, OpenAICompatibleProvider
from .processing import CandidateProcessingStats, process_candidates

__all__ = [
    "CandidateProvider",
    "OfflineCandidateProvider",
    "OpenAICompatibleProvider",
    "CandidateProcessingStats",
    "process_candidates",
]
