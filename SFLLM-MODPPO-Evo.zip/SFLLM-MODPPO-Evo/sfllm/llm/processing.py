"""
JSON parsing, deterministic repair, validation, and duplicate removal."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from typing import Any

import numpy as np

from ..config import DHFSPConfig
from ..encoding import DHFSPEncoder, Schedule, schedule_key
from ..evaluator import evaluate_schedule


@dataclass
class CandidateProcessingStats:
    returned: int = 0
    parsed: int = 0
    directly_valid: int = 0
    repaired: int = 0
    feasible: int = 0
    duplicates: int = 0
    rejected: int = 0
    injected: int = 0

    def to_dict(self) -> dict[str, int]:
        return asdict(self)


def parse_json_candidates(payload: Any) -> list[Any]:
    if isinstance(payload, list):
        return payload
    if not isinstance(payload, str):
        return []
    text = payload.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].startswith("```"):
            lines = lines[:-1]
        text = "\n".join(lines).strip()
    try:
        data = json.loads(text)
        return data if isinstance(data, list) else []
    except json.JSONDecodeError:
        start = text.find("[")
        if start < 0:
            return []
        depth = 0
        in_string = False
        escaped = False
        for idx in range(start, len(text)):
            char = text[idx]
            if in_string:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    in_string = False
                continue
            if char == '"':
                in_string = True
            elif char == "[":
                depth += 1
            elif char == "]":
                depth -= 1
                if depth == 0:
                    try:
                        data = json.loads(text[start : idx + 1])
                        return data if isinstance(data, list) else []
                    except json.JSONDecodeError:
                        return []
        return []


def _coerce_int(value: Any, default: int = 0) -> tuple[int, bool]:
    if isinstance(value, bool):
        return default, True
    if isinstance(value, (int, np.integer)):
        return int(value), False
    if isinstance(value, float) and np.isfinite(value):
        return int(round(value)), not float(value).is_integer()
    try:
        parsed = int(str(value).strip())
        return parsed, True
    except (ValueError, TypeError):
        return default, True


def repair_candidate(
    candidate: Any, cfg: DHFSPConfig, rng: np.random.Generator
) -> tuple[Schedule, bool, bool]:
    """
    Return schedule, directly_valid, changed.
    """
    changed = False
    directly_valid = True
    if not isinstance(candidate, list):
        candidate = []
        changed = directly_valid = True
    if len(candidate) != cfg.n:
        changed = True
        directly_valid = False
    schedule: Schedule = []
    for j in range(cfg.n):
        raw_job = candidate[j] if j < len(candidate) and isinstance(candidate[j], list) else []
        if len(raw_job) != cfg.k:
            changed = True
            directly_valid = False
        supplied_factories: list[int] = []
        for s in range(min(cfg.k, len(raw_job))):
            pair = raw_job[s]
            if isinstance(pair, (list, tuple)) and len(pair) >= 2:
                fac, coerced = _coerce_int(pair[0])
                if coerced:
                    changed = True
                    directly_valid = False
                if 0 <= fac < cfg.f:
                    supplied_factories.append(fac)
                else:
                    changed = True
                    directly_valid = False
            else:
                changed = True
                directly_valid = False
        if supplied_factories:
            counts = np.bincount(supplied_factories, minlength=cfg.f)
            best_count = counts.max()
            fac_choices = np.flatnonzero(counts == best_count)
            fac = int(fac_choices[0])
            if any(x != fac for x in supplied_factories):
                changed = True
                directly_valid = False
        else:
            # Choose a factory by average normalized processing-energy cost.
            costs = []
            for possible_fac in range(cfg.f):
                cost = 0.0
                for s in range(cfg.k):
                    options = [
                        cfg.p(j, s, possible_fac, m) * cfg.e(j, s, possible_fac, m)
                        for m in range(cfg.n_machines(possible_fac, s))
                    ]
                    cost += min(options)
                costs.append(cost)
            fac = int(np.argmin(costs))
            changed = True
            directly_valid = False
        job_plan: list[tuple[int, int]] = []
        for s in range(cfg.k):
            pair = raw_job[s] if s < len(raw_job) else None
            machine: int | None = None
            if isinstance(pair, (list, tuple)) and len(pair) >= 2:
                raw_machine, coerced = _coerce_int(pair[1])
                if coerced:
                    changed = True
                    directly_valid = False
                if 0 <= raw_machine < cfg.n_machines(fac, s):
                    machine = raw_machine
                else:
                    changed = True
                    directly_valid = False
            else:
                changed = True
                directly_valid = False
            if machine is None:
                option_scores = []
                p_values = [cfg.p(j, s, fac, m) for m in range(cfg.n_machines(fac, s))]
                e_values = [cfg.e(j, s, fac, m) for m in range(cfg.n_machines(fac, s))]
                p_min, p_max = min(p_values), max(p_values)
                e_min, e_max = min(e_values), max(e_values)
                for m in range(cfg.n_machines(fac, s)):
                    p_norm = (p_values[m] - p_min) / max(1e-12, p_max - p_min)
                    e_norm = (e_values[m] - e_min) / max(1e-12, e_max - e_min)
                    option_scores.append(p_norm + e_norm + 1e-9 * rng.random())
                machine = int(np.argmin(option_scores))
            job_plan.append((fac, machine))
        schedule.append(job_plan)
    return schedule, directly_valid and not changed, changed


def process_candidates(
    payload: Any,
    cfg: DHFSPConfig,
    rng: np.random.Generator,
    *,
    limit: int | None = None,
) -> tuple[list[dict[str, Any]], CandidateProcessingStats]:
    raw_candidates = parse_json_candidates(payload)
    stats = CandidateProcessingStats(returned=len(raw_candidates))
    encoder = DHFSPEncoder(cfg)
    accepted: list[dict[str, Any]] = []
    seen: set[tuple[int, ...]] = set()
    for raw in raw_candidates[:limit]:
        try:
            schedule, directly_valid, changed = repair_candidate(raw, cfg, rng)
            stats.parsed += 1
            if directly_valid:
                stats.directly_valid += 1
            if changed:
                stats.repaired += 1
            # Encoding-decoding
            encoding = encoder.encode(schedule)
            normalized_schedule = encoder.decode(encoding)
            metrics = evaluate_schedule(cfg, normalized_schedule, seed=cfg.seed)
            key = schedule_key(normalized_schedule)
            if key in seen:
                stats.duplicates += 1
                continue
            seen.add(key)
            if not metrics.get("feasible", False):
                stats.rejected += 1
                continue
            stats.feasible += 1
            accepted.append(
                {
                    "encoding": encoding,
                    "schedule": normalized_schedule,
                    "metrics": metrics,
                    "source": "llm",
                    "repaired": changed,
                }
            )
        except (ValueError, TypeError, RuntimeError, KeyError, IndexError):
            stats.rejected += 1
    return accepted, stats
