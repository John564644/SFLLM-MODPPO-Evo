"""OpenAI-compatible LLM adapter and deterministic offline smoke-test provider."""

from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from abc import ABC, abstractmethod
from typing import Any

import numpy as np

from ..config import DHFSPConfig, ExperimentConfig
from .prompts import SYSTEM_PROMPT, feedback_prompt, initial_prompt


class CandidateProvider(ABC):
    @abstractmethod
    def generate_initial(self, cfg: DHFSPConfig, batch_size: int) -> Any:
        raise NotImplementedError

    @abstractmethod
    def generate_feedback(
        self, cfg: DHFSPConfig, batch_size: int, feedback: dict[str, Any]
    ) -> Any:
        raise NotImplementedError


class OpenAICompatibleProvider(CandidateProvider):
    """Chat-completions client with the fixed settings reported in the response."""

    def __init__(
        self,
        experiment: ExperimentConfig,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        model: str | None = None,
    ):
        self.experiment = experiment
        self.api_key = api_key or os.getenv("LLM_API_KEY", "")
        self.base_url = (base_url or os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")).rstrip("/")
        self.model = model or os.getenv("LLM_MODEL", "")
        if not self.api_key:
            raise ValueError("LLM_API_KEY is required for api mode")
        if not self.model:
            raise ValueError("LLM_MODEL is required for api mode")
        self.last_response_metadata: dict[str, Any] = {}

    def _request(self, user_prompt: str) -> str:
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": self.experiment.llm_temperature,
            "max_tokens": self.experiment.llm_max_tokens,
            "stream": False,
        }
        body = json.dumps(payload).encode("utf-8")
        url = f"{self.base_url}/chat/completions"
        error: Exception | None = None
        for attempt in range(1, self.experiment.llm_max_attempts + 1):
            request = urllib.request.Request(
                url,
                data=body,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                method="POST",
            )
            try:
                with urllib.request.urlopen(
                    request, timeout=self.experiment.llm_timeout_seconds
                ) as response:
                    data = json.loads(response.read().decode("utf-8"))
                self.last_response_metadata = {
                    "model": data.get("model"),
                    "usage": data.get("usage", {}),
                    "attempt": attempt,
                }
                return str(data["choices"][0]["message"]["content"])
            except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, KeyError, ValueError) as exc:
                error = exc
                if attempt < self.experiment.llm_max_attempts:
                    time.sleep(self.experiment.llm_retry_seconds)
        raise RuntimeError(f"LLM request failed after retries: {error}")

    def generate_initial(self, cfg: DHFSPConfig, batch_size: int) -> str:
        return self._request(initial_prompt(cfg, batch_size))

    def generate_feedback(
        self, cfg: DHFSPConfig, batch_size: int, feedback: dict[str, Any]
    ) -> str:
        return self._request(feedback_prompt(cfg, batch_size, feedback))


class OfflineCandidateProvider(CandidateProvider):
    """
    Seeded local provider for tests when no API credentials are available.
    """

    def __init__(self, seed: int = 42):
        self.rng = np.random.default_rng(seed)

    def _generate(
        self,
        cfg: DHFSPConfig,
        batch_size: int,
        feedback: dict[str, Any] | None = None,
    ) -> list[list[list[list[int]]]]:
        result: list[list[list[list[int]]]] = []
        overloaded_factories = set()
        if feedback:
            loads = feedback.get("factory_job_counts", [])
            if loads:
                threshold = float(np.mean(loads) + np.std(loads))
                overloaded_factories = {i for i, value in enumerate(loads) if value > threshold}
        for candidate_index in range(batch_size):
            weight = (candidate_index + 1) / (batch_size + 1)
            candidate: list[list[list[int]]] = []
            factory_counts = np.zeros(cfg.f, dtype=float)
            for j in range(cfg.n):
                factory_scores = []
                for fac in range(cfg.f):
                    score = 0.0
                    for s in range(cfg.k):
                        values = []
                        for machine in range(cfg.n_machines(fac, s)):
                            p = cfg.p(j, s, fac, machine)
                            e = cfg.e(j, s, fac, machine)
                            values.append(weight * p + (1.0 - weight) * p * e / 100.0)
                        score += min(values)
                    score *= 1.0 + 0.04 * factory_counts[fac]
                    if fac in overloaded_factories:
                        score *= 1.15
                    score += self.rng.normal(0.0, max(1e-6, abs(score) * 0.02))
                    factory_scores.append(score)
                fac = int(np.argmin(factory_scores))
                factory_counts[fac] += 1
                job_plan: list[list[int]] = []
                for s in range(cfg.k):
                    options = []
                    for machine in range(cfg.n_machines(fac, s)):
                        p = cfg.p(j, s, fac, machine)
                        e = cfg.e(j, s, fac, machine)
                        score = weight * p + (1.0 - weight) * p * e / 100.0
                        score += self.rng.normal(0.0, max(1e-6, abs(score) * 0.03))
                        options.append(score)
                    job_plan.append([fac, int(np.argmin(options))])
                candidate.append(job_plan)
            result.append(candidate)
        return result

    def generate_initial(self, cfg: DHFSPConfig, batch_size: int) -> Any:
        return self._generate(cfg, batch_size)

    def generate_feedback(
        self, cfg: DHFSPConfig, batch_size: int, feedback: dict[str, Any]
    ) -> Any:
        return self._generate(cfg, batch_size, feedback)
