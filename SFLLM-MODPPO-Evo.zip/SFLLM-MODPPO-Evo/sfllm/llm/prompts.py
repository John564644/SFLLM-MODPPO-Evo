"""Formal DHFSPP prompts aligned with the revised response letter."""

from __future__ import annotations

import json
from typing import Any

from ..config import DHFSPConfig

SYSTEM_PROMPT = """You are a constrained scheduling candidate generator for the distributed hybrid flow shop scheduling problem with factory-level peak-power limits. Generate only resource-assignment matrices. Never generate code, explanations, start times, objective values, feasibility labels, or Markdown. Return only valid JSON."""


def serialize_instance(cfg: DHFSPConfig) -> dict[str, Any]:
    eligible_options: list[list[list[dict[str, float | int]]]] = []
    for j in range(cfg.n):
        job_options: list[list[dict[str, float | int]]] = []
        for s in range(cfg.k):
            stage_options: list[dict[str, float | int]] = []
            for fac in range(cfg.f):
                for machine in range(cfg.n_machines(fac, s)):
                    stage_options.append(
                        {
                            "factory_id": fac,
                            "machine_id": machine,
                            "processing_time": cfg.p(j, s, fac, machine),
                            "energy_rate": cfg.e(j, s, fac, machine),
                        }
                    )
            job_options.append(stage_options)
        eligible_options.append(job_options)
    return {
        "name": cfg.name,
        "n_jobs": cfg.n,
        "n_stages": cfg.k,
        "n_factories": cfg.f,
        "machines_per_stage": cfg.machines_per_stage,
        "peak_power_limits": cfg.peak_power_limits,
        "eligible_options": eligible_options,
    }


def initial_prompt(cfg: DHFSPConfig, batch_size: int) -> str:
    instance_json = json.dumps(serialize_instance(cfg), separators=(",", ":"))
    return f"""Generate exactly {batch_size} candidate assignment matrices for the DHFSPP instance provided below.

FORMAL PROBLEM DEFINITION
Jobs: J = 0, ..., n_jobs - 1.
Stages: S = 0, ..., n_stages - 1.
Factories: F = 0, ..., n_factories - 1.
Every job must visit all stages in ascending stage order.
Every job must be assigned to exactly one factory and remain in that factory throughout all stages.
For every job and stage, exactly one eligible machine must be selected.
The deterministic decoder, rather than the LLM, enforces processing precedence, machine non-overlap, factory and machine eligibility, hard factory-level peak-power constraints, makespan calculation, and total energy-consumption calculation.
The two minimized objectives are makespan and total energy consumption.

DECISION REPRESENTATION
candidate[j][s] = [factory_id, machine_id]
For each job, factory_id must be identical at every stage.

INSTANCE DATA
{instance_json}

CANDIDATE-GENERATION REQUIREMENTS
1. Return exactly {batch_size} candidates.
2. Every candidate must contain exactly n_jobs job entries.
3. Every job entry must contain exactly n_stages stage entries.
4. Every stage entry must contain exactly two integers: [factory_id, machine_id].
5. Use only factory-machine pairs appearing in eligible_options[job_id][stage_id].
6. Assign all stages of one job to the same factory.
7. Consider both processing_time and energy_rate.
8. Avoid excessive concentration on one factory or machine unless supported by data.
9. Preserve diversity and do not return duplicates.
10. Do not generate timing, objectives, power profiles, feasibility labels, explanations, Markdown, or code.

REQUIRED OUTPUT
Return only a JSON list of exactly {batch_size} candidate matrices."""


def feedback_prompt(cfg: DHFSPConfig, batch_size: int, feedback: dict[str, Any]) -> str:
    base = initial_prompt(cfg, batch_size)
    feedback_json = json.dumps(feedback, separators=(",", ":"), default=float)
    return f"""{base}

CURRENT DETERMINISTIC SEARCH FEEDBACK
{feedback_json}

IMPROVEMENT REQUIREMENTS
1. Preserve all dimension, eligibility, and single-factory requirements.
2. Seek an improved makespan-energy trade-off rather than only one objective.
3. Reduce assignments to factories or machines identified as excessively loaded.
4. Avoid patterns frequently duplicated, rejected, or substantially repaired.
5. When feasible-candidate rate is low, prefer lower energy-rate or lower-power eligible machines.
6. Generate candidates that differ from recent candidates and one another.
7. Do not predict makespan, energy, feasibility, or violations.
8. Return only the pure JSON list."""
