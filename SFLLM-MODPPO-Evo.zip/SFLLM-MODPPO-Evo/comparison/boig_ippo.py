#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
BOIG_IPPO_M.py

把两篇论文中的算法思想改造成适用于：
    “带峰值功率约束的分布式混合流水车间调度问题（DHFSPP）”
的 Python 对比算法实现。

实现的算法：
    1) BOIG-DHFSPP:
       基于 Wu & Zhao (2025) 的 balance-oriented iterative greedy (BOIG)。
       保留二维工厂序列编码、NEH 类初始化、负载均衡扰动、负载导向破坏-重构、
       跨工厂局部搜索、改进 Metropolis 接受准则；解码阶段将论文中的阻塞导向
       SA decoding 改造成峰值功率可行 list-scheduling 解码。

    2) IPPO-DHFSPP:
       基于 Sun et al. (2025) 的 multi-agent IPPO 思想。
       为了作为可直接运行的对比算法，本文件实现一个无需预训练模型的
       “IPPO-inspired rollout + policy-improvement”版本：
       多工厂智能体异步从候选工件池中选工件；每个智能体维护两套偏好权重，
       交替 episode 更新，使用多目标 reward 的 softmax policy improvement。
       该实现保持论文中的关键思想：多智能体、异步决策、EDD 截断候选池、
       两套策略、多目标动态权重、FAM/peak-aware machine selection。

输出格式：
    与你现有 comparison.py / dcma_comparison_algorithms2...py 的实验输出一致：
        final_results.json
        checkpoint.json
    每个算法包含：
        runs, pareto_fronts, hv_scores, igd_scores, sp_scores, runtimes, statistics

运行示例：
    python BOIG_IPPO_M.py \
        --instance /mnt/data/S1_10x2x2.json \
        --output_dir /mnt/data/paper_alg_results \
        --algorithms BOIG IPPO \
        --pop_size 30 \
        --max_gen 50 \
        --n_runs 3 \
        --seed 42

也可以只当作模块导入：
    from paper_algorithms_boig_ippo_for_dhfspp import BOIG_DHFSPP, IPPO_DHFSPP
"""

import argparse
import copy
import datetime
import json
import math
import os
import random

import tt
import time
import traceback
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Optional

import numpy as np


# =============================================================================
# 基础数据结构
# =============================================================================

@dataclass
class Individual:
    """与现有对比算法兼容的个体结构。"""
    schedule: Any
    objectives: Tuple[float, float]  # (makespan, total_energy)
    rank: int = 0
    crowding_distance: float = 0.0
    dominated_count: int = 0
    dominating_set: List[Any] = field(default_factory=list)
    fitness: float = 0.0


# =============================================================================
# 数据与评价器
# =============================================================================

class DHHFSPPInstance:
    """兼容你的 JSON 数据集格式的实例读取器。"""

    def __init__(self, data: Dict[str, Any]):
        self.data = data
        self.name = data.get("name", "unknown")
        self.n = int(data["n"])
        self.k = int(data["k"])
        self.f = int(data["f"])
        self.machines_per_stage = data["machines_per_stage"]
        self.processing_times = data["processing_times"]
        self.energy_consumption = data.get("energy_consumption", data.get("energy_consumptions"))

        if self.energy_consumption is None:
            raise KeyError("instance must contain 'energy_consumption' or 'energy_consumptions'")

        self.operations_per_stage = []
        for s in range(self.k):
            try:
                self.operations_per_stage.append(len(self.processing_times[str(0)][str(s)]))
            except Exception:
                self.operations_per_stage.append(1)

    def n_machines(self, factory: int, stage: int) -> int:
        return int(self.machines_per_stage[factory][stage])

    def _get_nested_numeric(self, block: Any, factory: int, machine: int) -> float:
        """强兼容提取 pt/en：支持 dict/list、含/不含 factory 维度的格式。"""
        f_key, m_key = str(factory), str(machine)

        def as_num(x):
            if isinstance(x, (int, float, np.integer, np.floating)):
                return float(x)
            if isinstance(x, str):
                return float(x)
            raise TypeError

        def rec(x):
            try:
                return as_num(x)
            except Exception:
                pass

            if isinstance(x, list):
                # 优先认为第一层是 factory，第二层是 machine。
                if len(x) > factory:
                    try:
                        return rec(x[factory])
                    except Exception:
                        pass
                if len(x) > machine:
                    try:
                        return rec(x[machine])
                    except Exception:
                        pass
                for v in x:
                    try:
                        return rec(v)
                    except Exception:
                        continue

            if isinstance(x, dict):
                # 叶子直接包含 machine
                if m_key in x and not isinstance(x[m_key], (dict, list)):
                    return float(x[m_key])
                # 优先 factory 分支
                if f_key in x:
                    try:
                        return rec(x[f_key])
                    except Exception:
                        pass
                # 其次 machine 分支
                if m_key in x:
                    try:
                        return rec(x[m_key])
                    except Exception:
                        pass
                for v in x.values():
                    try:
                        return rec(v)
                    except Exception:
                        continue

            raise KeyError("No numeric leaf found")

        return float(rec(block))

    def pt_energy(self, job: int, stage: int, op: int, factory: int, machine: int) -> Tuple[float, float]:
        pt_block = self.processing_times[str(job)][str(stage)][str(op)]
        en_block = self.energy_consumption[str(job)][str(stage)][str(op)]
        return (
            self._get_nested_numeric(pt_block, factory, machine),
            self._get_nested_numeric(en_block, factory, machine),
        )

    def min_pt(self, job: int, stage: Optional[int] = None) -> float:
        stages = range(self.k) if stage is None else [stage]
        total = 0.0
        for s in stages:
            best = float("inf")
            for f in range(self.f):
                for m in range(self.n_machines(f, s)):
                    pt, _ = self.pt_energy(job, s, 0, f, m)
                    best = min(best, pt)
            total += best
        return total

    def min_energy_work(self, job: int, stage: Optional[int] = None) -> float:
        stages = range(self.k) if stage is None else [stage]
        total = 0.0
        for s in stages:
            best = float("inf")
            for f in range(self.f):
                for m in range(self.n_machines(f, s)):
                    pt, er = self.pt_energy(job, s, 0, f, m)
                    best = min(best, pt * er)
            total += best
        return total

    def estimate_peak_limit(self, multiplier: float = 3.0) -> float:
        vals = []
        for j in range(self.n):
            for s in range(self.k):
                for f in range(self.f):
                    for m in range(self.n_machines(f, s)):
                        try:
                            _, er = self.pt_energy(j, s, 0, f, m)
                            vals.append(er)
                        except Exception:
                            pass
        return float(np.mean(vals) * multiplier) if vals else 1e9


class PeakPowerScheduleEvaluator:
    """
    峰值功率约束评价器。
    - 目标：makespan 与 total energy。
    - 约束：任意时刻运行功率之和 <= peak_power_limit。
    - 处理方式：若新操作直接开工会超峰值，则将其开始时间延后到下一个可能事件点。
    """

    def __init__(self, instance: Dict[str, Any], peak_power_limit: Optional[float] = None):
        self.inst = DHHFSPPInstance(instance)
        self.peak_power_limit = (
            self.inst.estimate_peak_limit() if peak_power_limit is None else float(peak_power_limit)
        )

    def _power_at(self, t: float, events: List[Tuple[float, float, float]]) -> float:
        return sum(p for st, ft, p in events if st <= t < ft)

    def _find_feasible_start(
        self,
        earliest: float,
        duration: float,
        power: float,
        events: List[Tuple[float, float, float]],
    ) -> Tuple[float, float]:
        """返回满足峰值约束的开始时间和最大超限量。"""
        if power > self.peak_power_limit:
            # 单个操作功率已经超过 Q，无法通过延后完全修复；仍调度但记录违反。
            return earliest, power - self.peak_power_limit

        candidates = sorted({earliest} | {ft for st, ft, _ in events if ft >= earliest} | {st for st, ft, _ in events if st >= earliest})
        t = earliest
        max_violation = 0.0
        checked = 0

        while checked < 10000:
            checked += 1
            relevant_points = [t, t + duration]
            for st, ft, _ in events:
                if t < st < t + duration:
                    relevant_points.append(st)
                if t < ft < t + duration:
                    relevant_points.append(ft)

            violation = 0.0
            feasible = True
            for pnt in relevant_points:
                pwr = self._power_at(pnt + 1e-9, events) + power
                if pwr > self.peak_power_limit + 1e-9:
                    feasible = False
                    violation = max(violation, pwr - self.peak_power_limit)
            if feasible:
                return t, 0.0

            max_violation = max(max_violation, violation)
            future_finishes = sorted(ft for st, ft, _ in events if ft > t + 1e-9)
            if not future_finishes:
                return t, max_violation
            t = future_finishes[0]

        return t, max_violation

    def evaluate_sequence_solution(self, sequence: List[List[int]]) -> Dict[str, Any]:
        """
        sequence[f] 是工厂 f 的工件加工顺序。
        每个工件一旦分配到某工厂，所有阶段均在该工厂处理；
        每阶段机器由 peak-aware earliest feasible machine rule 选择。
        """
        inst = self.inst
        machine_ready = {
            (f, s, m): 0.0
            for f in range(inst.f)
            for s in range(inst.k)
            for m in range(inst.n_machines(f, s))
        }
        machine_load = {key: 0.0 for key in machine_ready}
        job_ready = [0.0 for _ in range(inst.n)]
        events: List[Tuple[float, float, float]] = []
        assignment = [[[] for _ in range(inst.k)] for _ in range(inst.n)]
        total_energy = 0.0
        max_violation = 0.0
        power_violations = 0

        seen = set()
        for f in range(inst.f):
            for j in sequence[f]:
                if j in seen:
                    continue
                seen.add(j)
                for s in range(inst.k):
                    best = None
                    for m in range(inst.n_machines(f, s)):
                        pt, er = inst.pt_energy(j, s, 0, f, m)
                        earliest = max(job_ready[j], machine_ready[(f, s, m)])
                        start, violation = self._find_feasible_start(earliest, pt, er, events)
                        finish = start + pt
                        # 机器选择指标：优先可行完成早，其次能耗低、负载低。
                        score = (finish, violation, er * pt, machine_load[(f, s, m)])
                        if best is None or score < best[0]:
                            best = (score, m, pt, er, start, finish, violation)
                    _, m, pt, er, start, finish, violation = best
                    machine_ready[(f, s, m)] = finish
                    machine_load[(f, s, m)] += pt
                    job_ready[j] = finish
                    assignment[j][s] = [(f, m)]
                    events.append((start, finish, er))
                    total_energy += er * pt
                    if violation > 1e-9:
                        power_violations += 1
                        max_violation = max(max_violation, violation)

        # 若有遗漏工件，追加到最短负载工厂，保证鲁棒性。
        missing = [j for j in range(inst.n) if j not in seen]
        if missing:
            extra = [list(x) for x in sequence]
            loads = [len(extra[f]) for f in range(inst.f)]
            for j in missing:
                f = int(np.argmin(loads))
                extra[f].append(j)
                loads[f] += 1
            return self.evaluate_sequence_solution(extra)

        return {
            "makespan": float(max(job_ready) if job_ready else 0.0),
            "total_energy": float(total_energy),
            "feasible": bool(power_violations == 0),
            "power_violations": int(power_violations),
            "max_violation": float(max_violation),
            "assignment": assignment,
            "events": events,
        }

    def evaluate(self, schedule: Any) -> Dict[str, Any]:
        """
        兼容两类输入：
            1) {"sequence": [[...], ...]}
            2) 现有代码的 schedule[j][s][o] = (factory, machine)
        """
        if isinstance(schedule, dict) and "sequence" in schedule:
            return self.evaluate_sequence_solution(schedule["sequence"])

        # 现有代码 assignment-only 格式：按 job id 顺序调度。
        inst = self.inst
        seq = [[] for _ in range(inst.f)]
        for j in range(inst.n):
            try:
                f = int(schedule[j][0][0][0])
            except Exception:
                f = j % inst.f
            f = max(0, min(inst.f - 1, f))
            seq[f].append(j)
        return self.evaluate_sequence_solution(seq)


# =============================================================================
# 多目标工具
# =============================================================================

def dominates(a: Tuple[float, float], b: Tuple[float, float]) -> bool:
    return (a[0] <= b[0] and a[1] <= b[1]) and (a[0] < b[0] or a[1] < b[1])


def nondominated(individuals: List[Individual]) -> List[Individual]:
    front = []
    for i, ind in enumerate(individuals):
        bad = False
        for k, other in enumerate(individuals):
            if i != k and dominates(other.objectives, ind.objectives):
                bad = True
                break
        if not bad and all(not (abs(ind.objectives[0] - x.objectives[0]) < 1e-9 and abs(ind.objectives[1] - x.objectives[1]) < 1e-9) for x in front):
            front.append(ind)
    front.sort(key=lambda x: (x.objectives[0], x.objectives[1]))
    return front


def scalar_fitness(obj: Tuple[float, float], ref: Tuple[float, float], weight: Tuple[float, float]) -> float:
    return weight[0] * obj[0] / max(1e-9, ref[0]) + weight[1] * obj[1] / max(1e-9, ref[1])


class PerformanceMetrics:
    """保持现有对比代码风格的指标计算。"""

    @staticmethod
    def hypervolume(front: List[Individual], reference_point: Optional[Tuple[float, float]] = None) -> float:
        if not front:
            return 0.0
        pts = sorted([ind.objectives for ind in nondominated(front)], key=lambda x: x[0])
        if reference_point is None:
            reference_point = (max(p[0] for p in pts) * 1.1 + 1e-9, max(p[1] for p in pts) * 1.1 + 1e-9)
        hv = 0.0
        prev_y = reference_point[1]
        for x, y in pts:
            hv += max(0.0, reference_point[0] - x) * max(0.0, prev_y - y)
            prev_y = min(prev_y, y)
        return float(hv)

    @staticmethod
    def igd(front: List[Individual], reference_front: List[Tuple[float, float]]) -> float:
        if not front or not reference_front:
            return float("inf")
        pts = np.array([ind.objectives for ind in front], dtype=float)
        refs = np.array(reference_front, dtype=float)
        dists = []
        for r in refs:
            dists.append(float(np.min(np.linalg.norm(pts - r, axis=1))))
        return float(np.mean(dists))

    @staticmethod
    def spacing(front: List[Individual]) -> float:
        if len(front) <= 1:
            return 0.0
        pts = np.array([ind.objectives for ind in front], dtype=float)
        ds = []
        for i in range(len(pts)):
            d = np.min([np.sum(np.abs(pts[i] - pts[j])) for j in range(len(pts)) if i != j])
            ds.append(float(d))
        return float(np.sqrt(np.mean((np.array(ds) - np.mean(ds)) ** 2)))


# =============================================================================
# BOIG-DHFSPP
# =============================================================================

class BOIG_DHFSPP:
    """
    Balance-Oriented Iterative Greedy for DHFSPP.
    论文 DHHFSPB -> 本问题 DHFSPP 的关键适配：
        - blocking-oriented SA machine index 中的 blocking term 用“峰值约束导致的等待/机器负载”替代；
        - Cmax 单目标接受准则改成双目标归一化 scalar fitness；
        - 保留负载均衡的跨工厂 perturb / destruction-construction / local search。
    """

    def __init__(
        self,
        instance: Dict[str, Any],
        pop_size: int = 50,
        max_gen: int = 100,
        destruction_jobs: Optional[int] = None,
        initial_temperature: float = 0.2,
        cooling_rate: float = 0.995,
        sigmoid_k: float = 8.0,
        peak_power_limit: Optional[float] = None,
        seed: Optional[int] = None,
    ):
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
        self.raw = instance
        self.inst = DHHFSPPInstance(instance)
        self.pop_size = int(pop_size)
        self.max_gen = int(max_gen)
        self.d = destruction_jobs if destruction_jobs is not None else max(1, min(5, self.inst.n // 5))
        self.T = float(initial_temperature)
        self.cooling_rate = float(cooling_rate)
        self.sigmoid_k = float(sigmoid_k)
        self.evaluator = PeakPowerScheduleEvaluator(instance, peak_power_limit)
        self.archive: List[Individual] = []

    def _normalize_sequence(self, sequence: List[List[int]]) -> List[List[int]]:
        seen = set()
        out = [[] for _ in range(self.inst.f)]
        for f in range(self.inst.f):
            for j in sequence[f]:
                if 0 <= int(j) < self.inst.n and int(j) not in seen:
                    out[f].append(int(j))
                    seen.add(int(j))
        for j in range(self.inst.n):
            if j not in seen:
                out[j % self.inst.f].append(j)
        return out

    def _decode(self, sequence: List[List[int]]) -> Individual:
        seq = self._normalize_sequence(sequence)
        res = self.evaluator.evaluate_sequence_solution(seq)
        ind = Individual(
            schedule={"sequence": seq, "assignment": res.get("assignment")},
            objectives=(res["makespan"], res["total_energy"]),
        )
        # 峰值不可行时加轻惩罚，正常情况下 evaluator 会通过延后保证可行。
        if not res.get("feasible", True):
            penalty = 1.0 + 0.05 * res.get("power_violations", 0) + 0.01 * res.get("max_violation", 0)
            ind.objectives = (ind.objectives[0] * penalty, ind.objectives[1] * penalty)
        return ind

    def _factory_makespans(self, sequence: List[List[int]]) -> List[float]:
        vals = []
        for f in range(self.inst.f):
            sub = [[] for _ in range(self.inst.f)]
            sub[f] = list(sequence[f])
            vals.append(self.evaluator.evaluate_sequence_solution(sub)["makespan"] if sub[f] else 0.0)
        return vals

    def _neh_order(self, mode: str) -> List[int]:
        jobs = list(range(self.inst.n))
        if mode == "NEH_F":
            jobs.sort(key=lambda j: self.inst.min_pt(j), reverse=True)
        elif mode == "NEH_DBE":
            jobs.sort(key=lambda j: self.inst.min_pt(j), reverse=True)
            chunks = [jobs[i::self.inst.f] for i in range(self.inst.f)]
            new = []
            for ch in chunks:
                l, r = 0, len(ch) - 1
                while l <= r:
                    new.append(ch[l]); l += 1
                    if l <= r:
                        new.append(ch[r]); r -= 1
            jobs = new
        elif mode == "NEH_BE":
            jobs.sort(key=lambda j: self.inst.min_pt(j), reverse=True)
            new = []
            l, r = 0, len(jobs) - 1
            while l <= r:
                new.append(jobs[l]); l += 1
                if l <= r:
                    new.append(jobs[r]); r -= 1
            jobs = new
        else:
            random.shuffle(jobs)
        return jobs

    def _insert_best(self, sequence: List[List[int]], job: int, ref: Tuple[float, float]) -> List[List[int]]:
        best_seq = None
        best_fit = float("inf")
        w = (0.5, 0.5)
        for f in range(self.inst.f):
            for pos in range(len(sequence[f]) + 1):
                cand = copy.deepcopy(sequence)
                cand[f].insert(pos, job)
                ind = self._decode(cand)
                fit = scalar_fitness(ind.objectives, ref, w)
                if fit < best_fit:
                    best_fit = fit
                    best_seq = cand
        return best_seq

    def _initial_solution(self, mode: str) -> List[List[int]]:
        order = self._neh_order(mode)
        seq = [[] for _ in range(self.inst.f)]
        ref = (sum(self.inst.min_pt(j) for j in range(self.inst.n)), sum(self.inst.min_energy_work(j) for j in range(self.inst.n)))
        for idx, j in enumerate(order[:self.inst.f]):
            seq[idx % self.inst.f].append(j)
        for j in order[self.inst.f:]:
            seq = self._insert_best(seq, j, ref)
        return self._normalize_sequence(seq)

    def _random_solution(self) -> List[List[int]]:
        jobs = list(range(self.inst.n))
        random.shuffle(jobs)
        seq = [[] for _ in range(self.inst.f)]
        for j in jobs:
            seq[random.randrange(self.inst.f)].append(j)
        return seq

    def _perturbation(self, sequence: List[List[int]]) -> List[List[int]]:
        seq = copy.deepcopy(sequence)
        for _ in range(max(1, self.inst.f)):
            loads = self._factory_makespans(seq)
            fmax, fmin = int(np.argmax(loads)), int(np.argmin(loads))
            if not seq[fmax]:
                break
            old = self._decode(seq).objectives

            # max-min swap
            cand = copy.deepcopy(seq)
            p1 = random.randrange(len(cand[fmax]))
            if cand[fmin]:
                p2 = random.randrange(len(cand[fmin]))
                cand[fmax][p1], cand[fmin][p2] = cand[fmin][p2], cand[fmax][p1]
                if dominates(self._decode(cand).objectives, old) or random.random() < 0.2:
                    seq = cand

            # max-min insert
            cand = copy.deepcopy(seq)
            if cand[fmax]:
                p1 = random.randrange(len(cand[fmax]))
                job = cand[fmax].pop(p1)
                p2 = random.randrange(len(cand[fmin]) + 1)
                cand[fmin].insert(p2, job)
                new = self._decode(cand).objectives
                if dominates(new, old) or sum(self._factory_makespans(cand)) < sum(self._factory_makespans(seq)):
                    seq = cand
        return self._normalize_sequence(seq)

    def _destruction_construction(self, sequence: List[List[int]], ref: Tuple[float, float]) -> List[List[int]]:
        seq = copy.deepcopy(sequence)
        removed = []
        for _ in range(min(self.d, self.inst.n)):
            loads = self._factory_makespans(seq)
            # 负载越高越容易被破坏，同时保留随机性。
            probs = np.array(loads, dtype=float) + 1e-6
            probs = probs / probs.sum() if probs.sum() > 0 else np.ones(self.inst.f) / self.inst.f
            f = int(np.random.choice(np.arange(self.inst.f), p=probs))
            if not seq[f]:
                non_empty = [x for x in range(self.inst.f) if seq[x]]
                if not non_empty:
                    break
                f = random.choice(non_empty)
            pos = random.randrange(len(seq[f]))
            removed.append(seq[f].pop(pos))

        # 重构：逐个尝试所有工厂所有位置，采用归一化双目标最优插入。
        random.shuffle(removed)
        for j in removed:
            seq = self._insert_best(seq, j, ref)
        return self._normalize_sequence(seq)

    def _local_search(self, sequence: List[List[int]], ref: Tuple[float, float]) -> List[List[int]]:
        seq = copy.deepcopy(sequence)
        base = self._decode(seq).objectives
        w = (0.5, 0.5)

        # critical_factory_swap
        loads = self._factory_makespans(seq)
        fmax = int(np.argmax(loads))
        improved = True
        while improved:
            improved = False
            for i in range(len(seq[fmax]) - 1):
                for j in range(i + 1, len(seq[fmax])):
                    cand = copy.deepcopy(seq)
                    cand[fmax][i], cand[fmax][j] = cand[fmax][j], cand[fmax][i]
                    obj = self._decode(cand).objectives
                    if scalar_fitness(obj, ref, w) < scalar_fitness(base, ref, w):
                        seq, base, improved = cand, obj, True
                        break
                if improved:
                    break

        # cross_factory_rotate：每个工厂取一个位置，做环形转移。
        for _ in range(max(1, self.inst.f)):
            non_empty = [f for f in range(self.inst.f) if seq[f]]
            if len(non_empty) < 2:
                break
            pos = {f: random.randrange(len(seq[f])) for f in non_empty}
            jobs = [seq[f][pos[f]] for f in non_empty]
            for shift in range(1, len(non_empty)):
                cand = copy.deepcopy(seq)
                rotated = jobs[-shift:] + jobs[:-shift]
                for f, jb in zip(non_empty, rotated):
                    cand[f][pos[f]] = jb
                obj = self._decode(cand).objectives
                if scalar_fitness(obj, ref, w) < scalar_fitness(base, ref, w):
                    seq, base = cand, obj
        return self._normalize_sequence(seq)

    def run(self, verbose: bool = True) -> List[Individual]:
        start = time.time()
        if verbose:
            print(f"\n开始运行 BOIG-DHFSPP: pop={self.pop_size}, iter={self.max_gen}")

        init_modes = ["NEH_F", "NEH_DBE", "NEH_BE", "NEH_RAND"]
        candidates = [self._initial_solution(m) for m in init_modes]
        while len(candidates) < self.pop_size:
            candidates.append(self._random_solution())

        population = [self._decode(self._perturbation(seq)) for seq in candidates]
        self.archive = nondominated(population)
        ref = (
            max(ind.objectives[0] for ind in population) + 1e-9,
            max(ind.objectives[1] for ind in population) + 1e-9,
        )
        current = min(population, key=lambda ind: scalar_fitness(ind.objectives, ref, (0.5, 0.5)))
        T = self.T

        for gen in range(self.max_gen):
            # 动态权重，模拟论文中 sigmoid 自适应倾向：前期更平衡探索，后期偏向 makespan/peak-feasible。
            alpha = 1.0 / (1.0 + math.exp(-self.sigmoid_k * ((gen + 1) / max(1, self.max_gen) - 0.5)))
            weight = (0.35 + 0.30 * alpha, 0.65 - 0.30 * alpha)

            seq = copy.deepcopy(current.schedule["sequence"])
            seq = self._destruction_construction(seq, ref)
            seq = self._perturbation(seq)
            seq = self._local_search(seq, ref)
            new_ind = self._decode(seq)

            old_fit = scalar_fitness(current.objectives, ref, weight)
            new_fit = scalar_fitness(new_ind.objectives, ref, weight)
            accept = new_fit <= old_fit
            if not accept:
                prob = math.exp(-(new_fit - old_fit) / max(1e-12, T))
                accept = random.random() < prob
            if accept:
                current = new_ind

            self.archive = nondominated(self.archive + [new_ind, current])
            if len(self.archive) > self.pop_size:
                # 保留分布较好的前沿：按 makespan 排序抽样。
                self.archive.sort(key=lambda x: (x.objectives[0], x.objectives[1]))
                idxs = np.linspace(0, len(self.archive) - 1, self.pop_size).astype(int)
                self.archive = [self.archive[i] for i in idxs]

            T *= self.cooling_rate
            if verbose and (gen + 1) % max(1, self.max_gen // 10) == 0:
                best = min(self.archive, key=lambda ind: ind.objectives[0])
                print(f"  gen {gen+1:4d}/{self.max_gen}, PF={len(self.archive)}, best=({best.objectives[0]:.3f}, {best.objectives[1]:.3f})")

        if verbose:
            print(f"BOIG-DHFSPP 完成，用时 {time.time()-start:.2f}s，Pareto={len(self.archive)}")
        return nondominated(self.archive)


# =============================================================================
# IPPO-DHFSPP
# =============================================================================

class IPPO_DHFSPP:
    """
    可直接运行的 IPPO-inspired 多智能体对比算法。

    为什么不是完整深度神经 PPO？
    论文 IPPO 需要 SimPy 动态环境、训练集、神经网络和大量 episode。
    作为“对比算法代码文件”，这里实现轻量但结构一致的版本：
        - 每个 factory agent 异步从候选池中选 job；
        - 候选池按 EDD/最短剩余工时截断到 L=8；
        - 每个 agent 有两套策略参数 theta1/theta2，奇偶 episode 交替使用；
        - reward 是 makespan 增量与 energy 增量的向量加权；
        - 使用 softmax preference + policy improvement 更新；
        - 机器选择采用 FAM + 峰值功率可行开始时间。
    """

    def __init__(
        self,
        instance: Dict[str, Any],
        pop_size: int = 50,
        max_gen: int = 100,
        candidate_size: int = 8,
        learning_rate: float = 0.08,
        temperature: float = 0.35,
        peak_power_limit: Optional[float] = None,
        seed: Optional[int] = None,
    ):
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
        self.raw = instance
        self.inst = DHHFSPPInstance(instance)
        self.pop_size = int(pop_size)
        self.max_gen = int(max_gen)
        self.candidate_size = int(candidate_size)
        self.lr = float(learning_rate)
        self.temperature = float(temperature)
        self.evaluator = PeakPowerScheduleEvaluator(instance, peak_power_limit)
        # feature: [bias, min_pt, min_energy, factory_load, position_ratio, random_explore]
        self.feature_dim = 6
        self.theta1 = np.zeros((self.inst.f, self.feature_dim), dtype=float)
        self.theta2 = np.zeros((self.inst.f, self.feature_dim), dtype=float)
        self.archive: List[Individual] = []

    def _features(self, job: int, f: int, partial_seq: List[List[int]], step: int) -> np.ndarray:
        load = len(partial_seq[f]) / max(1, self.inst.n)
        minpt = self.inst.min_pt(job) / max(1e-9, sum(self.inst.min_pt(j) for j in range(self.inst.n)) / self.inst.n)
        mine = self.inst.min_energy_work(job) / max(1e-9, sum(self.inst.min_energy_work(j) for j in range(self.inst.n)) / self.inst.n)
        return np.array([
            1.0,
            -minpt,          # 越短越好
            -mine,           # 越省能越好
            -load,           # 负载均衡
            -step / max(1, self.inst.n),
            random.random() - 0.5,
        ], dtype=float)

    def _policy_select(
        self,
        candidates: List[int],
        f: int,
        partial_seq: List[List[int]],
        theta: np.ndarray,
        step: int,
        greedy: bool = False,
    ) -> Tuple[int, np.ndarray, np.ndarray]:
        feats = np.vstack([self._features(j, f, partial_seq, step) for j in candidates])
        logits = feats @ theta[f]
        logits = logits / max(1e-9, self.temperature)
        logits -= np.max(logits)
        probs = np.exp(logits)
        probs /= np.sum(probs)
        if greedy:
            idx = int(np.argmax(probs))
        else:
            idx = int(np.random.choice(np.arange(len(candidates)), p=probs))
        return candidates[idx], feats[idx], probs

    def _rollout(
        self,
        theta: np.ndarray,
        weights: Tuple[float, float],
        train: bool = True,
        greedy: bool = False,
    ) -> Tuple[Individual, List[Tuple[int, np.ndarray, float]]]:
        unscheduled = set(range(self.inst.n))
        seq = [[] for _ in range(self.inst.f)]
        memories: List[Tuple[int, np.ndarray, float]] = []

        # 异步决策：每一步选当前负载最小/可用最早的工厂 agent。
        for step in range(self.inst.n):
            f = min(range(self.inst.f), key=lambda x: (len(seq[x]), x))
            # 论文用 EDD 选 8 个候选；本数据无 due date，用最短剩余工时作为 EDD proxy。
            pool = sorted(list(unscheduled), key=lambda j: (self.inst.min_pt(j), self.inst.min_energy_work(j)))
            candidates = pool[: max(1, min(self.candidate_size, len(pool)))]
            job, feat, probs = self._policy_select(candidates, f, seq, theta, step, greedy=greedy)

            before = self.evaluator.evaluate_sequence_solution(seq)["makespan"] if any(seq) else 0.0
            seq[f].append(job)
            unscheduled.remove(job)
            after_eval = self.evaluator.evaluate_sequence_solution(seq)
            # 多目标 immediate reward：越小越好，转为 reward 越大越好。
            delta_c = max(0.0, after_eval["makespan"] - before)
            delta_e = self.inst.min_energy_work(job)
            reward = -weights[0] * delta_c - weights[1] * delta_e / 10.0
            if train:
                memories.append((f, feat, reward))

        ind_eval = self.evaluator.evaluate_sequence_solution(seq)
        ind = Individual(
            schedule={"sequence": seq, "assignment": ind_eval.get("assignment")},
            objectives=(ind_eval["makespan"], ind_eval["total_energy"]),
        )
        return ind, memories

    def _update(self, theta: np.ndarray, memories: List[Tuple[int, np.ndarray, float]]) -> None:
        if not memories:
            return
        rewards = np.array([m[2] for m in memories], dtype=float)
        # reward scaling
        rewards = (rewards - rewards.mean()) / (rewards.std() + 1e-9)
        for (f, feat, _), adv in zip(memories, rewards):
            theta[f] += self.lr * adv * feat
            theta[f] = np.clip(theta[f], -5.0, 5.0)

    def _mutate_theta(self, theta: np.ndarray, scale: float = 0.15) -> np.ndarray:
        return theta + np.random.normal(0.0, scale, size=theta.shape)

    def run(self, verbose: bool = True) -> List[Individual]:
        start = time.time()
        if verbose:
            print(f"\n开始运行 IPPO-DHFSPP: episodes={self.max_gen}, rollouts/ep≈{max(2, self.pop_size//5)}")

        self.archive = []
        ref_objs = []

        for ep in range(self.max_gen):
            alpha = 0.5 + 0.5 * math.sin(2 * math.pi * ep / max(1, self.max_gen))
            weights1 = (0.65, 0.35)
            weights2 = (0.35, 0.65)
            use_first = (ep % 2 == 0)
            theta = self.theta1 if use_first else self.theta2
            weights = weights1 if use_first else weights2

            episode_inds = []
            episode_mem = []
            n_rollouts = max(2, self.pop_size // 5)
            for r in range(n_rollouts):
                theta_r = self._mutate_theta(theta, scale=0.10 * (1.0 - ep / max(1, self.max_gen)) + 0.02)
                ind, mem = self._rollout(theta_r, weights=weights, train=True, greedy=False)
                episode_inds.append(ind)
                episode_mem.extend(mem)

            # 选出当前 episode 中标量最优轨迹来更新对应策略。
            ref = (
                max([x.objectives[0] for x in episode_inds] + [1.0]),
                max([x.objectives[1] for x in episode_inds] + [1.0]),
            )
            best = min(episode_inds, key=lambda x: scalar_fitness(x.objectives, ref, weights))
            # 用所有轨迹的 memory 做简化 policy improvement。
            self._update(theta, episode_mem)

            # 奇偶双策略之间的半周期数据利用：借鉴 IPPO 的 single/dual-policy 思想。
            if ep % max(2, self.max_gen // 10) == 0 and ep > 0:
                mix = 0.1
                avg = (self.theta1 + self.theta2) / 2.0
                self.theta1 = (1 - mix) * self.theta1 + mix * avg
                self.theta2 = (1 - mix) * self.theta2 + mix * avg

            # 贪心评估两套当前策略，加入 archive。
            ind1, _ = self._rollout(self.theta1, weights1, train=False, greedy=True)
            ind2, _ = self._rollout(self.theta2, weights2, train=False, greedy=True)
            self.archive = nondominated(self.archive + episode_inds + [best, ind1, ind2])

            if len(self.archive) > self.pop_size:
                self.archive.sort(key=lambda x: (x.objectives[0], x.objectives[1]))
                idxs = np.linspace(0, len(self.archive) - 1, self.pop_size).astype(int)
                self.archive = [self.archive[i] for i in idxs]

            if verbose and (ep + 1) % max(1, self.max_gen // 10) == 0:
                b = min(self.archive, key=lambda ind: ind.objectives[0])
                print(f"  ep {ep+1:4d}/{self.max_gen}, PF={len(self.archive)}, best=({b.objectives[0]:.3f}, {b.objectives[1]:.3f})")

        if verbose:
            print(f"IPPO-DHFSPP 完成，用时 {time.time()-start:.2f}s，Pareto={len(self.archive)}")
        return nondominated(self.archive)


# =============================================================================
# 实验入口，与现有对比算法输出结构保持一致
# =============================================================================

def _safe_json_dump(obj: Dict[str, Any], path: str) -> None:
    def default(o):
        if isinstance(o, (np.integer,)):
            return int(o)
        if isinstance(o, (np.floating,)):
            return float(o)
        if isinstance(o, np.ndarray):
            return o.tolist()
        return str(o)

    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, default=default)
    os.replace(tmp, path)


def run_comparison_experiment(
    pop_size: int,
    max_gen: int,
    n_runs: int,
    instance_path: str,
    output_dir: str = "results",
    algorithms: Optional[List[str]] = None,
    peak_power_limit: Optional[float] = None,
    seed: int = 42,
) -> Dict[str, Any]:
    print("=" * 80)
    print("BOIG/IPPO for peak-power-constrained distributed hybrid flow shop")
    print("=" * 80)

    print(f"\n加载测试实例: {instance_path}")
    with open(instance_path, "r", encoding="utf-8") as f:
        instance = json.load(f)

    inst = DHHFSPPInstance(instance)
    print(f"  实例: {inst.name}")
    print(f"  作业数: {inst.n}, 阶段数: {inst.k}, 工厂数: {inst.f}")
    if peak_power_limit is None:
        peak_power_limit = inst.estimate_peak_limit()
    print(f"  峰值功率限制: {peak_power_limit:.6g}")

    if algorithms is None:
        algorithms = ["BOIG", "IPPO"]

    now = datetime.datetime.now()
    run_tag = now.strftime("%Y-%m-%d_%H-%M-%S")
    exp_dir = os.path.join(output_dir, f"{run_tag}_{inst.name}")
    os.makedirs(exp_dir, exist_ok=True)
    checkpoint_file = os.path.join(exp_dir, "checkpoint.json")
    final_file = os.path.join(exp_dir, "final_results.json")

    all_results: Dict[str, Any] = {
        "meta": {
            "instance_path": instance_path,
            "instance_name": inst.name,
            "n_jobs": inst.n,
            "n_stages": inst.k,
            "n_factories": inst.f,
            "pop_size": int(pop_size),
            "max_gen": int(max_gen),
            "n_runs": int(n_runs),
            "algorithms": algorithms,
            "peak_power_limit": float(peak_power_limit),
            "created_at": now.isoformat(),
        },
        "algorithms": {},
    }

    def save_checkpoint():
        _safe_json_dump(all_results, checkpoint_file)
        print(f"  [checkpoint saved] {checkpoint_file}")

    save_checkpoint()

    for alg_name in algorithms:
        print(f"\n{'=' * 80}")
        print(f"算法: {alg_name}")
        print(f"{'=' * 80}")

        alg_results: Dict[str, Any] = {
            "runs": [],
            "pareto_fronts": [],
            "hv_scores": [],
            "igd_scores": [],
            "sp_scores": [],
            "runtimes": [],
            "statistics": None,
        }

        for run_idx in range(n_runs):
            print(f"\n运行 {run_idx + 1}/{n_runs}...")
            run_record = {
                "run_index": run_idx,
                "status": "unknown",
                "runtime": None,
                "pareto_size": None,
                "error": None,
                "traceback": None,
                "pareto_front": None,
            }
            start_time = time.time()

            try:
                run_seed = seed + 1000 * run_idx + abs(hash(alg_name)) % 997
                if alg_name.upper() in {"BOIG", "BOIG-DHFSPP"}:
                    alg = BOIG_DHFSPP(
                        instance,
                        pop_size=pop_size,
                        max_gen=max_gen,
                        peak_power_limit=peak_power_limit,
                        seed=run_seed,
                    )
                elif alg_name.upper() in {"IPPO", "IPPO-DHFSPP"}:
                    alg = IPPO_DHFSPP(
                        instance,
                        pop_size=pop_size,
                        max_gen=max_gen,
                        peak_power_limit=peak_power_limit,
                        seed=run_seed,
                    )
                else:
                    raise ValueError(f"未知算法: {alg_name}")

                pareto_front = alg.run(verbose=False)
                runtime = time.time() - start_time
                pareto_objs = [(float(ind.objectives[0]), float(ind.objectives[1])) for ind in pareto_front]

                run_record["status"] = "success"
                run_record["runtime"] = float(runtime)
                run_record["pareto_size"] = int(len(pareto_front))
                run_record["pareto_front"] = pareto_objs

                alg_results["pareto_fronts"].append(pareto_objs)
                alg_results["runtimes"].append(float(runtime))
                print(f"  完成! Pareto前沿: {len(pareto_front)} 个解, 用时: {runtime:.2f}秒")

            except Exception as e:
                runtime = time.time() - start_time
                tb = traceback.format_exc()
                run_record["status"] = "failed"
                run_record["runtime"] = float(runtime)
                run_record["error"] = repr(e)
                run_record["traceback"] = tb
                print(f"  [FAILED] run={run_idx + 1}/{n_runs}, runtime={runtime:.2f}s, error={repr(e)}")
                print(tb)

            finally:
                alg_results["runs"].append(run_record)
                all_results["algorithms"][alg_name] = alg_results
                save_checkpoint()

        successful_pfs = alg_results["pareto_fronts"]
        if not successful_pfs:
            alg_results["statistics"] = {
                "success_runs": 0,
                "failed_runs": n_runs,
                "hv": None,
                "igd": None,
                "sp": None,
                "runtime": None,
            }
            all_results["algorithms"][alg_name] = alg_results
            save_checkpoint()
            continue

        all_objs = []
        for pf in successful_pfs:
            all_objs.extend(pf)
        reference_front = []
        for obj in all_objs:
            if not any(dominates(other, obj) for other in all_objs if other != obj):
                if obj not in reference_front:
                    reference_front.append(obj)

        for pf_objs in successful_pfs:
            pf_inds = [Individual(schedule=[], objectives=tuple(obj)) for obj in pf_objs]
            alg_results["hv_scores"].append(PerformanceMetrics.hypervolume(pf_inds))
            alg_results["igd_scores"].append(PerformanceMetrics.igd(pf_inds, reference_front))
            alg_results["sp_scores"].append(PerformanceMetrics.spacing(pf_inds))

        alg_results["statistics"] = {
            "success_runs": len(successful_pfs),
            "failed_runs": n_runs - len(successful_pfs),
            "hv": {
                "mean": float(np.mean(alg_results["hv_scores"])),
                "std": float(np.std(alg_results["hv_scores"])),
                "min": float(np.min(alg_results["hv_scores"])),
                "max": float(np.max(alg_results["hv_scores"])),
            },
            "igd": {
                "mean": float(np.mean(alg_results["igd_scores"])),
                "std": float(np.std(alg_results["igd_scores"])),
                "min": float(np.min(alg_results["igd_scores"])),
                "max": float(np.max(alg_results["igd_scores"])),
            },
            "sp": {
                "mean": float(np.mean(alg_results["sp_scores"])),
                "std": float(np.std(alg_results["sp_scores"])),
                "min": float(np.min(alg_results["sp_scores"])),
                "max": float(np.max(alg_results["sp_scores"])),
            },
            "runtime": {
                "mean": float(np.mean(alg_results["runtimes"])),
                "std": float(np.std(alg_results["runtimes"])),
                "min": float(np.min(alg_results["runtimes"])),
                "max": float(np.max(alg_results["runtimes"])),
            },
        }
        all_results["algorithms"][alg_name] = alg_results
        save_checkpoint()

        print(f"\n{alg_name} 统计:")
        print(f"  HV:  {alg_results['statistics']['hv']['mean']:.6f} ± {alg_results['statistics']['hv']['std']:.6f}")
        print(f"  IGD: {alg_results['statistics']['igd']['mean']:.6f} ± {alg_results['statistics']['igd']['std']:.6f}")
        print(f"  SP:  {alg_results['statistics']['sp']['mean']:.6f} ± {alg_results['statistics']['sp']['std']:.6f}")
        print(f"  Runtime: {alg_results['statistics']['runtime']['mean']:.2f}s ± {alg_results['statistics']['runtime']['std']:.2f}s")

    _safe_json_dump(all_results, final_file)
    print(f"\n最终结果已保存: {final_file}")
    return all_results


def _dataset_sort_key(path: str) -> Tuple[int, int, str]:
    """按 S1..S4, M1..M4, L1..L4 的自然顺序排序数据集。"""
    base = os.path.splitext(os.path.basename(path))[0]
    prefix = base[:1].upper()
    group_order = {"S": 0, "M": 1, "L": 2}.get(prefix, 9)
    num = 999
    try:
        num = int(base[1:].split("_")[0])
    except Exception:
        pass
    return group_order, num, base


def discover_dataset_paths(
    dataset_dir: str = "new_dataset",
    dataset_glob: str = "*.json",
    instances: Optional[List[str]] = None,
) -> List[str]:
    """
    获取需要运行的实例路径。

    优先级：
      1) 如果命令行给了 --instances，则只运行这些路径；
      2) 否则扫描 --dataset_dir 下符合 --dataset_glob 的 JSON 文件。

    返回值会按 S/M/L 和编号自然排序，例如：
      S1, S2, S3, S4, M1, ..., L4
    """
    if instances:
        paths = [os.path.normpath(x) for x in instances]
    else:
        import glob
        pattern = os.path.join(dataset_dir, dataset_glob)
        paths = glob.glob(pattern)

    paths = sorted(paths, key=_dataset_sort_key)
    missing = [p for p in paths if not os.path.isfile(p)]
    if missing:
        raise FileNotFoundError("以下数据集文件不存在：\n" + "\n".join(missing))
    if not paths:
        raise FileNotFoundError(
            f"没有找到数据集文件。请检查 --dataset_dir={dataset_dir!r}, --dataset_glob={dataset_glob!r}"
        )
    return paths


def run_batch_experiments(
    dataset_paths: List[str],
    pop_size: int,
    max_gen: int,
    n_runs: int,
    output_dir: str,
    algorithms: Optional[List[str]],
    peak_power_limit: Optional[float],
    seed: int,
    continue_on_error: bool = True,
) -> Dict[str, Any]:
    """
    批量运行多个数据集。

    每个 JSON 示例会独立调用一次 run_comparison_experiment，
    因此每个示例都有自己的 checkpoint.json 和 final_results.json。
    默认 n_runs=20，即每个示例每个算法独立重复运行 20 次。

    同时在 output_dir 下额外保存 batch_summary.json，方便检查全部实例是否完成。
    """
    os.makedirs(output_dir, exist_ok=True)
    batch_started_at = datetime.datetime.now().isoformat()

    batch_summary: Dict[str, Any] = {
        "meta": {
            "created_at": batch_started_at,
            "dataset_count": len(dataset_paths),
            "dataset_paths": dataset_paths,
            "pop_size": int(pop_size),
            "max_gen": int(max_gen),
            "n_runs_per_instance": int(n_runs),
            "algorithms": algorithms if algorithms is not None else ["BOIG", "IPPO"],
            "peak_power_limit": None if peak_power_limit is None else float(peak_power_limit),
            "seed": int(seed),
        },
        "datasets": [],
    }

    summary_file = os.path.join(output_dir, "batch_summary.json")

    def save_batch_summary() -> None:
        _safe_json_dump(batch_summary, summary_file)
        print(f"\n[batch summary saved] {summary_file}")

    save_batch_summary()

    for ds_idx, instance_path in enumerate(dataset_paths):
        base = os.path.splitext(os.path.basename(instance_path))[0]
        print("\n" + "#" * 100)
        print(f"数据集 {ds_idx + 1}/{len(dataset_paths)}: {instance_path}")
        print(f"每个算法独立运行 {n_runs} 次")
        print("#" * 100)

        record: Dict[str, Any] = {
            "dataset_index": ds_idx,
            "instance_path": instance_path,
            "instance_name_from_file": base,
            "status": "unknown",
            "started_at": datetime.datetime.now().isoformat(),
            "finished_at": None,
            "runtime": None,
            "error": None,
            "traceback": None,
            "result_meta": None,
        }
        t0 = time.time()

        try:
            dataset_seed = seed + ds_idx * 100000
            result = run_comparison_experiment(
                pop_size=pop_size,
                max_gen=max_gen,
                n_runs=n_runs,
                instance_path=instance_path,
                output_dir=output_dir,
                algorithms=algorithms,
                peak_power_limit=peak_power_limit,
                seed=dataset_seed,
            )
            record["status"] = "success"
            record["result_meta"] = result.get("meta", {})

        except Exception as e:
            tb = traceback.format_exc()
            record["status"] = "failed"
            record["error"] = repr(e)
            record["traceback"] = tb
            print(f"\n[DATASET FAILED] {instance_path}: {repr(e)}")
            print(tb)
            if not continue_on_error:
                record["finished_at"] = datetime.datetime.now().isoformat()
                record["runtime"] = float(time.time() - t0)
                batch_summary["datasets"].append(record)
                save_batch_summary()
                raise

        finally:
            record["finished_at"] = datetime.datetime.now().isoformat()
            record["runtime"] = float(time.time() - t0)
            batch_summary["datasets"].append(record)
            save_batch_summary()

    success = sum(1 for r in batch_summary["datasets"] if r["status"] == "success")
    failed = sum(1 for r in batch_summary["datasets"] if r["status"] == "failed")
    batch_summary["meta"]["finished_at"] = datetime.datetime.now().isoformat()
    batch_summary["meta"]["success_datasets"] = success
    batch_summary["meta"]["failed_datasets"] = failed
    save_batch_summary()

    print("\n" + "=" * 100)
    print(f"批量实验完成：成功 {success}/{len(dataset_paths)}，失败 {failed}/{len(dataset_paths)}")
    print(f"汇总文件：{summary_file}")
    print("=" * 100)
    return batch_summary


def main() -> None:
    parser = argparse.ArgumentParser(description="BOIG/IPPO algorithms for DHFSPP")

    parser.add_argument(
        "--instance",
        dest="instance_path",
        default=None,
        help="单个 JSON instance path；如果提供，则只运行该实例。",
    )
    parser.add_argument(
        "--dataset_dir",
        default="new_dataset",
        help="批量数据集目录，默认 datasets。",
    )
    parser.add_argument(
        "--dataset_glob",
        default="*.json",
        help="批量数据集匹配模式，默认 *.json。",
    )
    parser.add_argument(
        "--instances",
        nargs="+",
        default=None,
        help="显式指定多个 JSON 路径；优先于 --dataset_dir/--dataset_glob。",
    )

    parser.add_argument("--output_dir", default="results", help="输出目录")
    parser.add_argument("--algorithms", nargs="+", default=["BOIG", "IPPO"], help="BOIG IPPO")
    parser.add_argument("--pop_size", type=int, default=100)
    parser.add_argument("--max_gen", type=int, default=100)
    parser.add_argument("--n_runs", type=int, default=10, help="每个示例/每个算法独立运行次数，默认 20")
    parser.add_argument("--peak_power_limit", type=float, default=None)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--stop_on_error",
        action="store_true",
        help="批量运行时遇到某个数据集失败就停止；默认继续运行后续数据集。",
    )

    args = parser.parse_args()

    if args.instance_path:
        run_comparison_experiment(
            pop_size=args.pop_size,
            max_gen=args.max_gen,
            n_runs=args.n_runs,
            instance_path=args.instance_path,
            output_dir=args.output_dir,
            algorithms=args.algorithms,
            peak_power_limit=args.peak_power_limit,
            seed=args.seed,
        )
    else:
        dataset_paths = discover_dataset_paths(
            dataset_dir=args.dataset_dir,
            dataset_glob=args.dataset_glob,
            instances=args.instances,
        )
        print("将运行以下数据集：")
        for p in dataset_paths:
            print(f"  - {p}")

        run_batch_experiments(
            dataset_paths=dataset_paths,
            pop_size=args.pop_size,
            max_gen=args.max_gen,
            n_runs=args.n_runs,
            output_dir=args.output_dir,
            algorithms=args.algorithms,
            peak_power_limit=args.peak_power_limit,
            seed=args.seed,
            continue_on_error=not args.stop_on_error,
        )

if __name__ == "__main__":
    main()
