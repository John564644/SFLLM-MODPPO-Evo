#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
DCMA算法及对比算法实现 - 多目标DHFSP问题
包含DCMA、NSGA-II、MOEA/D、SPEA2四种算法
"""
import datetime
import random
import traceback

import numpy as np
import tt
import copy
import json
import os
from typing import List, Dict, Tuple, Any
from dataclasses import dataclass, field
import time


# ============================================================================
# 基础数据结构
# ============================================================================

@dataclass
class Individual:
    """个体类"""
    schedule: List[List]  # 调度方案
    objectives: Tuple[float, float]  # (makespan, energy)
    rank: int = 0
    crowding_distance: float = 0.0
    dominated_count: int = 0
    dominating_set: List = field(default_factory=list)
    fitness: float = 0.0  # 用于DCMA的适应度


# ============================================================================
# 调度评估器
# ============================================================================

class ScheduleEvaluator:
    """调度方案评估器 - 考虑峰值能耗约束"""
    
    def __init__(self, instance: Dict, peak_power_limit: float = None):
        self.instance = instance
        self.n_jobs = instance['n']
        self.n_stages = instance['k']
        self.n_factories = instance['f']
        self.machines_per_stage = instance['machines_per_stage']
        self.processing_times = instance['processing_times']
        self.energy_consumption = instance['energy_consumption']
        
        # 峰值功耗限制
        if peak_power_limit is None:
            # Robust average energy-rate across all available entries (handles nested dicts)
            _vals = []

            def _collect_numbers(x):
                if isinstance(x, dict):
                    for vv in x.values():
                        _collect_numbers(vv)
                else:
                    try:
                        _vals.append(float(x))
                    except Exception:
                        pass

            for j in range(self.n_jobs):
                for s in range(self.n_stages):
                    for o in range(len(self.processing_times[str(j)][str(s)])):
                        block = self.energy_consumption[str(j)][str(s)][str(o)]
                        _collect_numbers(block)

            avg_energy = float(np.mean(_vals)) if _vals else 1.0
            self.peak_power_limit = avg_energy * 3
        else:
            self.peak_power_limit = peak_power_limit
    
    
    def _get_pt_energy(self, job_id: int, stage_id: int, op_id: int, factory: int, machine: int):
        """Fetch processing time and energy rate with strong backward compatibility.

        Supports (examples):
          - pt[j][s][o][f][m]  (intended new format)
          - pt[j][s][o][m]     (legacy, factory dimension missing)
          - pt[j][s][o]['0'][m] or pt[j][s][o][f]['0'][m] (mixed/older small datasets)
        """
        pt_block = self.processing_times[str(job_id)][str(stage_id)][str(op_id)]
        en_block = self.energy_consumption[str(job_id)][str(stage_id)][str(op_id)]

        f_key = str(factory)
        m_key = str(machine)

        def _extract_numeric(block):
            if not isinstance(block, dict):
                return float(block)

            # direct machine leaf
            if m_key in block and not isinstance(block[m_key], dict):
                return float(block[m_key])

            # preferred: factory branch
            if f_key in block:
                return _extract_numeric(block[f_key])

            # otherwise, try to find machine deeper by searching values
            last_err = None
            for vv in block.values():
                try:
                    return _extract_numeric(vv)
                except Exception as e:
                    import traceback
                    print('[ScheduleEvaluator] evaluate() failed:', repr(e))
                    traceback.print_exc()
                    last_err = e
                    continue
            raise last_err if last_err else KeyError('No numeric leaf found')

        pt = _extract_numeric(pt_block)
        er = _extract_numeric(en_block)
        return pt, er

    def evaluate(self, schedule: List[List]) -> Dict:
        """评估调度方案"""
        try:
            machine_ready = {}
            job_ready = [0.0] * self.n_jobs
            events = []
            total_energy = 0.0
            power_violations = 0
            max_violation = 0.0
            
            # 初始化机器就绪时间
            for f in range(self.n_factories):
                for s in range(self.n_stages):
                    for m in range(self.machines_per_stage[f][s]):
                        machine_ready[(f, s, m)] = 0.0
            
            # 调度所有作业
            for job_id in range(self.n_jobs):
                for stage_id in range(self.n_stages):
                    stage_ops = schedule[job_id][stage_id]
                    
                    for op_id, (factory, machine) in enumerate(stage_ops):
                        # 获取处理时间和能耗
                        pt, energy_rate = self._get_pt_energy(job_id, stage_id, op_id, factory, machine)
                        # 计算最早开始时间
                        earliest_start = max(
                            job_ready[job_id],
                            machine_ready[(factory, stage_id, machine)]
                        )
                        
                        # 检查峰值功耗约束
                        start_time, violation = self._find_feasible_start(
                            earliest_start, pt, energy_rate, events
                        )
                        
                        if violation > 0:
                            power_violations += 1
                            max_violation = max(max_violation, violation)
                        
                        # 更新时间
                        finish_time = start_time + pt
                        machine_ready[(factory, stage_id, machine)] = finish_time
                        job_ready[job_id] = finish_time
                        
                        # 记录事件
                        events.append((start_time, finish_time, energy_rate))
                        total_energy += energy_rate * pt
            
            makespan = max(job_ready)
            feasible = (power_violations == 0)
            
            return {
                'makespan': makespan,
                'total_energy': total_energy,
                'feasible': feasible,
                'power_violations': power_violations,
                'max_violation': max_violation
            }
            
        except Exception as e:
            return {
                'makespan': float('inf'),
                'total_energy': float('inf'),
                'feasible': False,
                'power_violations': 9999,
                'max_violation': 9999
            }
    
    def _find_feasible_start(self, earliest_start: float, duration: float,
                            energy_rate: float, events: List) -> Tuple[float, float]:
        """查找满足峰值功耗约束的可行开始时间"""
        start = earliest_start
        current_power = self._calculate_power_at(start, events)
        
        if current_power + energy_rate <= self.peak_power_limit:
            return start, 0.0
        
        violation = current_power + energy_rate - self.peak_power_limit
        delay = violation / (self.peak_power_limit * 0.1)
        return start + delay, violation
    
    def _calculate_power_at(self, time: float, events: List) -> float:
        """计算指定时刻的总功率"""
        total_power = 0.0
        for start, finish, power in events:
            if start <= time < finish:
                total_power += power
        return total_power


# ============================================================================
# 调度编码器
# ============================================================================

class ScheduleEncoder:
    """调度方案编码/解码器"""
    
    def __init__(self, n_jobs: int, n_stages: int, n_factories: int,
                 machines_per_stage: List[List]):
        self.n_jobs = n_jobs
        self.n_stages = n_stages
        self.n_factories = n_factories
        self.machines_per_stage = machines_per_stage
    
    def generate_random_schedule(self) -> List[List]:
        """生成随机调度方案"""
        schedule = []
        for job in range(self.n_jobs):
            job_schedule = []
            for stage in range(self.n_stages):
                factory = random.randint(0, self.n_factories - 1)
                n_machines = self.machines_per_stage[factory][stage]
                machine = random.randint(0, n_machines - 1)
                job_schedule.append([(factory, machine)])
            schedule.append(job_schedule)
        return schedule
    
    def crossover(self, parent1: List[List], parent2: List[List]) -> List[List]:
        """交叉操作"""
        child = []
        for job in range(self.n_jobs):
            if random.random() < 0.5:
                child.append(copy.deepcopy(parent1[job]))
            else:
                child.append(copy.deepcopy(parent2[job]))
        return child
    
    def mutate(self, schedule: List[List], mutation_rate: float) -> List[List]:
        """变异操作"""
        mutated = copy.deepcopy(schedule)
        for job in range(self.n_jobs):
            for stage in range(self.n_stages):
                if random.random() < mutation_rate:
                    factory = random.randint(0, self.n_factories - 1)
                    n_machines = self.machines_per_stage[factory][stage]
                    machine = random.randint(0, n_machines - 1)
                    mutated[job][stage][0] = (factory, machine)
        return mutated


# ============================================================================
# DCMA算法实现
# ============================================================================

class DCMA:
    """
    分布式协同进化Memetic算法 (Distributed Co-evolutionary Memetic Algorithm)
    基于Zhang et al. (2022)论文
    """
    
    def __init__(self, instance: Dict, pop_size: int = 100, max_gen: int = 200,
                 n_subpops: int = 4, migration_interval: int = 10,
                 migration_rate: float = 0.1, local_search_prob: float = 0.3,
                 crossover_rate: float = 0.9, mutation_rate: float = 0.1,
                 peak_power_limit: float = None):
        """
        初始化DCMA
        
        Args:
            instance: 问题实例
            pop_size: 总种群大小
            max_gen: 最大代数
            n_subpops: 子种群数量
            migration_interval: 迁移间隔
            migration_rate: 迁移率
            local_search_prob: 局部搜索概率
            crossover_rate: 交叉率
            mutation_rate: 变异率
            peak_power_limit: 峰值功耗限制
        """
        self.instance = instance
        self.pop_size = pop_size
        self.max_gen = max_gen
        self.n_subpops = n_subpops
        self.subpop_size = pop_size // n_subpops
        self.migration_interval = migration_interval
        self.migration_rate = migration_rate
        self.local_search_prob = local_search_prob
        self.crossover_rate = crossover_rate
        self.mutation_rate = mutation_rate
        
        # 初始化组件
        self.encoder = ScheduleEncoder(
            instance['n'], instance['k'], instance['f'],
            instance['machines_per_stage']
        )
        self.evaluator = ScheduleEvaluator(instance, peak_power_limit)
        
        # 子种群
        self.subpopulations = []
        self.pareto_front = []
        self.history = []
    
    def run(self, verbose: bool = True) -> List[Individual]:
        """运行DCMA算法"""
        if verbose:
            print(f"\n开始运行 DCMA...")
            print(f"  种群大小: {self.pop_size}, 子种群数: {self.n_subpops}, 最大代数: {self.max_gen}")
        
        start_time = time.time()
        
        # 初始化子种群
        self._initialize_subpopulations()
        
        # 主进化循环
        for gen in range(self.max_gen):
            # 各子种群独立进化
            for subpop_id in range(self.n_subpops):
                self._evolve_subpopulation(subpop_id)
            
            # 迁移操作
            if (gen + 1) % self.migration_interval == 0:
                self._migration()
            
            # 更新全局Pareto前沿
            self._update_global_pareto_front()
            
            # 记录历史
            if len(self.pareto_front) > 0:
                avg_makespan = np.mean([ind.objectives[0] for ind in self.pareto_front])
                avg_energy = np.mean([ind.objectives[1] for ind in self.pareto_front])
                self.history.append({
                    'generation': gen,
                    'pareto_size': len(self.pareto_front),
                    'avg_makespan': avg_makespan,
                    'avg_energy': avg_energy
                })
            
            if verbose and (gen + 1) % 20 == 0:
                print(f"  代数 {gen+1}/{self.max_gen}: Pareto前沿 {len(self.pareto_front)} 个解")
        
        elapsed_time = time.time() - start_time
        
        if verbose:
            print(f"  完成! 用时: {elapsed_time:.2f}秒")
            print(f"  最终Pareto前沿: {len(self.pareto_front)} 个解")
        
        return self.pareto_front
    
    def _initialize_subpopulations(self):
        """初始化子种群"""
        self.subpopulations = []
        
        for _ in range(self.n_subpops):
            subpop = []
            for _ in range(self.subpop_size):
                schedule = self.encoder.generate_random_schedule()
                ind = Individual(schedule=schedule, objectives=(0, 0))
                self._evaluate_individual(ind)
                subpop.append(ind)
            
            # 非支配排序
            self._non_dominated_sort(subpop)
            self.subpopulations.append(subpop)
    
    def _evolve_subpopulation(self, subpop_id: int):
        """进化单个子种群"""
        subpop = self.subpopulations[subpop_id]
        offspring = []
        
        # 生成后代
        while len(offspring) < self.subpop_size:
            # 选择
            parent1 = self._tournament_selection(subpop)
            parent2 = self._tournament_selection(subpop)
            
            # 交叉
            if random.random() < self.crossover_rate:
                child_schedule = self.encoder.crossover(parent1.schedule, parent2.schedule)
            else:
                child_schedule = copy.deepcopy(parent1.schedule)
            
            # 变异
            child_schedule = self.encoder.mutate(child_schedule, self.mutation_rate)
            
            # 创建个体
            child = Individual(schedule=child_schedule, objectives=(0, 0))
            self._evaluate_individual(child)
            
            # 局部搜索
            if random.random() < self.local_search_prob:
                child = self._local_search(child)
            
            offspring.append(child)
        
        # 环境选择
        combined = subpop + offspring
        self._non_dominated_sort(combined)
        
        # 选择下一代
        new_subpop = []
        for ind in combined:
            if len(new_subpop) < self.subpop_size:
                new_subpop.append(ind)
            else:
                break
        
        # 按拥挤距离补充
        if len(new_subpop) < self.subpop_size:
            remaining = [ind for ind in combined if ind not in new_subpop]
            self._calculate_crowding_distance(remaining)
            remaining.sort(key=lambda x: x.crowding_distance, reverse=True)
            new_subpop.extend(remaining[:self.subpop_size - len(new_subpop)])
        
        self.subpopulations[subpop_id] = new_subpop
    
    def _local_search(self, individual: Individual) -> Individual:
        """局部搜索 - 改进单个个体"""
        best_ind = copy.deepcopy(individual)
        best_objs = individual.objectives
        
        # 尝试若干次邻域搜索
        for _ in range(3):
            neighbor = copy.deepcopy(individual)
            
            # 随机选择一个作业和阶段进行调整
            job = random.randint(0, len(neighbor.schedule) - 1)
            stage = random.randint(0, len(neighbor.schedule[job]) - 1)
            
            # 重新分配工厂和机器
            factory = random.randint(0, self.encoder.n_factories - 1)
            n_machines = self.encoder.machines_per_stage[factory][stage]
            machine = random.randint(0, n_machines - 1)
            neighbor.schedule[job][stage][0] = (factory, machine)
            
            # 评估
            self._evaluate_individual(neighbor)
            
            # 如果更好则接受
            if self._dominates(neighbor.objectives, best_objs):
                best_ind = neighbor
                best_objs = neighbor.objectives
        
        return best_ind
    
    def _migration(self):
        """子种群间迁移操作"""
        n_migrants = int(self.subpop_size * self.migration_rate)
        
        for i in range(self.n_subpops):
            # 选择目标子种群
            target = (i + 1) % self.n_subpops
            
            # 选择优秀个体进行迁移
            source_subpop = self.subpopulations[i]
            source_subpop.sort(key=lambda x: (x.rank, -x.crowding_distance))
            migrants = source_subpop[:n_migrants]
            
            # 替换目标子种群中较差的个体
            target_subpop = self.subpopulations[target]
            target_subpop.sort(key=lambda x: (x.rank, -x.crowding_distance))
            
            for j in range(n_migrants):
                target_subpop[-(j+1)] = copy.deepcopy(migrants[j])
    
    def _update_global_pareto_front(self):
        """更新全局Pareto前沿"""
        all_individuals = []
        for subpop in self.subpopulations:
            all_individuals.extend(subpop)
        
        # 提取非支配解
        self.pareto_front = []
        for ind in all_individuals:
            is_dominated = False
            for other in all_individuals:
                if self._dominates(other.objectives, ind.objectives):
                    is_dominated = True
                    break
            if not is_dominated:
                self.pareto_front.append(copy.deepcopy(ind))
    
    def _evaluate_individual(self, ind: Individual):
        """评估个体"""
        metrics = self.evaluator.evaluate(ind.schedule)
        
        if not metrics['feasible']:
            penalty = metrics['max_violation'] * 100
            ind.objectives = (
                metrics['makespan'] + penalty,
                metrics['total_energy'] + penalty
            )
        else:
            ind.objectives = (metrics['makespan'], metrics['total_energy'])
    
    def _tournament_selection(self, population: List[Individual],
                             tournament_size: int = 2) -> Individual:
        """锦标赛选择"""
        tournament = random.sample(population, min(tournament_size, len(population)))
        tournament.sort(key=lambda x: (x.rank, -x.crowding_distance))
        return tournament[0]
    
    def _non_dominated_sort(self, population: List[Individual]):
        """非支配排序"""
        for ind in population:
            ind.dominated_count = 0
            ind.dominating_set = []
        
        for i, ind1 in enumerate(population):
            for j, ind2 in enumerate(population):
                if i != j:
                    if self._dominates(ind1.objectives, ind2.objectives):
                        ind1.dominating_set.append(ind2)
                    elif self._dominates(ind2.objectives, ind1.objectives):
                        ind1.dominated_count += 1
        
        fronts = []
        current_front = [ind for ind in population if ind.dominated_count == 0]
        
        for ind in current_front:
            ind.rank = 0
        
        front_index = 0
        while current_front:
            fronts.append(current_front)
            next_front = []
            
            for ind1 in current_front:
                for ind2 in ind1.dominating_set:
                    ind2.dominated_count -= 1
                    if ind2.dominated_count == 0:
                        ind2.rank = front_index + 1
                        next_front.append(ind2)
            
            current_front = next_front
            front_index += 1
    
    def _dominates(self, obj1: Tuple[float, float],
                   obj2: Tuple[float, float]) -> bool:
        """判断obj1是否支配obj2"""
        better_in_all = all(o1 <= o2 for o1, o2 in zip(obj1, obj2))
        better_in_one = any(o1 < o2 for o1, o2 in zip(obj1, obj2))
        return better_in_all and better_in_one
    
    def _calculate_crowding_distance(self, front: List[Individual]):
        """计算拥挤距离"""
        n = len(front)
        if n == 0:
            return
        
        for ind in front:
            ind.crowding_distance = 0.0
        
        for obj_idx in range(2):
            front.sort(key=lambda x: x.objectives[obj_idx])
            front[0].crowding_distance = float('inf')
            front[-1].crowding_distance = float('inf')
            
            obj_range = front[-1].objectives[obj_idx] - front[0].objectives[obj_idx]
            if obj_range == 0:
                continue
            
            for i in range(1, n - 1):
                distance = (front[i+1].objectives[obj_idx] -
                           front[i-1].objectives[obj_idx]) / obj_range
                front[i].crowding_distance += distance


# ============================================================================
# NSGA-II算法（用于对比）
# ============================================================================

class NSGAII:
    """NSGA-II算法"""
    
    def __init__(self, instance: Dict, pop_size: int = 100, max_gen: int = 200,
                 crossover_rate: float = 0.9, mutation_rate: float = 0.1,
                 peak_power_limit: float = None):
        self.instance = instance
        self.pop_size = pop_size
        self.max_gen = max_gen
        self.crossover_rate = crossover_rate
        self.mutation_rate = mutation_rate
        
        self.encoder = ScheduleEncoder(
            instance['n'], instance['k'], instance['f'],
            instance['machines_per_stage']
        )
        self.evaluator = ScheduleEvaluator(instance, peak_power_limit)
        
        self.population = []
        self.pareto_front = []
        self.history = []
    
    def run(self, verbose: bool = True) -> List[Individual]:
        """运行NSGA-II"""
        if verbose:
            print(f"\n开始运行 NSGA-II...")
            print(f"  种群大小: {self.pop_size}, 最大代数: {self.max_gen}")
        
        start_time = time.time()
        
        # 初始化
        self.population = self._initialize_population()
        self._evaluate_population(self.population)
        
        # 主循环
        for gen in range(self.max_gen):
            offspring = self._generate_offspring()
            self._evaluate_population(offspring)
            
            combined = self.population + offspring
            fronts = self._non_dominated_sort(combined)
            
            self.population = []
            for front in fronts:
                if len(self.population) + len(front) <= self.pop_size:
                    self.population.extend(front)
                else:
                    self._calculate_crowding_distance(front)
                    front.sort(key=lambda x: x.crowding_distance, reverse=True)
                    remaining = self.pop_size - len(self.population)
                    self.population.extend(front[:remaining])
                    break
            
            self.pareto_front = fronts[0] if fronts else []
            
            if len(self.pareto_front) > 0:
                avg_makespan = np.mean([ind.objectives[0] for ind in self.pareto_front])
                avg_energy = np.mean([ind.objectives[1] for ind in self.pareto_front])
                self.history.append({
                    'generation': gen,
                    'pareto_size': len(self.pareto_front),
                    'avg_makespan': avg_makespan,
                    'avg_energy': avg_energy
                })
            
            if verbose and (gen + 1) % 20 == 0:
                print(f"  代数 {gen+1}/{self.max_gen}: Pareto前沿 {len(self.pareto_front)} 个解")
        
        elapsed_time = time.time() - start_time
        
        if verbose:
            print(f"  完成! 用时: {elapsed_time:.2f}秒")
            print(f"  最终Pareto前沿: {len(self.pareto_front)} 个解")
        
        return self.pareto_front
    
    def _initialize_population(self):
        population = []
        for _ in range(self.pop_size):
            schedule = self.encoder.generate_random_schedule()
            individual = Individual(schedule=schedule, objectives=(0, 0))
            population.append(individual)
        return population
    
    def _evaluate_population(self, population):
        for ind in population:
            metrics = self.evaluator.evaluate(ind.schedule)
            if not metrics['feasible']:
                penalty = metrics['max_violation'] * 100
                ind.objectives = (
                    metrics['makespan'] + penalty,
                    metrics['total_energy'] + penalty
                )
            else:
                ind.objectives = (metrics['makespan'], metrics['total_energy'])
    
    def _generate_offspring(self):
        offspring = []
        while len(offspring) < self.pop_size:
            parent1 = self._tournament_selection()
            parent2 = self._tournament_selection()
            
            if random.random() < self.crossover_rate:
                child_schedule = self.encoder.crossover(parent1.schedule, parent2.schedule)
            else:
                child_schedule = copy.deepcopy(parent1.schedule)
            
            child_schedule = self.encoder.mutate(child_schedule, self.mutation_rate)
            child = Individual(schedule=child_schedule, objectives=(0, 0))
            offspring.append(child)
        
        return offspring
    
    def _tournament_selection(self, tournament_size: int = 2):
        tournament = random.sample(self.population, tournament_size)
        tournament.sort(key=lambda x: (x.rank, -x.crowding_distance))
        return tournament[0]
    
    def _non_dominated_sort(self, population):
        for ind in population:
            ind.dominated_count = 0
            ind.dominating_set = []
        
        for i, ind1 in enumerate(population):
            for j, ind2 in enumerate(population):
                if i != j:
                    if self._dominates(ind1.objectives, ind2.objectives):
                        ind1.dominating_set.append(ind2)
                    elif self._dominates(ind2.objectives, ind1.objectives):
                        ind1.dominated_count += 1
        
        fronts = []
        current_front = [ind for ind in population if ind.dominated_count == 0]
        
        for ind in current_front:
            ind.rank = 0
        
        front_index = 0
        while current_front:
            fronts.append(current_front)
            next_front = []
            
            for ind1 in current_front:
                for ind2 in ind1.dominating_set:
                    ind2.dominated_count -= 1
                    if ind2.dominated_count == 0:
                        ind2.rank = front_index + 1
                        next_front.append(ind2)
            
            current_front = next_front
            front_index += 1
        
        return fronts
    
    def _dominates(self, obj1, obj2):
        better_in_all = all(o1 <= o2 for o1, o2 in zip(obj1, obj2))
        better_in_one = any(o1 < o2 for o1, o2 in zip(obj1, obj2))
        return better_in_all and better_in_one
    
    def _calculate_crowding_distance(self, front):
        n = len(front)
        if n == 0:
            return
        
        for ind in front:
            ind.crowding_distance = 0.0
        
        for obj_idx in range(2):
            front.sort(key=lambda x: x.objectives[obj_idx])
            front[0].crowding_distance = float('inf')
            front[-1].crowding_distance = float('inf')
            
            obj_range = front[-1].objectives[obj_idx] - front[0].objectives[obj_idx]
            if obj_range == 0:
                continue
            
            for i in range(1, n - 1):
                distance = (front[i+1].objectives[obj_idx] -
                           front[i-1].objectives[obj_idx]) / obj_range
                front[i].crowding_distance += distance


# ============================================================================
# MOEA/D算法（用于对比）
# ============================================================================

class MOEAD:
    """MOEA/D算法"""
    
    def __init__(self, instance: Dict, pop_size: int = 100, max_gen: int = 200,
                 neighbor_size: int = 20, mutation_rate: float = 0.1,
                 peak_power_limit: float = None):
        self.instance = instance
        self.pop_size = pop_size
        self.max_gen = max_gen
        self.neighbor_size = neighbor_size
        self.mutation_rate = mutation_rate
        
        self.encoder = ScheduleEncoder(
            instance['n'], instance['k'], instance['f'],
            instance['machines_per_stage']
        )
        self.evaluator = ScheduleEvaluator(instance, peak_power_limit)
        
        self.population = []
        self.weights = []
        self.neighbors = []
        self.pareto_front = []
        self.history = []
        self.ideal_point = [float('inf'), float('inf')]
    
    def run(self, verbose: bool = True) -> List[Individual]:
        """运行MOEA/D"""
        if verbose:
            print(f"\n开始运行 MOEA/D...")
            print(f"  种群大小: {self.pop_size}, 最大代数: {self.max_gen}")
        
        start_time = time.time()
        
        self._initialize_weights()
        self._calculate_neighbors()
        self.population = self._initialize_population()
        self._evaluate_population(self.population)
        self._update_ideal_point()
        
        for gen in range(self.max_gen):
            for i in range(self.pop_size):
                parent_indices = random.sample(self.neighbors[i], 2)
                parent1 = self.population[parent_indices[0]]
                parent2 = self.population[parent_indices[1]]
                
                child_schedule = self.encoder.crossover(parent1.schedule, parent2.schedule)
                child_schedule = self.encoder.mutate(child_schedule, self.mutation_rate)
                
                child = Individual(schedule=child_schedule, objectives=(0, 0))
                self._evaluate_individual(child)
                self._update_ideal_point_with(child.objectives)
                
                for j in self.neighbors[i]:
                    old_tchebycheff = self._tchebycheff(
                        self.population[j].objectives, self.weights[j]
                    )
                    new_tchebycheff = self._tchebycheff(
                        child.objectives, self.weights[j]
                    )
                    
                    if new_tchebycheff < old_tchebycheff:
                        self.population[j] = copy.deepcopy(child)
            
            self._update_pareto_front()
            
            if len(self.pareto_front) > 0:
                avg_makespan = np.mean([ind.objectives[0] for ind in self.pareto_front])
                avg_energy = np.mean([ind.objectives[1] for ind in self.pareto_front])
                self.history.append({
                    'generation': gen,
                    'pareto_size': len(self.pareto_front),
                    'avg_makespan': avg_makespan,
                    'avg_energy': avg_energy
                })
            
            if verbose and (gen + 1) % 20 == 0:
                print(f"  代数 {gen+1}/{self.max_gen}: Pareto前沿 {len(self.pareto_front)} 个解")
        
        elapsed_time = time.time() - start_time
        
        if verbose:
            print(f"  完成! 用时: {elapsed_time:.2f}秒")
            print(f"  最终Pareto前沿: {len(self.pareto_front)} 个解")
        
        return self.pareto_front
    
    def _initialize_weights(self):
        self.weights = []
        for i in range(self.pop_size):
            weight = i / (self.pop_size - 1)
            self.weights.append([weight, 1 - weight])
    
    def _calculate_neighbors(self):
        self.neighbors = []
        for i in range(self.pop_size):
            distances = []
            for j in range(self.pop_size):
                if i != j:
                    dist = np.linalg.norm(
                        np.array(self.weights[i]) - np.array(self.weights[j])
                    )
                    distances.append((j, dist))
            
            distances.sort(key=lambda x: x[1])
            neighbors = [i] + [x[0] for x in distances[:self.neighbor_size-1]]
            self.neighbors.append(neighbors)
    
    def _initialize_population(self):
        population = []
        for _ in range(self.pop_size):
            schedule = self.encoder.generate_random_schedule()
            individual = Individual(schedule=schedule, objectives=(0, 0))
            population.append(individual)
        return population
    
    def _evaluate_population(self, population):
        for ind in population:
            self._evaluate_individual(ind)
    
    def _evaluate_individual(self, ind):
        metrics = self.evaluator.evaluate(ind.schedule)
        if not metrics['feasible']:
            penalty = metrics['max_violation'] * 100
            ind.objectives = (
                metrics['makespan'] + penalty,
                metrics['total_energy'] + penalty
            )
        else:
            ind.objectives = (metrics['makespan'], metrics['total_energy'])
    
    def _update_ideal_point(self):
        for ind in self.population:
            self._update_ideal_point_with(ind.objectives)
    
    def _update_ideal_point_with(self, objectives):
        self.ideal_point[0] = min(self.ideal_point[0], objectives[0])
        self.ideal_point[1] = min(self.ideal_point[1], objectives[1])
    
    def _tchebycheff(self, objectives, weight):
        return max(
            weight[i] * abs(objectives[i] - self.ideal_point[i])
            for i in range(2)
        )
    
    def _update_pareto_front(self):
        self.pareto_front = []
        for ind in self.population:
            is_dominated = False
            for other in self.population:
                if self._dominates(other.objectives, ind.objectives):
                    is_dominated = True
                    break
            if not is_dominated:
                self.pareto_front.append(copy.deepcopy(ind))
    
    def _dominates(self, obj1, obj2):
        better_in_all = all(o1 <= o2 for o1, o2 in zip(obj1, obj2))
        better_in_one = any(o1 < o2 for o1, o2 in zip(obj1, obj2))
        return better_in_all and better_in_one


# ============================================================================
# SPEA2算法（用于对比）
# ============================================================================

class SPEA2:
    """SPEA2算法"""
    
    def __init__(self, instance: Dict, pop_size: int = 100, archive_size: int = 100,
                 max_gen: int = 200, crossover_rate: float = 0.9,
                 mutation_rate: float = 0.1, peak_power_limit: float = None):
        self.instance = instance
        self.pop_size = pop_size
        self.archive_size = archive_size
        self.max_gen = max_gen
        self.crossover_rate = crossover_rate
        self.mutation_rate = mutation_rate
        
        self.encoder = ScheduleEncoder(
            instance['n'], instance['k'], instance['f'],
            instance['machines_per_stage']
        )
        self.evaluator = ScheduleEvaluator(instance, peak_power_limit)
        
        self.population = []
        self.archive = []
        self.pareto_front = []
        self.history = []
    
    def run(self, verbose: bool = True) -> List[Individual]:
        """运行SPEA2"""
        if verbose:
            print(f"\n开始运行 SPEA2...")
            print(f"  种群大小: {self.pop_size}, 存档大小: {self.archive_size}, 最大代数: {self.max_gen}")
        
        start_time = time.time()
        
        self.population = self._initialize_population()
        self._evaluate_population(self.population)
        self.archive = []
        
        for gen in range(self.max_gen):
            combined = self.population + self.archive
            self._calculate_fitness(combined)
            self.archive = self._environmental_selection(combined)
            
            if len(self.archive) < self.archive_size:
                remaining = self.archive_size - len(self.archive)
                combined.sort(key=lambda x: x.rank)
                self.archive.extend(combined[:remaining])
            
            self.population = self._mating_selection()
            self.pareto_front = [ind for ind in self.archive if ind.rank < 1]
            
            if len(self.pareto_front) > 0:
                avg_makespan = np.mean([ind.objectives[0] for ind in self.pareto_front])
                avg_energy = np.mean([ind.objectives[1] for ind in self.pareto_front])
                self.history.append({
                    'generation': gen,
                    'pareto_size': len(self.pareto_front),
                    'avg_makespan': avg_makespan,
                    'avg_energy': avg_energy
                })
            
            if verbose and (gen + 1) % 20 == 0:
                print(f"  代数 {gen+1}/{self.max_gen}: Pareto前沿 {len(self.pareto_front)} 个解")
        
        elapsed_time = time.time() - start_time
        
        if verbose:
            print(f"  完成! 用时: {elapsed_time:.2f}秒")
            print(f"  最终Pareto前沿: {len(self.pareto_front)} 个解")
        
        return self.pareto_front
    
    def _initialize_population(self):
        population = []
        for _ in range(self.pop_size):
            schedule = self.encoder.generate_random_schedule()
            individual = Individual(schedule=schedule, objectives=(0, 0))
            population.append(individual)
        return population
    
    def _evaluate_population(self, population):
        for ind in population:
            metrics = self.evaluator.evaluate(ind.schedule)
            if not metrics['feasible']:
                penalty = metrics['max_violation'] * 100
                ind.objectives = (
                    metrics['makespan'] + penalty,
                    metrics['total_energy'] + penalty
                )
            else:
                ind.objectives = (metrics['makespan'], metrics['total_energy'])
    
    def _calculate_fitness(self, population):
        for i, ind in enumerate(population):
            ind.rank = 0
            for j, other in enumerate(population):
                if i != j and self._dominates(other.objectives, ind.objectives):
                    ind.rank += 1
    
    def _dominates(self, obj1, obj2):
        better_in_all = all(o1 <= o2 for o1, o2 in zip(obj1, obj2))
        better_in_one = any(o1 < o2 for o1, o2 in zip(obj1, obj2))
        return better_in_all and better_in_one
    
    def _environmental_selection(self, population):
        non_dominated = [ind for ind in population if ind.rank == 0]
        if len(non_dominated) <= self.archive_size:
            return non_dominated
        return self._truncate(non_dominated, self.archive_size)
    
    def _truncate(self, population, size):
        while len(population) > size:
            min_dist = float('inf')
            remove_idx = 0
            
            for i, ind in enumerate(population):
                distances = []
                for j, other in enumerate(population):
                    if i != j:
                        dist = np.linalg.norm(
                            np.array(ind.objectives) - np.array(other.objectives)
                        )
                        distances.append(dist)
                
                if distances:
                    min_ind_dist = min(distances)
                    if min_ind_dist < min_dist:
                        min_dist = min_ind_dist
                        remove_idx = i
            
            population.pop(remove_idx)
        
        return population
    
    def _mating_selection(self):
        offspring = []
        while len(offspring) < self.pop_size:
            parent1 = self._tournament_selection()
            parent2 = self._tournament_selection()
            
            if random.random() < self.crossover_rate:
                child_schedule = self.encoder.crossover(parent1.schedule, parent2.schedule)
            else:
                child_schedule = copy.deepcopy(parent1.schedule)
            
            child_schedule = self.encoder.mutate(child_schedule, self.mutation_rate)
            child = Individual(schedule=child_schedule, objectives=(0, 0))
            metrics = self.evaluator.evaluate(child.schedule)
            
            if not metrics['feasible']:
                penalty = metrics['max_violation'] * 100
                child.objectives = (
                    metrics['makespan'] + penalty,
                    metrics['total_energy'] + penalty
                )
            else:
                child.objectives = (metrics['makespan'], metrics['total_energy'])
            
            offspring.append(child)
        
        return offspring
    
    def _tournament_selection(self, tournament_size: int = 2):
        tournament = random.sample(self.archive, min(tournament_size, len(self.archive)))
        tournament.sort(key=lambda x: x.rank)
        return tournament[0]


# ============================================================================
# KMOEA算法（知识驱动的多目标优化算法）
# ============================================================================

@dataclass
class Individual3D:
    """3D编码个体类 - 用于KMOEA"""
    factory_assignment: List[int]  # 工厂分配向量
    scheduling: List[int]  # 调度序列向量
    speed_setting: List[int]  # 速度设置向量 (1=normal, 2=fast)
    schedule: List[List] = field(default_factory=list)  # 解码后的调度方案
    objectives: Tuple[float, float] = (float('inf'), float('inf'))
    rank: int = 0
    crowding_distance: float = 0.0
    dominated_count: int = 0
    dominating_set: List = field(default_factory=list)
    fitness: float = 0.0


class ScheduleEncoder3D:
    """3D调度编码器 - 用于KMOEA"""
    
    def __init__(self, n_jobs: int, n_stages: int, n_factories: int,
                 machines_per_stage: List[List]):
        self.n_jobs = n_jobs
        self.n_stages = n_stages
        self.n_factories = n_factories
        self.machines_per_stage = machines_per_stage
    
    def decode_to_schedule(self, ind: Individual3D) -> List[List]:
        """将3D编码解码为调度方案"""
        schedule = []
        
        # 按照scheduling序列处理每个作业
        for job_idx in range(self.n_jobs):
            job_schedule = []
            factory = ind.factory_assignment[job_idx]
            
            for stage in range(self.n_stages):
                # 选择该工厂该阶段的第一台可用机器（简化版本）
                n_machines = self.machines_per_stage[factory][stage]
                machine = job_idx % n_machines  # 简单的机器选择策略
                
                job_schedule.append([(factory, machine)])
            
            schedule.append(job_schedule)
        
        return schedule
    
    def generate_random_individual(self) -> Individual3D:
        """生成随机3D个体"""
        # 工厂分配
        factory_assignment = [random.randint(0, self.n_factories - 1) 
                            for _ in range(self.n_jobs)]
        
        # 调度序列
        scheduling = list(range(self.n_jobs))
        random.shuffle(scheduling)
        
        # 速度设置（1=normal, 2=fast）
        speed_setting = [random.choice([1, 2]) 
                        for _ in range(self.n_jobs * self.n_stages)]
        
        ind = Individual3D(
            factory_assignment=factory_assignment,
            scheduling=scheduling,
            speed_setting=speed_setting
        )
        
        ind.schedule = self.decode_to_schedule(ind)
        return ind
    
    def generate_lowest_speed_individual(self) -> Individual3D:
        """生成最低速度个体（Lemma 3）"""
        factory_assignment = [random.randint(0, self.n_factories - 1) 
                            for _ in range(self.n_jobs)]
        scheduling = list(range(self.n_jobs))
        random.shuffle(scheduling)
        speed_setting = [1] * (self.n_jobs * self.n_stages)  # 全部最低速度
        
        ind = Individual3D(
            factory_assignment=factory_assignment,
            scheduling=scheduling,
            speed_setting=speed_setting
        )
        
        ind.schedule = self.decode_to_schedule(ind)
        return ind
    
    def generate_highest_speed_individual(self) -> Individual3D:
        """生成最高速度个体（Lemma 3）"""
        factory_assignment = [random.randint(0, self.n_factories - 1) 
                            for _ in range(self.n_jobs)]
        scheduling = list(range(self.n_jobs))
        random.shuffle(scheduling)
        speed_setting = [2] * (self.n_jobs * self.n_stages)  # 全部最高速度
        
        ind = Individual3D(
            factory_assignment=factory_assignment,
            scheduling=scheduling,
            speed_setting=speed_setting
        )
        
        ind.schedule = self.decode_to_schedule(ind)
        return ind


class KMOEA:
    """
    Knowledge-based Multi-Objective Evolutionary Algorithm
    基于论文: Li et al. (2022) IEEE TII
    """
    
    def __init__(self, instance: Dict, pop_size: int, max_gen: int,
                 crossover_rate: float = 0.7, mutation_rate: float = 0.5,
                 local_search_prob: float = 0.5, peak_power_limit: float = None):
        self.instance = instance
        self.pop_size = pop_size
        self.max_gen = max_gen
        self.crossover_rate = crossover_rate
        self.mutation_rate = mutation_rate
        self.local_search_prob = local_search_prob
        
        # 初始化编码器和评估器
        self.encoder3d = ScheduleEncoder3D(
            instance['n'], instance['k'], instance['f'],
            instance['machines_per_stage']
        )
        self.evaluator = ScheduleEvaluator(instance, peak_power_limit)
        
        # 种群和Pareto前沿
        self.population = []
        self.pareto_front = []
        self.history = []
        
        # 参考点（用于AR-MOEA风格的选择）
        self.reference_points = self._generate_reference_points()
    
    def run(self, verbose: bool = True) -> List[Individual]:
        """运行KMOEA算法"""
        if verbose:
            print(f"\n开始运行 KMOEA...")
            print(f"  种群大小: {self.pop_size}, 最大代数: {self.max_gen}")
        
        start_time = time.time()
        
        # 初始化种群（基于Lemma 3）
        self.population = self._initialize_population_with_knowledge()
        self._evaluate_population(self.population)
        
        # 主进化循环
        for gen in range(self.max_gen):
            # 生成后代
            offspring = []
            
            while len(offspring) < self.pop_size:
                # 选择父代
                parent1 = self._tournament_selection(self.population)
                parent2 = self._tournament_selection(self.population)
                
                # 交叉（PSJOX）
                if random.random() < self.crossover_rate:
                    child = self._psjox_crossover(parent1, parent2)
                else:
                    child = copy.deepcopy(parent1)
                
                # 变异
                if random.random() < self.mutation_rate:
                    child = self._mutate(child)
                
                # 解码
                child.schedule = self.encoder3d.decode_to_schedule(child)
                
                # 评估
                self._evaluate_individual(child)
                
                # 局部搜索（SAR）
                if random.random() < self.local_search_prob:
                    child = self._speed_adjustment_local_search(child)
                
                offspring.append(child)
            
            # 环境选择
            combined = self.population + offspring
            self._non_dominated_sort(combined)
            self.population = self._environmental_selection(combined, self.pop_size)
            
            # 更新Pareto前沿
            self._update_pareto_front()
            
            # 记录历史
            if len(self.pareto_front) > 0:
                avg_makespan = np.mean([ind.objectives[0] for ind in self.pareto_front])
                avg_energy = np.mean([ind.objectives[1] for ind in self.pareto_front])
                self.history.append({
                    'generation': gen,
                    'pareto_size': len(self.pareto_front),
                    'avg_makespan': avg_makespan,
                    'avg_energy': avg_energy
                })
            
            if verbose and (gen + 1) % 20 == 0:
                print(f"  代数 {gen+1}/{self.max_gen}: Pareto前沿 {len(self.pareto_front)} 个解")
        
        elapsed_time = time.time() - start_time
        
        if verbose:
            print(f"  完成! 用时: {elapsed_time:.2f}秒")
            print(f"  最终Pareto前沿: {len(self.pareto_front)} 个解")
        
        # 转换为标准Individual格式返回
        return self._convert_to_standard_individuals(self.pareto_front)
    
    def _initialize_population_with_knowledge(self) -> List[Individual3D]:
        """基于Lemma 3的知识驱动初始化"""
        population = []
        
        # 生成一些最低速度的个体（高能效）
        for _ in range(self.pop_size // 4):
            ind = self.encoder3d.generate_lowest_speed_individual()
            population.append(ind)
        
        # 生成一些最高速度的个体（高速度）
        for _ in range(self.pop_size // 4):
            ind = self.encoder3d.generate_highest_speed_individual()
            population.append(ind)
        
        # 其余用随机个体填充
        while len(population) < self.pop_size:
            ind = self.encoder3d.generate_random_individual()
            population.append(ind)
        
        return population
    
    def _psjox_crossover(self, parent1: Individual3D, parent2: Individual3D) -> Individual3D:
        """Pareto Similar Job Order Crossover（PSJOX）"""
        # 基于Pareto前沿构建job occurrence向量
        job_occurrence = self._calculate_job_occurrence()
        
        # 创建子代
        child = Individual3D(
            factory_assignment=[],
            scheduling=[],
            speed_setting=[]
        )
        
        # 工厂分配向量：两点交叉
        r1, r2 = sorted(random.sample(range(self.encoder3d.n_jobs), 2))
        child.factory_assignment = (
            parent1.factory_assignment[:r1] + 
            parent2.factory_assignment[r1:r2] + 
            parent1.factory_assignment[r2:]
        )
        
        # 调度序列：基于job occurrence的启发式交叉
        if job_occurrence:
            # 使用job occurrence作为指导
            child.scheduling = self._guided_scheduling_crossover(
                parent1.scheduling, parent2.scheduling, job_occurrence
            )
        else:
            # 退化为标准两点交叉
            child.scheduling = self._standard_scheduling_crossover(
                parent1.scheduling, parent2.scheduling
            )
        
        # 速度设置：两点交叉
        total_ops = self.encoder3d.n_jobs * self.encoder3d.n_stages
        r1, r2 = sorted(random.sample(range(total_ops), 2))
        child.speed_setting = (
            parent1.speed_setting[:r1] + 
            parent2.speed_setting[r1:r2] + 
            parent1.speed_setting[r2:]
        )
        
        return child
    
    def _calculate_job_occurrence(self) -> Dict[int, int]:
        """计算Pareto前沿中每个位置上job的出现次数"""
        if not self.pareto_front:
            return {}
        
        occurrence = {}
        for pos in range(self.encoder3d.n_jobs):
            job_counts = {}
            for ind in self.pareto_front:
                if hasattr(ind, 'scheduling') and pos < len(ind.scheduling):
                    job = ind.scheduling[pos]
                    job_counts[job] = job_counts.get(job, 0) + 1
            
            if job_counts:
                # 选择出现次数最多的job
                most_common_job = max(job_counts, key=job_counts.get)
                occurrence[pos] = most_common_job
        
        return occurrence
    
    def _guided_scheduling_crossover(self, sched1: List[int], sched2: List[int],
                                    job_occurrence: Dict[int, int]) -> List[int]:
        """基于job occurrence的引导式调度交叉"""
        child_sched = []
        used_jobs = set()
        
        # 首先使用job occurrence中的建议
        for pos in range(self.encoder3d.n_jobs):
            if pos in job_occurrence:
                job = job_occurrence[pos]
                if job not in used_jobs:
                    child_sched.append(job)
                    used_jobs.add(job)
        
        # 用parent1和parent2的剩余job填充
        for job in sched1 + sched2:
            if job not in used_jobs and len(child_sched) < self.encoder3d.n_jobs:
                child_sched.append(job)
                used_jobs.add(job)
        
        # 如果还有缺失的job，随机填充
        all_jobs = set(range(self.encoder3d.n_jobs))
        missing_jobs = list(all_jobs - used_jobs)
        random.shuffle(missing_jobs)
        child_sched.extend(missing_jobs)
        
        return child_sched[:self.encoder3d.n_jobs]
    
    @staticmethod
    def _standard_scheduling_crossover(sched1: List[int],
                                       sched2: List[int]) -> List[int]:
        """标准的调度序列交叉（OX交叉）"""
        size = len(sched1)
        r1, r2 = sorted(random.sample(range(size), 2))
        
        # 从parent1复制r1到r2之间的基因
        child = [-1] * size
        child[r1:r2] = sched1[r1:r2]
        
        # 从parent2填充剩余位置
        parent2_filtered = [job for job in sched2 if job not in child[r1:r2]]
        
        # 填充r2之后的位置
        idx = r2
        for job in parent2_filtered:
            if idx >= size:
                idx = 0
            if child[idx] == -1:
                child[idx] = job
                idx += 1
        
        # 填充0到r1之间的位置
        for i in range(r1):
            if child[i] == -1:
                for job in parent2_filtered:
                    if job not in child:
                        child[i] = job
                        break
        
        return child
    
    def _mutate(self, ind: Individual3D) -> Individual3D:
        """变异操作"""
        mutated = copy.deepcopy(ind)
        
        # 工厂分配变异：随机改变某个job的工厂
        if random.random() < 0.3:
            pos = random.randint(0, self.encoder3d.n_jobs - 1)
            mutated.factory_assignment[pos] = random.randint(
                0, self.encoder3d.n_factories - 1
            )
        
        # 调度序列变异：swap或insert
        if random.random() < 0.5:
            # Swap
            pos1, pos2 = random.sample(range(self.encoder3d.n_jobs), 2)
            mutated.scheduling[pos1], mutated.scheduling[pos2] = \
                mutated.scheduling[pos2], mutated.scheduling[pos1]
        else:
            # Insert
            pos1 = random.randint(0, self.encoder3d.n_jobs - 1)
            pos2 = random.randint(0, self.encoder3d.n_jobs - 1)
            job = mutated.scheduling.pop(pos1)
            mutated.scheduling.insert(pos2, job)
        
        # 速度设置变异：随机改变某个操作的速度
        if random.random() < 0.3:
            pos = random.randint(0, len(mutated.speed_setting) - 1)
            mutated.speed_setting[pos] = 3 - mutated.speed_setting[pos]  # 1<->2切换
        
        return mutated
    
    def _speed_adjustment_local_search(self, ind: Individual3D) -> Individual3D:
        """Speed Adjustment Rule (SAR) 局部搜索 - 基于Lemma 1和2"""
        improved = copy.deepcopy(ind)
        
        # 简化版本：随机尝试降低一些fast速度的操作
        for i in range(len(improved.speed_setting)):
            if improved.speed_setting[i] == 2:  # fast speed
                # 尝试降低到normal speed
                old_speed = improved.speed_setting[i]
                improved.speed_setting[i] = 1
                
                # 重新解码和评估
                improved.schedule = self.encoder3d.decode_to_schedule(improved)
                self._evaluate_individual(improved)
                
                # 如果变差，恢复
                if self._dominates(ind.objectives, improved.objectives):
                    improved.speed_setting[i] = old_speed
                    improved.schedule = self.encoder3d.decode_to_schedule(improved)
                    self._evaluate_individual(improved)
                else:
                    # 如果改进，继续使用新速度
                    break
        
        return improved
    
    def _evaluate_population(self, population: List[Individual3D]):
        """评估种群"""
        for ind in population:
            self._evaluate_individual(ind)
    
    def _evaluate_individual(self, ind: Individual3D):
        """评估个体"""
        metrics = self.evaluator.evaluate(ind.schedule)
        
        if not metrics['feasible']:
            penalty = metrics['max_violation'] * 100
            ind.objectives = (
                metrics['makespan'] + penalty,
                metrics['total_energy'] + penalty
            )
        else:
            ind.objectives = (metrics['makespan'], metrics['total_energy'])
    
    @staticmethod
    def _tournament_selection(population: List[Individual3D],
                              tournament_size: int = 2) -> Individual3D:
        """锦标赛选择"""
        tournament = random.sample(population, min(tournament_size, len(population)))
        tournament.sort(key=lambda x: (x.rank, -x.crowding_distance))
        return copy.deepcopy(tournament[0])
    
    def _non_dominated_sort(self, population: List[Individual3D]):
        """快速非支配排序"""
        for ind in population:
            ind.dominated_count = 0
            ind.dominating_set = []
        
        for i, ind1 in enumerate(population):
            for j, ind2 in enumerate(population):
                if i != j:
                    if self._dominates(ind1.objectives, ind2.objectives):
                        ind1.dominating_set.append(ind2)
                    elif self._dominates(ind2.objectives, ind1.objectives):
                        ind1.dominated_count += 1
        
        fronts = []
        current_front = [ind for ind in population if ind.dominated_count == 0]
        
        for ind in current_front:
            ind.rank = 0
        
        front_index = 0
        while current_front:
            fronts.append(current_front)
            next_front = []
            
            for ind1 in current_front:
                for ind2 in ind1.dominating_set:
                    ind2.dominated_count -= 1
                    if ind2.dominated_count == 0:
                        ind2.rank = front_index + 1
                        next_front.append(ind2)
            
            current_front = next_front
            front_index += 1
    
    def _environmental_selection(self, population: List[Individual3D],
                                 target_size: int) -> List[Individual3D]:
        """环境选择（基于rank和crowding distance）"""
        # 按rank排序
        population.sort(key=lambda x: x.rank)
        
        selected = []
        current_rank = 0
        
        while len(selected) < target_size:
            # 获取当前rank的所有个体
            current_front = [ind for ind in population if ind.rank == current_rank]
            
            if not current_front:
                break
            
            if len(selected) + len(current_front) <= target_size:
                # 整个front都可以加入
                selected.extend(current_front)
            else:
                # 需要根据crowding distance选择
                self._calculate_crowding_distance(current_front)
                current_front.sort(key=lambda x: x.crowding_distance, reverse=True)
                
                remaining = target_size - len(selected)
                selected.extend(current_front[:remaining])
                break
            
            current_rank += 1
        
        return selected
    
    def _calculate_crowding_distance(self, front: List[Individual3D]):
        """计算拥挤距离"""
        n = len(front)
        if n == 0:
            return
        
        for ind in front:
            ind.crowding_distance = 0.0
        
        # 对每个目标计算crowding distance
        for obj_idx in range(2):
            front.sort(key=lambda x: x.objectives[obj_idx])
            
            # 边界个体设置为无穷大
            front[0].crowding_distance = float('inf')
            front[-1].crowding_distance = float('inf')
            
            obj_range = front[-1].objectives[obj_idx] - front[0].objectives[obj_idx]
            
            if obj_range == 0:
                continue
            
            for i in range(1, n - 1):
                distance = (front[i+1].objectives[obj_idx] -
                           front[i-1].objectives[obj_idx]) / obj_range
                front[i].crowding_distance += distance
    
    def _dominates(self, obj1: Tuple[float, float],
                   obj2: Tuple[float, float]) -> bool:
        """判断obj1是否支配obj2"""
        better_in_all = all(o1 <= o2 for o1, o2 in zip(obj1, obj2))
        better_in_one = any(o1 < o2 for o1, o2 in zip(obj1, obj2))
        return better_in_all and better_in_one
    
    def _update_pareto_front(self):
        """更新全局Pareto前沿"""
        self.pareto_front = []
        for ind in self.population:
            is_dominated = False
            for other in self.population:
                if self._dominates(other.objectives, ind.objectives):
                    is_dominated = True
                    break
            if not is_dominated:
                self.pareto_front.append(copy.deepcopy(ind))
    
    def _generate_reference_points(self) -> np.ndarray:
        """生成参考点（用于AR-MOEA风格的选择）"""
        # 简化版本：在目标空间均匀分布参考点
        n_points = 100
        points = []
        for i in range(n_points):
            w1 = i / (n_points - 1)
            w2 = 1 - w1
            points.append([w1, w2])
        return np.array(points)
    
    def _convert_to_standard_individuals(self, 
                                        population: List[Individual3D]) -> List[Individual]:
        """将Individual3D转换为标准Individual格式"""
        standard_pop = []
        for ind3d in population:
            ind = Individual(
                schedule=ind3d.schedule,
                objectives=ind3d.objectives,
                rank=ind3d.rank,
                crowding_distance=ind3d.crowding_distance
            )
            standard_pop.append(ind)
        return standard_pop


# ============================================================================
# HMOMA算法（混合多目标Memetic算法）
# ============================================================================

class HMOMA:
    """
    Hybrid Multiobjective Memetic Algorithm (HMOMA)
    混合多目标Memetic算法 - 用于能效调度
    结合遗传算法和局部搜索
    """
    
    def __init__(self, instance: Dict, pop_size: int, max_gen: int,
                 crossover_rate: float = 0.7, mutation_rate: float = 0.3,
                 local_search_prob: float = 0.5, local_search_iter: int = 10,
                 peak_power_limit: float = None):
        self.instance = instance
        self.pop_size = pop_size
        self.max_gen = max_gen
        self.crossover_rate = crossover_rate
        self.mutation_rate = mutation_rate
        self.local_search_prob = local_search_prob  # 局部搜索概率
        self.local_search_iter = local_search_iter  # 局部搜索迭代次数
        
        # 初始化编码器和评估器
        self.encoder = ScheduleEncoder(
            instance['n'], instance['k'], instance['f'],
            instance['machines_per_stage']
        )
        self.evaluator = ScheduleEvaluator(instance, peak_power_limit)
        
        # 种群和Pareto前沿
        self.population = []
        self.pareto_front = []
        self.history = []
        
        # Memetic算法特有：外部存档
        self.archive = []
        self.archive_size = pop_size
    
    def run(self, verbose: bool = True) -> List[Individual]:
        """运行HMOMA算法"""
        if verbose:
            print(f"\n开始运行 HMOMA...")
            print(f"  种群大小: {self.pop_size}, 最大代数: {self.max_gen}")
            print(f"  局部搜索概率: {self.local_search_prob}")
        
        start_time = time.time()
        
        # 初始化种群
        self.population = self._initialize_population()
        self._evaluate_population(self.population)
        
        # 初始化外部存档
        self.archive = copy.deepcopy(self.population)
        self._update_archive()
        
        # 主进化循环
        for gen in range(self.max_gen):
            # 生成后代
            offspring = []
            
            while len(offspring) < self.pop_size:
                # 选择父代（从种群和存档中选择）
                parent1 = self._tournament_selection(self.population + self.archive)
                parent2 = self._tournament_selection(self.population + self.archive)
                
                # 交叉
                if random.random() < self.crossover_rate:
                    child_schedule = self.encoder.crossover(parent1.schedule, parent2.schedule)
                else:
                    child_schedule = copy.deepcopy(parent1.schedule)
                
                # 变异
                child_schedule = self.encoder.mutate(child_schedule, self.mutation_rate)
                
                child = Individual(schedule=child_schedule, objectives=(0, 0))
                offspring.append(child)
            
            # 评估后代
            self._evaluate_population(offspring)
            
            # Memetic算法核心：局部搜索
            offspring = self._apply_local_search(offspring)
            
            # 环境选择
            combined = self.population + offspring
            self._non_dominated_sort(combined)
            self.population = self._environmental_selection(combined, self.pop_size)
            
            # 更新外部存档
            self.archive = self.population + self.archive
            self._update_archive()
            
            # 更新Pareto前沿
            self._update_pareto_front()
            
            # 记录历史
            if len(self.pareto_front) > 0:
                avg_makespan = np.mean([ind.objectives[0] for ind in self.pareto_front])
                avg_energy = np.mean([ind.objectives[1] for ind in self.pareto_front])
                self.history.append({
                    'generation': gen,
                    'pareto_size': len(self.pareto_front),
                    'avg_makespan': avg_makespan,
                    'avg_energy': avg_energy
                })
            
            if verbose and (gen + 1) % 20 == 0:
                print(f"  代数 {gen+1}/{self.max_gen}: Pareto前沿 {len(self.pareto_front)} 个解, "
                      f"存档 {len(self.archive)} 个解")
        
        elapsed_time = time.time() - start_time
        
        if verbose:
            print(f"  完成! 用时: {elapsed_time:.2f}秒")
            print(f"  最终Pareto前沿: {len(self.pareto_front)} 个解")
        
        return self.pareto_front
    
    def _initialize_population(self) -> List[Individual]:
        """初始化种群"""
        population = []
        for _ in range(self.pop_size):
            schedule = self.encoder.generate_random_schedule()
            individual = Individual(schedule=schedule, objectives=(0, 0))
            population.append(individual)
        return population
    
    def _evaluate_population(self, population: List[Individual]):
        """评估种群"""
        for ind in population:
            metrics = self.evaluator.evaluate(ind.schedule)
            if not metrics['feasible']:
                penalty = metrics['max_violation'] * 100
                ind.objectives = (
                    metrics['makespan'] + penalty,
                    metrics['total_energy'] + penalty
                )
            else:
                ind.objectives = (metrics['makespan'], metrics['total_energy'])
    
    def _apply_local_search(self, population: List[Individual]) -> List[Individual]:
        """
        Memetic算法核心：应用局部搜索
        使用变邻域搜索（VNS）策略
        """
        improved_pop = []
        
        for ind in population:
            if random.random() < self.local_search_prob:
                # 应用局部搜索
                improved = self._variable_neighborhood_search(ind)
                improved_pop.append(improved)
            else:
                improved_pop.append(ind)
        
        return improved_pop
    
    def _variable_neighborhood_search(self, individual: Individual) -> Individual:
        """
        变邻域搜索（VNS）
        尝试多种邻域操作来改进个体
        """
        current = copy.deepcopy(individual)
        best = copy.deepcopy(individual)
        
        for _ in range(self.local_search_iter):
            # 随机选择邻域操作
            neighbor_type = random.choice(['swap', 'insert', 'reverse'])
            
            if neighbor_type == 'swap':
                neighbor = self._swap_neighbor(current)
            elif neighbor_type == 'insert':
                neighbor = self._insert_neighbor(current)
            else:  # reverse
                neighbor = self._reverse_neighbor(current)
            
            # 评估邻居
            self._evaluate_population([neighbor])
            
            # 如果邻居更好或非支配，接受
            if self._is_better_or_nondominated(neighbor, current):
                current = neighbor
                if self._dominates(neighbor.objectives, best.objectives):
                    best = neighbor
        
        return best
    
    def _swap_neighbor(self, individual: Individual) -> Individual:
        """交换操作：交换两个作业在某个工厂某个阶段的机器分配"""
        neighbor = copy.deepcopy(individual)
        schedule = neighbor.schedule
        
        # 随机选择两个作业
        if len(schedule) >= 2:
            j1, j2 = random.sample(range(len(schedule)), 2)
            # 随机选择阶段
            stage = random.randint(0, len(schedule[0]) - 1)
            
            # 交换机器分配
            if len(schedule[j1][stage]) > 0 and len(schedule[j2][stage]) > 0:
                schedule[j1][stage], schedule[j2][stage] = \
                    schedule[j2][stage], schedule[j1][stage]
        
        neighbor.schedule = schedule
        return neighbor
    
    def _insert_neighbor(self, individual: Individual) -> Individual:
        """插入操作：在同一阶段内移动一个操作"""
        neighbor = copy.deepcopy(individual)
        schedule = neighbor.schedule
        
        if len(schedule) >= 2:
            # 随机选择作业和阶段
            job = random.randint(0, len(schedule) - 1)
            stage = random.randint(0, len(schedule[0]) - 1)
            
            # 尝试改变工厂分配
            if len(schedule[job][stage]) > 0:
                factory, machine = schedule[job][stage][0]
                # 改变到另一个工厂
                n_factories = self.instance['f']
                if n_factories > 1:
                    new_factory = random.choice([f for f in range(n_factories) if f != factory])
                    n_machines = self.instance['machines_per_stage'][new_factory][stage]
                    new_machine = random.randint(0, n_machines - 1)
                    schedule[job][stage] = [(new_factory, new_machine)]
        
        neighbor.schedule = schedule
        return neighbor
    
    def _reverse_neighbor(self, individual: Individual) -> Individual:
        """反转操作：反转一段作业序列"""
        neighbor = copy.deepcopy(individual)
        schedule = neighbor.schedule
        
        if len(schedule) >= 3:
            # 随机选择起始和结束位置
            start = random.randint(0, len(schedule) - 2)
            end = random.randint(start + 1, len(schedule) - 1)
            
            # 反转这段序列
            schedule[start:end+1] = schedule[start:end+1][::-1]
        
        neighbor.schedule = schedule
        return neighbor
    
    def _is_better_or_nondominated(self, ind1: Individual, ind2: Individual) -> bool:
        """判断ind1是否优于或不被ind2支配"""
        return (self._dominates(ind1.objectives, ind2.objectives) or 
                not self._dominates(ind2.objectives, ind1.objectives))
    
    def _tournament_selection(self, population: List[Individual],
                             tournament_size: int = 2) -> Individual:
        """锦标赛选择"""
        tournament = random.sample(population, min(tournament_size, len(population)))
        tournament.sort(key=lambda x: (x.rank, -x.crowding_distance))
        return copy.deepcopy(tournament[0])
    
    def _non_dominated_sort(self, population: List[Individual]):
        """快速非支配排序"""
        for ind in population:
            ind.dominated_count = 0
            ind.dominating_set = []
        
        for i, ind1 in enumerate(population):
            for j, ind2 in enumerate(population):
                if i != j:
                    if self._dominates(ind1.objectives, ind2.objectives):
                        ind1.dominating_set.append(ind2)
                    elif self._dominates(ind2.objectives, ind1.objectives):
                        ind1.dominated_count += 1
        
        fronts = []
        current_front = [ind for ind in population if ind.dominated_count == 0]
        
        for ind in current_front:
            ind.rank = 0
        
        front_index = 0
        while current_front:
            fronts.append(current_front)
            next_front = []
            
            for ind1 in current_front:
                for ind2 in ind1.dominating_set:
                    ind2.dominated_count -= 1
                    if ind2.dominated_count == 0:
                        ind2.rank = front_index + 1
                        next_front.append(ind2)
            
            current_front = next_front
            front_index += 1
        
        return fronts
    
    def _environmental_selection(self, population: List[Individual],
                                 target_size: int) -> List[Individual]:
        """环境选择（基于rank和crowding distance）"""
        # 按rank排序
        population.sort(key=lambda x: x.rank)
        
        selected = []
        current_rank = 0
        
        while len(selected) < target_size:
            # 获取当前rank的所有个体
            current_front = [ind for ind in population if ind.rank == current_rank]
            
            if not current_front:
                break
            
            if len(selected) + len(current_front) <= target_size:
                # 整个front都可以加入
                selected.extend(current_front)
            else:
                # 需要根据crowding distance选择
                self._calculate_crowding_distance(current_front)
                current_front.sort(key=lambda x: x.crowding_distance, reverse=True)
                
                remaining = target_size - len(selected)
                selected.extend(current_front[:remaining])
                break
            
            current_rank += 1
        
        return selected
    
    def _calculate_crowding_distance(self, front: List[Individual]):
        """计算拥挤距离"""
        n = len(front)
        if n == 0:
            return
        
        for ind in front:
            ind.crowding_distance = 0.0
        
        # 对每个目标计算crowding distance
        for obj_idx in range(2):
            front.sort(key=lambda x: x.objectives[obj_idx])
            
            # 边界个体设置为无穷大
            front[0].crowding_distance = float('inf')
            front[-1].crowding_distance = float('inf')
            
            obj_range = front[-1].objectives[obj_idx] - front[0].objectives[obj_idx]
            
            if obj_range == 0:
                continue
            
            for i in range(1, n - 1):
                distance = (front[i+1].objectives[obj_idx] -
                           front[i-1].objectives[obj_idx]) / obj_range
                front[i].crowding_distance += distance
    
    def _dominates(self, obj1: Tuple[float, float],
                   obj2: Tuple[float, float]) -> bool:
        """判断obj1是否支配obj2"""
        better_in_all = all(o1 <= o2 for o1, o2 in zip(obj1, obj2))
        better_in_one = any(o1 < o2 for o1, o2 in zip(obj1, obj2))
        return better_in_all and better_in_one
    
    def _update_archive(self):
        """更新外部存档（保留非支配解）"""
        # 提取所有非支配解
        self._non_dominated_sort(self.archive)
        non_dominated = [ind for ind in self.archive if ind.rank == 0]
        
        # 如果非支配解太多，用拥挤距离选择
        if len(non_dominated) > self.archive_size:
            self._calculate_crowding_distance(non_dominated)
            non_dominated.sort(key=lambda x: x.crowding_distance, reverse=True)
            self.archive = non_dominated[:self.archive_size]
        else:
            self.archive = non_dominated
    
    def _update_pareto_front(self):
        """更新全局Pareto前沿"""
        # 从存档中提取Pareto前沿
        self.pareto_front = copy.deepcopy(self.archive)


# ============================================================================
# QL-MOHPSO算法（Q-Learning驱动的多目标混合粒子群算法）
# ============================================================================

@dataclass
class Particle:
    """粒子类 - 用于PSO"""
    position: List[List]  # 位置（调度方案）
    velocity: List[float]  # 速度向量
    objectives: Tuple[float, float] = (float('inf'), float('inf'))
    pbest_position: List[List] = field(default_factory=list)  # 个体最优位置
    pbest_objectives: Tuple[float, float] = (float('inf'), float('inf'))
    rank: int = 0
    crowding_distance: float = 0.0
    dominated_count: int = 0
    dominating_set: List = field(default_factory=list)


class QLearningModule:
    """Q-Learning模块 - 用于自适应参数选择"""
    
    def __init__(self, n_states: int = 3, n_actions: int = 3, 
                 alpha: float = 0.1, gamma: float = 0.9, epsilon: float = 0.1):
        self.n_states = n_states  # 状态数：搜索阶段（早期/中期/后期）
        self.n_actions = n_actions  # 动作数：不同的参数组合
        self.alpha = alpha  # 学习率
        self.gamma = gamma  # 折扣因子
        self.epsilon = epsilon  # 探索率
        
        # Q表：状态 × 动作
        self.q_table = np.zeros((n_states, n_actions))
        
        # 动作对应的参数（惯性权重w, 学习因子c1, c2）
        self.action_params = [
            (0.9, 2.0, 2.0),  # 动作0：高惯性，标准学习因子
            (0.7, 1.5, 2.5),  # 动作1：中惯性，偏社会学习
            (0.5, 2.5, 1.5),  # 动作2：低惯性，偏个体学习
        ]
    
    def get_state(self, generation: int, max_gen: int) -> int:
        """根据当前代数确定搜索阶段（状态）"""
        progress = generation / max_gen
        if progress < 0.33:
            return 0  # 早期阶段
        elif progress < 0.67:
            return 1  # 中期阶段
        else:
            return 2  # 后期阶段
    
    def select_action(self, state: int) -> int:
        """基于ε-greedy策略选择动作"""
        if random.random() < self.epsilon:
            # 探索：随机选择
            return random.randint(0, self.n_actions - 1)
        else:
            # 利用：选择Q值最大的动作
            return np.argmax(self.q_table[state])
    
    def update_q_value(self, state: int, action: int, reward: float, next_state: int):
        """更新Q值"""
        best_next_q = np.max(self.q_table[next_state])
        current_q = self.q_table[state, action]
        
        # Q-Learning更新规则
        new_q = current_q + self.alpha * (reward + self.gamma * best_next_q - current_q)
        self.q_table[state, action] = new_q
    
    def get_params(self, action: int) -> Tuple[float, float, float]:
        """获取动作对应的PSO参数"""
        return self.action_params[action]


class QL_MOHPSO:
    """
    Q-Learning Driven Multi-Objective Hybrid PSO
    基于Q-Learning的多目标混合粒子群优化算法
    """
    
    def __init__(self, instance: Dict, pop_size: int, max_gen: int,
                 w: float = 0.7, c1: float = 2.0, c2: float = 2.0,
                 archive_size: int = 100, mutation_rate: float = 0.1,
                 peak_power_limit: float = None):
        self.instance = instance
        self.pop_size = pop_size
        self.max_gen = max_gen
        
        # PSO参数（初始值，将被Q-Learning调整）
        self.w = w  # 惯性权重
        self.c1 = c1  # 个体学习因子
        self.c2 = c2  # 社会学习因子
        
        self.archive_size = archive_size
        self.mutation_rate = mutation_rate
        
        # 初始化编码器和评估器
        self.encoder = ScheduleEncoder(
            instance['n'], instance['k'], instance['f'],
            instance['machines_per_stage']
        )
        self.evaluator = ScheduleEvaluator(instance, peak_power_limit)
        
        # 粒子群和外部存档
        self.swarm = []
        self.archive = []  # 外部存档（全局最优集合）
        self.pareto_front = []
        self.history = []
        
        # Q-Learning模块
        self.q_learning = QLearningModule()
        
        # 速度限制
        self.v_max = 0.5  # 速度最大值（相对于位置范围）
    
    def run(self, verbose: bool = True) -> List[Individual]:
        """运行QL-MOHPSO算法"""
        if verbose:
            print(f"\n开始运行 QL-MOHPSO...")
            print(f"  粒子数: {self.pop_size}, 最大代数: {self.max_gen}")
            print(f"  Q-Learning自适应参数调整")
        
        start_time = time.time()
        
        # 初始化粒子群
        self.swarm = self._initialize_swarm()
        self._evaluate_swarm(self.swarm)
        
        # 初始化个体最优
        for particle in self.swarm:
            particle.pbest_position = copy.deepcopy(particle.position)
            particle.pbest_objectives = particle.objectives
        
        # 初始化外部存档
        self._update_archive(self.swarm)
        
        # 主进化循环
        for gen in range(self.max_gen):
            # Q-Learning: 确定当前状态
            state = self.q_learning.get_state(gen, self.max_gen)
            
            # Q-Learning: 选择动作（参数组合）
            action = self.q_learning.select_action(state)
            self.w, self.c1, self.c2 = self.q_learning.get_params(action)
            
            # 记录本代开始时的存档质量（用于奖励计算）
            old_archive_quality = self._calculate_archive_quality()
            
            # 更新粒子速度和位置
            for particle in self.swarm:
                # 从存档中随机选择全局引导者
                if self.archive:
                    gbest = random.choice(self.archive)
                else:
                    gbest = particle
                
                # 更新速度和位置
                self._update_particle(particle, gbest)
            
            # 评估新位置
            self._evaluate_swarm(self.swarm)
            
            # 更新个体最优
            for particle in self.swarm:
                if self._dominates(particle.objectives, particle.pbest_objectives):
                    particle.pbest_position = copy.deepcopy(particle.position)
                    particle.pbest_objectives = particle.objectives
            
            # 变异（增加多样性）
            if random.random() < self.mutation_rate:
                self._mutate_swarm()
            
            # 更新外部存档
            self._update_archive(self.swarm)
            
            # Q-Learning: 计算奖励并更新Q值
            new_archive_quality = self._calculate_archive_quality()
            reward = new_archive_quality - old_archive_quality
            next_state = self.q_learning.get_state(gen + 1, self.max_gen)
            self.q_learning.update_q_value(state, action, reward, next_state)
            
            # 更新Pareto前沿
            self.pareto_front = copy.deepcopy(self.archive)
            
            # 记录历史
            if len(self.pareto_front) > 0:
                avg_makespan = np.mean([self._particle_to_individual(p).objectives[0] 
                                       for p in self.pareto_front])
                avg_energy = np.mean([self._particle_to_individual(p).objectives[1] 
                                     for p in self.pareto_front])
                self.history.append({
                    'generation': gen,
                    'pareto_size': len(self.pareto_front),
                    'avg_makespan': avg_makespan,
                    'avg_energy': avg_energy,
                    'w': self.w,
                    'c1': self.c1,
                    'c2': self.c2
                })
            
            if verbose and (gen + 1) % 20 == 0:
                print(f"  代数 {gen+1}/{self.max_gen}: Pareto前沿 {len(self.pareto_front)} 个解, "
                      f"w={self.w:.2f}, c1={self.c1:.2f}, c2={self.c2:.2f}")
        
        elapsed_time = time.time() - start_time
        
        if verbose:
            print(f"  完成! 用时: {elapsed_time:.2f}秒")
            print(f"  最终Pareto前沿: {len(self.pareto_front)} 个解")
        
        # 转换为标准Individual格式返回
        return [self._particle_to_individual(p) for p in self.pareto_front]
    
    def _initialize_swarm(self) -> List[Particle]:
        """初始化粒子群"""
        swarm = []
        for _ in range(self.pop_size):
            # 随机生成调度方案作为位置
            position = self.encoder.generate_random_schedule()
            
            # 初始化速度（随机小值）
            velocity = [random.uniform(-0.1, 0.1) for _ in range(self._get_dimension())]
            
            particle = Particle(
                position=position,
                velocity=velocity
            )
            swarm.append(particle)
        
        return swarm
    
    def _get_dimension(self) -> int:
        """获取问题维度（用于速度向量）"""
        # 简化：维度 = 作业数 * 阶段数 * 2（工厂和机器各一维）
        return self.instance['n'] * self.instance['k'] * 2
    
    def _evaluate_swarm(self, swarm: List[Particle]):
        """评估粒子群"""
        for particle in swarm:
            metrics = self.evaluator.evaluate(particle.position)
            if not metrics['feasible']:
                penalty = metrics['max_violation'] * 100
                particle.objectives = (
                    metrics['makespan'] + penalty,
                    metrics['total_energy'] + penalty
                )
            else:
                particle.objectives = (metrics['makespan'], metrics['total_energy'])
    
    def _update_particle(self, particle: Particle, gbest: Particle):
        """更新粒子的速度和位置（PSO核心）"""
        # PSO速度更新公式
        # v = w*v + c1*r1*(pbest - x) + c2*r2*(gbest - x)
        
        for i in range(len(particle.velocity)):
            r1 = random.random()
            r2 = random.random()
            
            # 计算pbest和gbest的"距离"（简化）
            pbest_diff = random.uniform(-1, 1)  # 简化的差异
            gbest_diff = random.uniform(-1, 1)
            
            # 速度更新
            particle.velocity[i] = (
                self.w * particle.velocity[i] +
                self.c1 * r1 * pbest_diff +
                self.c2 * r2 * gbest_diff
            )
            
            # 速度限制
            particle.velocity[i] = max(-self.v_max, min(self.v_max, particle.velocity[i]))
        
        # 位置更新（基于速度的概率性调整）
        self._update_position_based_on_velocity(particle)
    
    def _update_position_based_on_velocity(self, particle: Particle):
        """基于速度更新位置（离散问题的处理）"""
        # 对于离散调度问题，使用速度的概率解释
        # 速度越大，变化的概率越高
        
        new_position = copy.deepcopy(particle.position)
        
        # 根据速度随机调整一些操作
        for _ in range(int(abs(sum(particle.velocity)) * 10)):  # 速度越大，调整次数越多
            if random.random() < 0.5:
                # 交换两个作业的某个阶段的分配
                if len(new_position) >= 2:
                    j1, j2 = random.sample(range(len(new_position)), 2)
                    stage = random.randint(0, len(new_position[0]) - 1)
                    if len(new_position[j1][stage]) > 0 and len(new_position[j2][stage]) > 0:
                        new_position[j1][stage], new_position[j2][stage] = \
                            new_position[j2][stage], new_position[j1][stage]
            else:
                # 改变某个作业某个阶段的工厂/机器分配
                job = random.randint(0, len(new_position) - 1)
                stage = random.randint(0, len(new_position[0]) - 1)
                if len(new_position[job][stage]) > 0:
                    factory = random.randint(0, self.instance['f'] - 1)
                    n_machines = self.instance['machines_per_stage'][factory][stage]
                    machine = random.randint(0, n_machines - 1)
                    new_position[job][stage] = [(factory, machine)]
        
        particle.position = new_position
    
    def _mutate_swarm(self):
        """对部分粒子进行变异"""
        n_mutate = max(1, int(self.pop_size * 0.1))  # 变异10%的粒子
        particles_to_mutate = random.sample(self.swarm, n_mutate)
        
        for particle in particles_to_mutate:
            particle.position = self.encoder.mutate(schedule=particle.position, mutation_rate=0.2)
    
    def _update_archive(self, swarm: List[Particle]):
        """更新外部存档"""
        # 合并当前粒子群和存档
        combined = self.archive + swarm
        
        # 提取非支配解
        self._non_dominated_sort_particles(combined)
        non_dominated = [p for p in combined if p.rank == 0]
        
        # 如果非支配解太多，用拥挤距离裁剪
        if len(non_dominated) > self.archive_size:
            self._calculate_crowding_distance_particles(non_dominated)
            non_dominated.sort(key=lambda x: x.crowding_distance, reverse=True)
            self.archive = non_dominated[:self.archive_size]
        else:
            self.archive = non_dominated
    
    def _non_dominated_sort_particles(self, particles: List[Particle]):
        """对粒子进行非支配排序"""
        for p in particles:
            p.dominated_count = 0
            p.dominating_set = []
        
        for i, p1 in enumerate(particles):
            for j, p2 in enumerate(particles):
                if i != j:
                    if self._dominates(p1.objectives, p2.objectives):
                        p1.dominating_set.append(p2)
                    elif self._dominates(p2.objectives, p1.objectives):
                        p1.dominated_count += 1
        
        fronts = []
        current_front = [p for p in particles if p.dominated_count == 0]
        
        for p in current_front:
            p.rank = 0
        
        front_index = 0
        while current_front:
            fronts.append(current_front)
            next_front = []
            
            for p1 in current_front:
                for p2 in p1.dominating_set:
                    p2.dominated_count -= 1
                    if p2.dominated_count == 0:
                        p2.rank = front_index + 1
                        next_front.append(p2)
            
            current_front = next_front
            front_index += 1
        
        return fronts
    
    def _calculate_crowding_distance_particles(self, particles: List[Particle]):
        """计算粒子的拥挤距离"""
        n = len(particles)
        if n == 0:
            return
        
        for p in particles:
            p.crowding_distance = 0.0
        
        for obj_idx in range(2):
            particles.sort(key=lambda x: x.objectives[obj_idx])
            
            particles[0].crowding_distance = float('inf')
            particles[-1].crowding_distance = float('inf')
            
            obj_range = particles[-1].objectives[obj_idx] - particles[0].objectives[obj_idx]
            
            if obj_range == 0:
                continue
            
            for i in range(1, n - 1):
                distance = (particles[i+1].objectives[obj_idx] -
                           particles[i-1].objectives[obj_idx]) / obj_range
                particles[i].crowding_distance += distance
    
    def _dominates(self, obj1: Tuple[float, float], obj2: Tuple[float, float]) -> bool:
        """判断obj1是否支配obj2"""
        better_in_all = all(o1 <= o2 for o1, o2 in zip(obj1, obj2))
        better_in_one = any(o1 < o2 for o1, o2 in zip(obj1, obj2))
        return better_in_all and better_in_one
    
    def _calculate_archive_quality(self) -> float:
        """计算存档质量（用于Q-Learning奖励）"""
        if not self.archive:
            return 0.0
        
        # 简化：使用存档中解的平均目标值（归一化后）
        makespans = [p.objectives[0] for p in self.archive]
        energies = [p.objectives[1] for p in self.archive]
        
        if len(makespans) == 0:
            return 0.0
        
        # 归一化并计算综合质量（越小越好，所以取负值作为奖励）
        avg_makespan = np.mean(makespans)
        avg_energy = np.mean(energies)
        
        # 奖励 = -归一化的平均目标值
        quality = -(avg_makespan / 10000.0 + avg_energy / 100000.0)
        
        return quality
    
    def _particle_to_individual(self, particle: Particle) -> Individual:
        """将粒子转换为标准Individual格式"""
        return Individual(
            schedule=particle.position,
            objectives=particle.objectives,
            rank=particle.rank,
            crowding_distance=particle.crowding_distance
        )


# ============================================================================
# EMTMA算法实现 (新增)
# ============================================================================

class EMTMA:
    """
    Evolutionary Multitasking Memetic Algorithm (EMTMA)
    基于论文: Li et al. (2024) IEEE TEVC
    双任务进化框架 + 知识转移 + Memetic局部搜索
    """

    def __init__(self, instance: Dict, pop_size: int, max_gen: int,
                 ps1: int = 100, ps2: int = 20, Pm: float = 0.3,
                 epsilon: float = 0.85, alpha: float = 0.1, gamma: float = 0.95,
                 peak_power_limit: float = None):
        """
        初始化EMTMA

        Args:
            instance: 问题实例
            pop_size: 总种群大小（为了兼容接口，实际使用ps1+ps2）
            max_gen: 最大代数
            ps1: Task 1种群大小
            ps2: Task 2种群大小
            Pm: 变异率
            epsilon: ε-greedy参数
            alpha: Q-learning学习率
            gamma: Q-learning折扣因子
            peak_power_limit: 峰值功耗限制
        """
        self.instance = instance
        self.max_gen = max_gen
        self.ps1 = ps1
        self.ps2 = ps2
        self.Pm = Pm
        self.epsilon = epsilon
        self.alpha = alpha
        self.gamma = gamma

        # 初始化组件
        self.encoder = ScheduleEncoder(
            instance['n'], instance['k'], instance['f'],
            instance['machines_per_stage']
        )
        self.evaluator = ScheduleEvaluator(instance, peak_power_limit)

        # 任务种群
        self.P1 = []  # Task 1 population
        self.P2 = []  # Task 2 population
        self.archive = []  # Elite archive Ω
        self.pareto_front = []
        self.history = []

        # Q-learning table for Task 2 (5 actions, 10 states)
        self.Q_table = np.zeros((10, 5))
        self.current_state = 0

    def run(self, verbose: bool = True) -> List[Individual]:
        """运行EMTMA算法"""
        if verbose:
            print(f"\n开始运行 EMTMA...")
            print(f"  Task1种群: {self.ps1}, Task2种群: {self.ps2}, 最大代数: {self.max_gen}")

        start_time = time.time()

        # 初始化两个任务的种群
        self.P1 = self._initialize_population(self.ps1)
        self.P2 = self._initialize_population(self.ps2)

        # 评估
        self._evaluate_population(self.P1)
        self._evaluate_population(self.P2)

        # 初始化存档
        self.archive = copy.deepcopy(self.P1[:5])  # 初始精英解

        # 主进化循环
        for gen in range(self.max_gen):
            # Task 1: 竞争群优化器进化
            self.P1 = self._evolve_task1(self.P1)

            # Task 2: RL引导的协作搜索
            self.P2 = self._evolve_task2(self.P2)

            # 知识转移: T1 → T2
            K1 = self._knowledge_transfer(self.P1, task_id=1)
            if K1:
                self.P2 = self._merge_and_select(self.P2, K1, self.ps2)

            # 知识转移: T2 → T1
            K2 = self._knowledge_transfer(self.P2, task_id=2)
            if K2:
                self.P1 = self._merge_and_select(self.P1, K2, self.ps1)

            # 更新精英存档
            self._update_archive()

            # 精英局部搜索 (每10代一次)
            if (gen + 1) % 10 == 0:
                self._elite_local_search()

            # 更新Pareto前沿
            self._update_pareto_front()

            # 记录历史
            if len(self.pareto_front) > 0:
                avg_makespan = np.mean([ind.objectives[0] for ind in self.pareto_front])
                avg_energy = np.mean([ind.objectives[1] for ind in self.pareto_front])
                self.history.append({
                    'generation': gen,
                    'pareto_size': len(self.pareto_front),
                    'avg_makespan': avg_makespan,
                    'avg_energy': avg_energy
                })

            if verbose and (gen + 1) % 20 == 0:
                print(f"  代数 {gen + 1}/{self.max_gen}: Pareto前沿 {len(self.pareto_front)} 个解")

        elapsed_time = time.time() - start_time

        if verbose:
            print(f"  完成! 用时: {elapsed_time:.2f}秒")
            print(f"  最终Pareto前沿: {len(self.pareto_front)} 个解")

        return self.pareto_front

    def _initialize_population(self, size: int) -> List[Individual]:
        """初始化种群"""
        population = []
        for _ in range(size):
            schedule = self.encoder.generate_random_schedule()
            ind = Individual(schedule=schedule, objectives=(0, 0))
            population.append(ind)
        return population

    def _evaluate_population(self, population: List[Individual]):
        """评估种群"""
        for ind in population:
            metrics = self.evaluator.evaluate(ind.schedule)
            if not metrics['feasible']:
                penalty = metrics['max_violation'] * 100
                ind.objectives = (
                    metrics['makespan'] + penalty,
                    metrics['total_energy'] + penalty
                )
            else:
                ind.objectives = (metrics['makespan'], metrics['total_energy'])

    def _evolve_task1(self, P1: List[Individual]) -> List[Individual]:
        """Task 1: 竞争群优化器 (Algorithm 1)"""
        # 计算综合性能指标 H
        H = self._calculate_H_metric(P1)

        # 排序
        sorted_indices = np.argsort(H)
        W = [P1[i] for i in sorted_indices[:len(P1) // 2]]  # Winner
        L = [P1[i] for i in sorted_indices[len(P1) // 2:]]  # Loser

        C1 = []  # Offspring from loser learning winner
        C2 = []  # Offspring from winner self-evolution

        # Loser学习Winner
        for i in range(len(W)):
            parent1 = random.choice(W)
            parent2 = L[i]

            child1_schedule = self.encoder.crossover(parent1.schedule, parent2.schedule)
            child2_schedule = self.encoder.crossover(parent2.schedule, parent1.schedule)

            child1 = Individual(schedule=child1_schedule, objectives=(0, 0))
            child2 = Individual(schedule=child2_schedule, objectives=(0, 0))

            C1.extend([child1, child2])

        # Winner自我进化
        for i in range(len(W)):
            parent1 = random.choice(W)
            parent2 = W[i]

            child1_schedule = self.encoder.crossover(parent1.schedule, parent2.schedule)
            child2_schedule = self.encoder.crossover(parent2.schedule, parent1.schedule)

            # 变异
            if random.random() < self.Pm:
                child1_schedule = self.encoder.mutate(child1_schedule, self.Pm)
                child2_schedule = self.encoder.mutate(child2_schedule, self.Pm)

            child1 = Individual(schedule=child1_schedule, objectives=(0, 0))
            child2 = Individual(schedule=child2_schedule, objectives=(0, 0))

            C2.extend([child1, child2])

        # 评估后代
        self._evaluate_population(C1)
        self._evaluate_population(C2)

        # 环境选择
        Qt = P1 + C1 + C2
        return self._environmental_selection(Qt, self.ps1)

    def _evolve_task2(self, P2: List[Individual]) -> List[Individual]:
        """Task 2: RL引导的协作搜索 (Algorithm 2)"""
        offspring = []

        for i in range(len(P2)):
            parent = P2[i]

            # ε-greedy 选择动作
            if random.random() > self.epsilon:
                action = np.argmax(self.Q_table[self.current_state, :])
            else:
                action = random.randint(0, 4)

            # 执行局部搜索
            child = self._local_search(parent, action)
            self._evaluate_population([child])

            # 计算奖励
            if self._dominates(child.objectives, parent.objectives):
                reward = 10.0
                success = 1
            else:
                reward = 0.0
                success = 0

            # 更新Q表
            next_state = 2 * action + success
            best_next_q = np.max(self.Q_table[next_state, :])
            current_q = self.Q_table[self.current_state, action]
            self.Q_table[self.current_state, action] = current_q + self.alpha * (
                    reward + self.gamma * best_next_q - current_q
            )

            self.current_state = next_state
            offspring.append(child)

        # 合并父代和子代
        Qt = P2 + offspring
        return self._environmental_selection(Qt, self.ps2)

    def _local_search(self, individual: Individual, action: int) -> Individual:
        """局部搜索操作（5种动作）"""
        neighbor = copy.deepcopy(individual)
        schedule = neighbor.schedule

        if action == 0:  # Swap jobs
            if len(schedule) >= 2:
                j1, j2 = random.sample(range(len(schedule)), 2)
                stage = random.randint(0, len(schedule[0]) - 1)
                if len(schedule[j1][stage]) > 0 and len(schedule[j2][stage]) > 0:
                    schedule[j1][stage], schedule[j2][stage] = \
                        schedule[j2][stage], schedule[j1][stage]

        elif action == 1:  # Change factory
            job = random.randint(0, len(schedule) - 1)
            stage = random.randint(0, len(schedule[0]) - 1)
            if len(schedule[job][stage]) > 0:
                factory = random.randint(0, self.encoder.n_factories - 1)
                n_machines = self.encoder.machines_per_stage[factory][stage]
                machine = random.randint(0, n_machines - 1)
                schedule[job][stage] = [(factory, machine)]

        elif action == 2:  # Change machine
            job = random.randint(0, len(schedule) - 1)
            stage = random.randint(0, len(schedule[0]) - 1)
            if len(schedule[job][stage]) > 0:
                factory, _ = schedule[job][stage][0]
                n_machines = self.encoder.machines_per_stage[factory][stage]
                machine = random.randint(0, n_machines - 1)
                schedule[job][stage] = [(factory, machine)]

        elif action == 3:  # Insert
            if len(schedule) >= 3:
                start = random.randint(0, len(schedule) - 2)
                end = random.randint(start + 1, len(schedule) - 1)
                schedule[start:end + 1] = schedule[start:end + 1][::-1]

        else:  # action == 4: Random mutation
            schedule = self.encoder.mutate(schedule, 0.1)

        neighbor.schedule = schedule
        return neighbor

    def _calculate_H_metric(self, population: List[Individual]) -> np.ndarray:
        """计算综合性能指标 H (Equation 17)"""
        N = len(population)
        H = np.zeros(N)

        for i in range(N):
            # 计算被支配次数
            dom_count = sum(1 for j in range(N) if i != j and
                            self._dominates(population[j].objectives, population[i].objectives))

            # 计算到最近邻的距离
            distances = []
            for j in range(N):
                if i != j:
                    dist = np.sqrt(
                        (population[i].objectives[0] - population[j].objectives[0]) ** 2 +
                        (population[i].objectives[1] - population[j].objectives[1]) ** 2
                    )
                    distances.append(dist)

            min_dist = min(distances) if distances else 1.0

            H[i] = (dom_count + 1) / (min_dist + 2)

        return H

    def _knowledge_transfer(self, population: List[Individual],
                            task_id: int) -> List[Individual]:
        """知识转移策略 (Section IV-B)"""
        # 计算skill factor τ
        transferred = []

        for ind in population:
            # 简化版skill factor: 只转移非支配解
            is_dominated = False
            for other in population:
                if self._dominates(other.objectives, ind.objectives):
                    is_dominated = True
                    break

            if not is_dominated and ind.rank == 0:
                transferred.append(copy.deepcopy(ind))

        return transferred[:max(1, len(transferred) // 2)]  # 转移一半的精英解

    def _merge_and_select(self, population: List[Individual],
                          knowledge: List[Individual],
                          size: int) -> List[Individual]:
        """合并知识并选择"""
        combined = population + knowledge
        return self._environmental_selection(combined, size)

    def _update_archive(self):
        """更新精英存档"""
        # 合并所有种群到存档
        all_pop = self.P1 + self.P2 + self.archive

        # 提取非支配解
        self._non_dominated_sort(all_pop)
        self.archive = [ind for ind in all_pop if ind.rank == 0]

        # 限制存档大小
        if len(self.archive) > 100:
            self._calculate_crowding_distance(self.archive)
            self.archive.sort(key=lambda x: x.crowding_distance, reverse=True)
            self.archive = self.archive[:100]

    def _elite_local_search(self):
        """精英局部搜索"""
        improved_archive = []

        for ind in self.archive:
            # 随机选择一个局部搜索动作
            action = random.randint(0, 4)
            neighbor = self._local_search(ind, action)
            self._evaluate_population([neighbor])

            # 保留更好的解
            if self._dominates(neighbor.objectives, ind.objectives):
                improved_archive.append(neighbor)
            else:
                improved_archive.append(ind)

        self.archive = improved_archive

    def _update_pareto_front(self):
        """更新全局Pareto前沿"""
        self.pareto_front = copy.deepcopy(self.archive)

    def _environmental_selection(self, population: List[Individual],
                                 size: int) -> List[Individual]:
        """环境选择 (NSGA-II策略)"""
        self._non_dominated_sort(population)

        selected = []
        current_rank = 0

        while len(selected) < size:
            current_front = [ind for ind in population if ind.rank == current_rank]

            if not current_front:
                break

            if len(selected) + len(current_front) <= size:
                selected.extend(current_front)
            else:
                self._calculate_crowding_distance(current_front)
                current_front.sort(key=lambda x: x.crowding_distance, reverse=True)
                remaining = size - len(selected)
                selected.extend(current_front[:remaining])
                break

            current_rank += 1

        return selected

    def _non_dominated_sort(self, population: List[Individual]):
        """快速非支配排序"""
        for ind in population:
            ind.dominated_count = 0
            ind.dominating_set = []

        for i, ind1 in enumerate(population):
            for j, ind2 in enumerate(population):
                if i != j:
                    if self._dominates(ind1.objectives, ind2.objectives):
                        ind1.dominating_set.append(ind2)
                    elif self._dominates(ind2.objectives, ind1.objectives):
                        ind1.dominated_count += 1

        fronts = []
        current_front = [ind for ind in population if ind.dominated_count == 0]

        for ind in current_front:
            ind.rank = 0

        front_index = 0
        while current_front:
            fronts.append(current_front)
            next_front = []

            for ind1 in current_front:
                for ind2 in ind1.dominating_set:
                    ind2.dominated_count -= 1
                    if ind2.dominated_count == 0:
                        ind2.rank = front_index + 1
                        next_front.append(ind2)

            current_front = next_front
            front_index += 1

    def _dominates(self, obj1: Tuple[float, float],
                   obj2: Tuple[float, float]) -> bool:
        """判断obj1是否支配obj2"""
        better_in_all = all(o1 <= o2 for o1, o2 in zip(obj1, obj2))
        better_in_one = any(o1 < o2 for o1, o2 in zip(obj1, obj2))
        return better_in_all and better_in_one

    def _calculate_crowding_distance(self, front: List[Individual]):
        """计算拥挤距离"""
        n = len(front)
        if n == 0:
            return

        for ind in front:
            ind.crowding_distance = 0.0

        for obj_idx in range(2):
            front.sort(key=lambda x: x.objectives[obj_idx])
            front[0].crowding_distance = float('inf')
            front[-1].crowding_distance = float('inf')

            obj_range = front[-1].objectives[obj_idx] - front[0].objectives[obj_idx]
            if obj_range == 0:
                continue

            for i in range(1, n - 1):
                distance = (front[i + 1].objectives[obj_idx] -
                            front[i - 1].objectives[obj_idx]) / obj_range
                front[i].crowding_distance += distance


# ============================================================================
# 性能指标
# ============================================================================

class PerformanceMetrics:
    """性能指标计算"""
    
    @staticmethod
    def hypervolume(pareto_front: List[Individual], ref_point: Tuple[float, float] = None) -> float:
        """
        计算超体积(HV)指标 - 不归一化
        与mo_metrics.py的实现保持一致
        """
        if not pareto_front or len(pareto_front) == 0:
            return 0.0

        # 提取目标值
        objectives = np.array([ind.objectives for ind in pareto_front])

        # 自动设置参考点为最大值的1.1倍
        if ref_point is None:
            max_vals = np.max(objectives, axis=0)
            ref_point = tuple(max_vals * 1.1)

        ref = np.array(ref_point)

        # 检查所有点都在参考点之前
        if np.any(objectives >= ref):
            # 有点超出参考点，调整参考点
            max_vals = np.max(objectives, axis=0)
            ref = max_vals * 1.1

        # 使用2D HV精确算法（不归一化）
        hv = PerformanceMetrics._compute_2d_hv(objectives, ref)

        return hv

    def _compute_2d_hv(front: np.ndarray, ref: np.ndarray) -> float:
        """
        计算2D Hypervolume（精确算法）
        按第一个目标排序，从参考点的y坐标开始计算矩形面积
        """
        # 按第一个目标排序
        sorted_front = front[np.argsort(front[:, 0])]

        hv = 0.0
        prev_y = ref[1]  # 从参考点的y坐标开始

        for point in sorted_front:
            x, y = point

            # 检查支配关系
            if y < prev_y:
                # 计算矩形面积
                width = ref[0] - x
                height = prev_y - y
                hv += width * height
                prev_y = y

        return hv
    
    @staticmethod
    def igd(pareto_front: List[Individual],
            true_pareto_front: List[Tuple[float, float]]) -> float:
        """
        计算反转世代距离(IGD)指标 - 需要归一化
        与mo_metrics.py的实现保持一致
        """
        if not pareto_front or not true_pareto_front:
            return float('inf')

        if len(pareto_front) == 0 or len(true_pareto_front) == 0:
            return float('inf')

        # 转换为numpy数组
        pf = np.array([ind.objectives for ind in pareto_front])
        tpf = np.array(true_pareto_front)

        # 归一化（使用真实前沿的范围）
        min_vals = np.min(tpf, axis=0)
        max_vals = np.max(tpf, axis=0)
        range_vals = max_vals - min_vals

        # 避免除以0
        range_vals[range_vals == 0] = 1.0

        pf_norm = (pf - min_vals) / range_vals
        tpf_norm = (tpf - min_vals) / range_vals

        # 计算每个真实前沿点到获得前沿的最小距离
        distances = []
        for true_point in tpf_norm:
            # 计算到所有获得点的距离
            dists = np.sqrt(np.sum((pf_norm - true_point) ** 2, axis=1))
            min_dist = np.min(dists)
            distances.append(min_dist)

        # IGD = 平均距离
        igd_value = np.mean(distances)

        return igd_value
    
    @staticmethod
    def spacing(pareto_front: List[Individual]) -> float:
        """
        计算分布性(SP)指标 - 需要归一化
        与mo_metrics.py的实现保持一致
        """
        if len(pareto_front) < 2:
            return 0.0

        # 转换为numpy数组
        pf = np.array([ind.objectives for ind in pareto_front])

        # 归一化
        min_vals = np.min(pf, axis=0)
        max_vals = np.max(pf, axis=0)
        range_vals = max_vals - min_vals

        # 避免除以0
        range_vals[range_vals == 0] = 1.0

        pf_norm = (pf - min_vals) / range_vals

        # 计算每个点到最近邻的距离
        distances = []
        for i, point in enumerate(pf_norm):
            # 计算到其他所有点的距离
            other_points = np.delete(pf_norm, i, axis=0)
            dists = np.sqrt(np.sum((other_points - point) ** 2, axis=1))
            min_dist = np.min(dists)
            distances.append(min_dist)

        distances = np.array(distances)

        # Spacing = 标准差
        mean_dist = np.mean(distances)
        sp = np.sqrt(np.mean((distances - mean_dist) ** 2))

        return sp

def _safe_json_dump(obj: Any, path: str):
    """尽量保证写文件原子性：先写 tmp，再替换。"""
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)

# ============================================================================
# 实验运行函数
# ============================================================================

def run_comparison_experiment(pop_size: int, max_gen: int,
                              n_runs: int, instance_path: str, output_dir: str = "results",
                              algorithms: List[str] = None,
                              ):
    """
    运行对比实验
    
    Args:
        instance_path: 实例文件路径
        output_dir: 输出目录
        algorithms: 要运行的算法列表
        pop_size: 种群大小
        max_gen: 最大代数
        n_runs: 独立运行次数
    """
    print("="*80)
    print("多目标DHFSP对比实验")
    print("="*80)
    
    # 加载实例
    print(f"\n加载测试实例: {instance_path}")
    with open(instance_path, 'r') as f:
        instance = json.load(f)
    
    instance_name = instance.get('name', 'unknown')
    print(f"  实例: {instance_name}")
    print(f"  作业数: {instance['n']}, 阶段数: {instance['k']}, 工厂数: {instance['f']}")
    
    # 创建输出目录
    # os.makedirs(output_dir, exist_ok=True)

    # 创建输出目录（每个数据集一个时间戳子目录，checkpoint持续更新）
    now = datetime.datetime.now()
    run_tag = now.strftime('%Y-%m-%d_%H-%M-%S')
    exp_dir = os.path.join(output_dir, f"{run_tag}_{instance_name}")
    os.makedirs(exp_dir, exist_ok=True)

    checkpoint_file = os.path.join(exp_dir, "checkpoint.json")
    final_file = os.path.join(exp_dir, "final_results.json")
    
    # 默认运行所有算法
    if algorithms is None:
        algorithms = ['DCMA', 'NSGA-II', 'MOEA/D', 'SPEA2', 'KMOEA', 'HMOMA', 'QL-MOHPSO', 'EMTMA']
    
    # 估算峰值功耗限制（交给 ScheduleEvaluator 内部自动计算，兼容任意数据嵌套结构）
    peak_power_limit = None
    # print(f"  峰值功耗限制: {peak_power_limit:.2f}")
    
    # all_results = {}
    #
    # # 对每个算法运行实验
    # for alg_name in algorithms:
    #     print(f"\n{'='*80}")
    #     print(f"算法: {alg_name}")
    #     print(f"{'='*80}")
    #
    #     alg_results = {
    #         'pareto_fronts': [],
    #         'hv_scores': [],
    #         'igd_scores': [],
    #         'sp_scores': [],
    #         'runtimes': []
    #     }
    #
    #     # 独立运行多次
    #     for run in range(n_runs):
    #         print(f"\n运行 {run+1}/{n_runs}...")
    #
    #         start_time = time.time()
    #
    #         # 创建算法实例
    #         if alg_name == 'DCMA':
    #             alg = DCMA(instance, pop_size, max_gen,
    #                       peak_power_limit=peak_power_limit)
    #         elif alg_name == 'NSGA-II':
    #             alg = NSGAII(instance, pop_size, max_gen,
    #                         peak_power_limit=peak_power_limit)
    #         elif alg_name == 'MOEA/D':
    #             alg = MOEAD(instance, pop_size, max_gen,
    #                        peak_power_limit=peak_power_limit)
    #         elif alg_name == 'SPEA2':
    #             alg = SPEA2(instance, pop_size, pop_size, max_gen,
    #                        peak_power_limit=peak_power_limit)
    #         elif alg_name == 'KMOEA':
    #             alg = KMOEA(instance, pop_size, max_gen,
    #                        peak_power_limit=peak_power_limit)
    #         elif alg_name == 'HMOMA':
    #             alg = HMOMA(instance, pop_size, max_gen,
    #                        peak_power_limit=peak_power_limit)
    #         elif alg_name == 'QL-MOHPSO':
    #             alg = QL_MOHPSO(instance, pop_size, max_gen,
    #                        peak_power_limit=peak_power_limit)
    #         elif alg_name == 'EMTMA':
    #             alg = EMTMA(instance, pop_size, max_gen,
    #                        peak_power_limit=peak_power_limit)
    #         else:
    #             print(f"  未知算法: {alg_name}")
    #             continue
    #
    #         # 运行算法
    #         pareto_front = alg.run(verbose=False)
    #         runtime = time.time() - start_time
    #
    #         # 提取Pareto前沿目标值
    #         pareto_objs = [(ind.objectives[0], ind.objectives[1])
    #                       for ind in pareto_front]
    #
    #         alg_results['pareto_fronts'].append(pareto_objs)
    #         alg_results['runtimes'].append(runtime)
    #
    #         print(f"  完成! Pareto前沿: {len(pareto_front)} 个解, 用时: {runtime:.2f}秒")
    #
    #     # 计算合并的Pareto前沿（作为参考前沿）
    #     all_objs = []
    #     for pf in alg_results['pareto_fronts']:
    #         all_objs.extend(pf)
    #
    #     # 提取非支配解
    #     reference_front = []
    #     for obj in all_objs:
    #         is_dominated = False
    #         for other_obj in all_objs:
    #             if (other_obj[0] < obj[0] and other_obj[1] <= obj[1]) or \
    #                (other_obj[0] <= obj[0] and other_obj[1] < obj[1]):
    #                 is_dominated = True
    #                 break
    #         if not is_dominated:
    #             reference_front.append(obj)
    #
    #     print(f"\n参考前沿: {len(reference_front)} 个解")
    #
    #     # 计算指标
    #     print(f"\n计算性能指标...")
    #
    #     for run, pf_objs in enumerate(alg_results['pareto_fronts']):
    #         pf_inds = [Individual(schedule=[], objectives=obj) for obj in pf_objs]
    #
    #         # 计算HV
    #         hv = PerformanceMetrics.hypervolume(pf_inds)
    #         alg_results['hv_scores'].append(hv)
    #
    #         # 计算IGD
    #         igd = PerformanceMetrics.igd(pf_inds, reference_front)
    #         alg_results['igd_scores'].append(igd)
    #
    #         # 计算SP
    #         sp = PerformanceMetrics.spacing(pf_inds)
    #         alg_results['sp_scores'].append(sp)
    #
    #     # 计算统计量
    #     stats = {
    #         'hv': {
    #             'mean': np.mean(alg_results['hv_scores']),
    #             'std': np.std(alg_results['hv_scores']),
    #             'min': np.min(alg_results['hv_scores']),
    #             'max': np.max(alg_results['hv_scores'])
    #         },
    #         'igd': {
    #             'mean': np.mean(alg_results['igd_scores']),
    #             'std': np.std(alg_results['igd_scores']),
    #             'min': np.min(alg_results['igd_scores']),
    #             'max': np.max(alg_results['igd_scores'])
    #         },
    #         'sp': {
    #             'mean': np.mean(alg_results['sp_scores']),
    #             'std': np.std(alg_results['sp_scores']),
    #             'min': np.min(alg_results['sp_scores']),
    #             'max': np.max(alg_results['sp_scores'])
    #         },
    #         'runtime': {
    #             'mean': np.mean(alg_results['runtimes']),
    #             'std': np.std(alg_results['runtimes'])
    #         }
    #     }
    #
    #     alg_results['statistics'] = stats
    #
    #     # 打印统计结果
    #     print(f"\n{alg_name} 统计结果 ({n_runs}次运行):")
    #     print(f"  HV:  均值={stats['hv']['mean']:.4f}, 标准差={stats['hv']['std']:.4f}")
    #     print(f"  IGD: 均值={stats['igd']['mean']:.4f}, 标准差={stats['igd']['std']:.4f}")
    #     print(f"  SP:  均值={stats['sp']['mean']:.4f}, 标准差={stats['sp']['std']:.4f}")
    #     print(f"  时间: 均值={stats['runtime']['mean']:.2f}秒, 标准差={stats['runtime']['std']:.2f}秒")
    #
    #     all_results[alg_name] = alg_results
    #
    # now = datetime.datetime.now()
    # # 保存结果
    # result_file = os.path.join(output_dir, f"{now.strftime('%Y-%m-%d_%H-%M-%S')}_{instance_name}_results.json")
    #
    # serializable_results = {}
    # for alg_name, alg_res in all_results.items():
    #     serializable_results[alg_name] = {
    #         'statistics': alg_res['statistics'],
    #         'hv_scores': alg_res['hv_scores'],
    #         'igd_scores': alg_res['igd_scores'],
    #         'sp_scores': alg_res['sp_scores'],
    #         'runtimes': alg_res['runtimes'],
    #         'pareto_fronts': alg_res['pareto_fronts']
    #     }
    #
    # with open(result_file, 'w') as f:
    #     json.dump(serializable_results, f, indent=2)
    #
    # print(f"\n结果已保存到: {result_file}")
    #
    # # 打印对比表格
    # print(f"\n{'='*80}")
    # print("最终对比结果")
    # print(f"{'='*80}")
    # print(f"{'算法':<15} {'HV (↑)':<20} {'IGD (↓)':<20} {'SP (↓)':<20} {'时间(秒)':<15}")
    # print("-"*95)
    #
    # for alg_name in algorithms:
    #     if alg_name in all_results:
    #         stats = all_results[alg_name]['statistics']
    #         print(f"{alg_name:<15} "
    #               f"{stats['hv']['mean']:.4f}±{stats['hv']['std']:.4f}    "
    #               f"{stats['igd']['mean']:.4f}±{stats['igd']['std']:.4f}    "
    #               f"{stats['sp']['mean']:.4f}±{stats['sp']['std']:.4f}    "
    #               f"{stats['runtime']['mean']:.2f}±{stats['runtime']['std']:.2f}")
    #
    # print(f"{'='*80}\n")
    #
    # return all_results

    all_results = {
        "meta": {
            "instance_path": instance_path,
            "instance_name": instance_name,
            "n_jobs": instance['n'],
            "n_stages": instance['k'],
            "n_factories": instance['f'],
            "pop_size": pop_size,
            "max_gen": max_gen,
            "n_runs": n_runs,
            "algorithms": algorithms,
            "created_at": now.isoformat()
        },
        "algorithms": {}
    }

    def _save_checkpoint():
        _safe_json_dump(all_results, checkpoint_file)
        print(f"  [checkpoint saved] {checkpoint_file}")

    _save_checkpoint()

    for alg_name in algorithms:
        print(f"\n{'=' * 80}")
        print(f"算法: {alg_name}")
        print(f"{'=' * 80}")

        alg_results = {
            "runs": [],  # 每次run的详细信息（成功/失败、耗时、traceback等）
            "pareto_fronts": [],
            "hv_scores": [],
            "igd_scores": [],
            "sp_scores": [],
            "runtimes": [],
            "statistics": None
        }

        for run_idx in range(n_runs):
            print(f"\n运行 {run_idx + 1}/{n_runs}...")

            run_record = {
                "run_index": run_idx,
                "status": "unknown",
                "runtime": None,
                "pareto_size": None,
                "error": None,
                "traceback": None,
                "pareto_front": None
            }

            start_time = time.time()

            try:
                # 创建算法实例
                if alg_name == 'DCMA':
                    alg = DCMA(instance, pop_size, max_gen, peak_power_limit=peak_power_limit)
                elif alg_name == 'NSGA-II':
                    alg = NSGAII(instance, pop_size, max_gen, peak_power_limit=peak_power_limit)
                elif alg_name == 'MOEA/D':
                    alg = MOEAD(instance, pop_size, max_gen, peak_power_limit=peak_power_limit)
                elif alg_name == 'SPEA2':
                    alg = SPEA2(instance, pop_size, pop_size, max_gen, peak_power_limit=peak_power_limit)
                elif alg_name == 'KMOEA':
                    alg = KMOEA(instance, pop_size, max_gen, peak_power_limit=peak_power_limit)
                elif alg_name == 'HMOMA':
                    alg = HMOMA(instance, pop_size, max_gen, peak_power_limit=peak_power_limit)
                elif alg_name == 'QL-MOHPSO':
                    alg = QL_MOHPSO(instance, pop_size, max_gen, peak_power_limit=peak_power_limit)
                elif alg_name == 'EMTMA':
                    alg = EMTMA(instance, pop_size, max_gen, peak_power_limit=peak_power_limit)
                else:
                    raise ValueError(f"未知算法: {alg_name}")

                pareto_front = alg.run(verbose=False)
                runtime = time.time() - start_time

                pareto_objs = [(float(ind.objectives[0]), float(ind.objectives[1])) for ind in pareto_front]

                run_record["status"] = "success"
                run_record["runtime"] = float(runtime)
                run_record["pareto_size"] = int(len(pareto_front))
                run_record["pareto_front"] = pareto_objs

                alg_results['pareto_fronts'].append(pareto_objs)
                alg_results['runtimes'].append(float(runtime))

                print(f"  完成! Pareto前沿: {len(pareto_front)} 个解, 用时: {runtime:.2f}秒")

            except Exception as e:
                runtime = time.time() - start_time
                tb = traceback.format_exc()

                run_record["status"] = "failed"
                run_record["runtime"] = float(runtime)
                run_record["error"] = repr(e)
                run_record["traceback"] = tb

                # 控制台也打印完整traceback，方便你直接看
                print(f"  [FAILED] run={run_idx + 1}/{n_runs}, runtime={runtime:.2f}s, error={repr(e)}")
                print(tb)

            finally:
                alg_results["runs"].append(run_record)
                # 每次run结束就保存checkpoint（无论成功失败）
                all_results["algorithms"][alg_name] = alg_results
                _save_checkpoint()

        # ====== 统计与指标：只对成功的 pareto_fronts 计算 ======
        successful_pfs = alg_results["pareto_fronts"]  # 这里只放成功的（失败run不会append）
        if len(successful_pfs) == 0:
            alg_results["statistics"] = {
                "success_runs": 0,
                "failed_runs": n_runs,
                "hv": None,
                "igd": None,
                "sp": None,
                "runtime": None
            }
            all_results["algorithms"][alg_name] = alg_results
            _save_checkpoint()
            print(f"\n{alg_name}: 所有 runs 均失败，跳过指标计算。")
            continue

        # 计算参考前沿（合并成功run的前沿）
        all_objs = []
        for pf in successful_pfs:
            all_objs.extend(pf)

        reference_front = []
        for obj in all_objs:
            is_dominated = False
            for other_obj in all_objs:
                if (other_obj[0] < obj[0] and other_obj[1] <= obj[1]) or \
                        (other_obj[0] <= obj[0] and other_obj[1] < obj[1]):
                    is_dominated = True
                    break
            if not is_dominated:
                reference_front.append(obj)

        print(f"\n参考前沿(成功runs合并): {len(reference_front)} 个解")
        print(f"\n计算性能指标（仅成功runs）...")

        # 清空旧分数，重新计算（确保和成功runs数量一致）
        alg_results['hv_scores'] = []
        alg_results['igd_scores'] = []
        alg_results['sp_scores'] = []

        for pf_objs in successful_pfs:
            pf_inds = [Individual(schedule=[], objectives=obj) for obj in pf_objs]
            hv = PerformanceMetrics.hypervolume(pf_inds)
            igd = PerformanceMetrics.igd(pf_inds, reference_front)
            sp = PerformanceMetrics.spacing(pf_inds)

            alg_results['hv_scores'].append(float(hv))
            alg_results['igd_scores'].append(float(igd))
            alg_results['sp_scores'].append(float(sp))

        stats = {
            "success_runs": int(len(successful_pfs)),
            "failed_runs": int(n_runs - len(successful_pfs)),
            'hv': {
                'mean': float(np.mean(alg_results['hv_scores'])),
                'std': float(np.std(alg_results['hv_scores'])),
                'min': float(np.min(alg_results['hv_scores'])),
                'max': float(np.max(alg_results['hv_scores']))
            },
            'igd': {
                'mean': float(np.mean(alg_results['igd_scores'])),
                'std': float(np.std(alg_results['igd_scores'])),
                'min': float(np.min(alg_results['igd_scores'])),
                'max': float(np.max(alg_results['igd_scores']))
            },
            'sp': {
                'mean': float(np.mean(alg_results['sp_scores'])),
                'std': float(np.std(alg_results['sp_scores'])),
                'min': float(np.min(alg_results['sp_scores'])),
                'max': float(np.max(alg_results['sp_scores']))
            },
            'runtime': {
                'mean': float(np.mean(alg_results['runtimes'])) if alg_results['runtimes'] else None,
                'std': float(np.std(alg_results['runtimes'])) if alg_results['runtimes'] else None
            }
        }

        alg_results['statistics'] = stats

        print(f"\n{alg_name} 统计结果 (成功 {stats['success_runs']} / 失败 {stats['failed_runs']}):")
        print(f"  HV:  均值={stats['hv']['mean']:.4f}, 标准差={stats['hv']['std']:.4f}")
        print(f"  IGD: 均值={stats['igd']['mean']:.4f}, 标准差={stats['igd']['std']:.4f}")
        print(f"  SP:  均值={stats['sp']['mean']:.4f}, 标准差={stats['sp']['std']:.4f}")
        if stats['runtime']['mean'] is not None:
            print(f"  时间: 均值={stats['runtime']['mean']:.2f}秒, 标准差={stats['runtime']['std']:.2f}秒")

        all_results["algorithms"][alg_name] = alg_results
        _save_checkpoint()

    # 保存最终结果
    _safe_json_dump(all_results, final_file)
    print(f"\n最终结果已保存到: {final_file}")

    # 打印对比表格（只显示有统计的算法）
    print(f"\n{'=' * 80}")
    print("最终对比结果（仅成功runs统计）")
    print(f"{'=' * 80}")
    print(f"{'算法':<15} {'HV (↑)':<20} {'IGD (↓)':<20} {'SP (↓)':<20} {'时间(秒)':<15} {'成功/失败':<10}")
    print("-" * 110)

    for alg_name in algorithms:
        alg_res = all_results["algorithms"].get(alg_name)
        if not alg_res or not alg_res.get("statistics"):
            continue
        st = alg_res["statistics"]
        if st["hv"] is None:
            print(f"{alg_name:<15} {'-':<20} {'-':<20} {'-':<20} {'-':<15} "
                  f"{st['success_runs']}/{st['failed_runs']:<10}")
        else:
            print(f"{alg_name:<15} "
                  f"{st['hv']['mean']:.4f}±{st['hv']['std']:.4f}    "
                  f"{st['igd']['mean']:.4f}±{st['igd']['std']:.4f}    "
                  f"{st['sp']['mean']:.4f}±{st['sp']['std']:.4f}    "
                  f"{st['runtime']['mean']:.2f}±{st['runtime']['std']:.2f}    "
                  f"{st['success_runs']}/{st['failed_runs']:<10}")

    print(f"{'=' * 80}\n")

    return all_results


if __name__ == "__main__":
    # import argparse
    #
    # parser = argparse.ArgumentParser(description='运行DCMA及对比算法实验')
    # parser.add_argument('--instance', type=str, required=True,
    #                    help='测试实例路径')
    # parser.add_argument('--output', type=str, default='results',
    #                    help='输出目录')
    # parser.add_argument('--algorithms', type=str, nargs='+',
    #                    default=['DCMA', 'NSGA-II', 'MOEA/D', 'SPEA2'],
    #                    help='要运行的算法')
    # parser.add_argument('--pop_size', type=int, default=100,
    #                    help='种群大小')
    # parser.add_argument('--max_gen', type=int, default=200,
    #                    help='最大代数')
    # parser.add_argument('--n_runs', type=int, default=10,
    #                    help='独立运行次数')
    #
    # args = parser.parse_args()
    #
    # run_comparison_experiment(
    #     instance_path=args.instance,
    #     output_dir=args.output,
    #     algorithms=args.algorithms,
    #     pop_size=args.pop_size,
    #     max_gen=args.max_gen,
    #     n_runs=args.n_runs
    # )

    """批量运行多个数据集"""
    # 定义要运行的所有数据集
    datasets = [
        'new_dataset/L5_120x4x3.json',
        'new_dataset/L7_150x5x3.json',
        'new_dataset/M5_50x3x2.json',
        'new_dataset/M7_70x4x3.json',
        'new_dataset/S6_15x4x2.json',
        'new_dataset/S7_25x3x3.json',
        # 'datasets/S1_10x2x2.json',
        # 'datasets/S2_10x3x2.json',
        # 'datasets/S3_20x3x2.json',
        # 'datasets/S4_20x2x2.json',
        # 'datasets/M1_40x3x2.json',
        # 'datasets/M2_40x4x2.json',
        # 'datasets/M3_60x3x3.json',
        # 'datasets/M4_60x4x2.json',
        # 'datasets/L1_80x4x3.json',
        # 'datasets/L2_80x3x2.json',
        # 'datasets/L3_100x4x3.json',
        # 'datasets/L4_100x5x3.json'
    ]

    print("=" * 80)
    print(f"批量实验 - 共 {len(datasets)} 个数据集")
    print("=" * 80)

    # 运行每个数据集
    for i, dataset_path in enumerate(datasets, 1):
        print(f"\n{'#' * 80}")
        print(f"数据集 {i}/{len(datasets)}: {dataset_path}")
        print(f"{'#' * 80}\n")

        # 检查文件是否存在
        if not os.path.exists(dataset_path):
            print(f"警告: 文件不存在，跳过: {dataset_path}")
            continue

        # 获取配置
        # config = get_config(dataset_path)
        # print(f"使用配置: pop_size={config['pop_size']}, "
        #       f"max_gen={config['max_gen']}, n_runs={config['n_runs']}")

        try:
            # 运行实验
            run_comparison_experiment(
                pop_size=100, max_gen=100, n_runs=20,
                instance_path=dataset_path,
                output_dir='results',
                algorithms=['NSGA-II', 'MOEA/D', 'SPEA2', 'KMOEA', 'HMOMA', 'QL-MOHPSO', 'EMTMA']
            )
            print(f"\n数据集 {dataset_path} 完成!")

        except Exception as e:
            print(f"\n数据集 {dataset_path} 运行失败:")
            print(f"   错误: {e}")
            print(traceback.format_exc())
            continue

    print(f"\n{'=' * 80}")
    print("批量实验完成!")
    print("所有结果保存在: results/")
    print(f"{'=' * 80}\n")