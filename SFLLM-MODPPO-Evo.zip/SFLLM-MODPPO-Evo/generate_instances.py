#!/usr/bin/env python3
from datasets.generate_instances import main

if __name__ == "__main__":
    main()
