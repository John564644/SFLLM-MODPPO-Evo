"""Instance-generation scripts and generated JSON data."""
