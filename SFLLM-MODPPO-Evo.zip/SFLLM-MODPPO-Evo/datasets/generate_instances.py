#!/usr/bin/env python3
"""Generate the 18 fixed DHFSPP instances described in Section V-A."""

from __future__ import annotations

import argparse
import hashlib
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from sfllm.config import DHFSPConfig

INSTANCE_SPECS = [
    ("S1_10x2x2", 10, 2, 2, [[2, 2], [2, 2]]),
    ("S2_10x3x2", 10, 3, 2, [[2, 2, 2], [2, 2, 2]]),
    ("S3_20x3x2", 20, 3, 2, [[2, 2, 2], [2, 2, 2]]),
    ("S4_20x2x2", 20, 2, 2, [[2, 2], [2, 2]]),
    ("S5_15x4x2", 15, 4, 2, [[2, 3, 2, 3], [3, 2, 3, 2]]),
    ("S6_25x3x3", 25, 3, 3, [[2, 3, 3], [3, 2, 3], [2, 3, 2]]),
    ("M1_40x3x2", 40, 3, 2, [[3, 3, 3], [3, 3, 3]]),
    ("M2_40x4x2", 40, 4, 2, [[3, 3, 3, 3], [3, 3, 3, 3]]),
    ("M3_60x3x3", 60, 3, 3, [[3, 3, 4], [2, 3, 3], [3, 2, 3]]),
    ("M4_60x4x2", 60, 4, 2, [[3, 4, 4, 3], [3, 3, 4, 4]]),
    ("M5_50x3x2", 50, 3, 2, [[3, 4, 3], [4, 3, 4]]),
    ("M6_70x4x3", 70, 4, 3, [[3, 4, 4, 3], [4, 3, 4, 4], [3, 4, 3, 4]]),
    ("L1_80x4x3", 80, 4, 3, [[3, 4, 4, 5], [4, 3, 4, 4], [3, 4, 3, 4]]),
    ("L2_80x3x2", 80, 3, 2, [[4, 5, 5], [4, 4, 5]]),
    ("L3_100x4x3", 100, 4, 3, [[3, 4, 4, 4], [4, 3, 4, 5], [3, 4, 3, 4]]),
    ("L4_100x5x3", 100, 5, 3, [[3, 4, 4, 4, 5], [4, 3, 4, 5, 4], [3, 4, 3, 4, 4]]),
    ("L5_120x4x3", 120, 4, 3, [[4, 5, 4, 5], [5, 4, 5, 4], [4, 5, 5, 4]]),
    ("L6_150x5x3", 150, 5, 3, [[4, 5, 5, 4, 6], [5, 4, 5, 6, 4], [4, 5, 4, 5, 5]]),
]


def stable_instance_seed(base_seed: int, name: str) -> int:
    digest = hashlib.sha256(name.encode("utf-8")).digest()
    offset = int.from_bytes(digest[:4], "big")
    return (base_seed + offset) % (2**32)


def generate_instance(
    name: str,
    n_jobs: int,
    n_stages: int,
    n_factories: int,
    machines_per_stage: list[list[int]],
    seed: int,
) -> DHFSPConfig:
    rng = random.Random(seed)
    processing_times: dict[str, dict] = {}
    energy_consumption: dict[str, dict] = {}
    for job in range(n_jobs):
        processing_times[str(job)] = {}
        energy_consumption[str(job)] = {}
        for stage in range(n_stages):
            processing_times[str(job)][str(stage)] = {}
            energy_consumption[str(job)][str(stage)] = {}
            for fac in range(n_factories):
                processing_times[str(job)][str(stage)][str(fac)] = {}
                energy_consumption[str(job)][str(stage)][str(fac)] = {}
                for machine in range(machines_per_stage[fac][stage]):
                    processing_times[str(job)][str(stage)][str(fac)][str(machine)] = round(
                        rng.uniform(10.0, 30.0), 2
                    )
                    energy_consumption[str(job)][str(stage)][str(fac)][str(machine)] = round(
                        rng.uniform(50.0, 150.0), 2
                    )
    return DHFSPConfig(
        name=name,
        n=n_jobs,
        k=n_stages,
        f=n_factories,
        machines_per_stage=machines_per_stage,
        processing_times=processing_times,
        energy_consumption=energy_consumption,
        seed=seed,
    )


def build_all(output_dir: Path, base_seed: int = 42) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    for name, n, k, f, machines in INSTANCE_SPECS:
        seed = stable_instance_seed(base_seed, name)
        instance = generate_instance(name, n, k, f, machines, seed)
        path = output_dir / f"{name}.json"
        instance.to_json(path)
        print(f"wrote {path.name}: n={n}, k={k}, F={f}, seed={seed}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    build_all(args.output_dir, args.seed)


if __name__ == "__main__":
    main()
