#!/usr/bin/env python3
"""Run SFLLM-MODPPO-Evo on one DHFSPP JSON instance."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

from sfllm.config import DHFSPConfig, ExperimentConfig
from sfllm.framework import SFLLMMODPPOEvo
from sfllm.llm.client import OfflineCandidateProvider, OpenAICompatibleProvider


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--instance", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("outputs/result.json"))
    parser.add_argument(
        "--llm-mode",
        choices=("auto", "api", "offline"),
        default="auto",
        help="auto uses API when LLM_API_KEY and LLM_MODEL exist; otherwise offline smoke-test mode",
    )
    parser.add_argument("--quick", action="store_true", help="small functional run, not paper-scale")
    parser.add_argument("--population", type=int)
    parser.add_argument("--iterations", type=int)
    parser.add_argument("--feedback-interval", type=int)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="cpu")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    cfg = DHFSPConfig.from_json(args.instance)
    experiment = ExperimentConfig.quick(args.seed) if args.quick else ExperimentConfig(seed=args.seed)
    experiment.device = args.device
    if args.population is not None:
        experiment.population_size = args.population
    if args.iterations is not None:
        experiment.iterations = args.iterations
    if args.feedback_interval is not None:
        experiment.llm_feedback_interval = args.feedback_interval
    experiment.validate()

    mode = args.llm_mode
    if mode == "auto":
        mode = "api" if os.getenv("LLM_API_KEY") and os.getenv("LLM_MODEL") else "offline"
    provider = (
        OpenAICompatibleProvider(experiment)
        if mode == "api"
        else OfflineCandidateProvider(seed=args.seed)
    )
    framework = SFLLMMODPPOEvo(cfg, experiment, provider)
    result = framework.run()
    framework.save_result(args.output)
    summary = {
        "instance": result["instance"],
        "llm_mode": mode,
        "pareto_solutions": len(result["pareto_solutions"]),
        "output": str(args.output),
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
